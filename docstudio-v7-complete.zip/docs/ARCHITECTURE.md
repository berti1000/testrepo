# DocStudio 5 architektúra

## Könyvtárak és felelősség

| Hely | Feladat |
|---|---|
| `studio/ir.py`, `schemas/document-ir.schema.json` | Az egyetlen tartós dokumentum-adatmodell; validáció és assettár |
| `studio/profiling.py` | Natív szöveg, képi oldalak, fájltípus, pénzügyi tartalom alapján profil |
| `studio/router.py` | Képességek ellenőrzése, Strategy kiválasztása, hibakódok → tényleges paraméterek |
| `studio/pipeline.py` | Bemenet → IR, illetve kiválasztott oldal újrafelismerése |
| `studio/engines/neural.py` | PP-OCRv5 Latin detektálás, CTC-koordináták és tipográfia |
| `studio/engines/verify.py` | Független Tesseract-olvasat: eltérések jelölése |
| `studio/engines/typography.py` | Keskeny nyugtabetűk magassága és szomszédos sorok elkülönítése |
| `studio/engines/tables.py` | TATR detektálás, rács, összevonás; térközös oszlopstratégia |
| `studio/engines/vision.py` | Engedélyhez kötött Vision, hibát tartalmazó prompt és validált válasz |
| `studio/office.py` | OOXML-validáció, izolált LibreOffice-render, XLSX natív cellaimport |
| `studio/output/` | IR → export és a tényleges fájl előnézete |
| `studio/workflow.py` | Explicit állapotátmenetek és bemeneti/kimeneti hibakódok |
| `studio/store.py` | SQLite WAL, immutable IR-verziók, helyi feladatsor, visszaállítás |
| `web/routes/studio_api.py` | V5 HTTP API, tulajdonos- és verzióellenőrzés |
| `web/templates/studio.html`, `web/static/studio.*` | Két vászon, hibagombok, szerkesztés, folyamatállapot |
| `reconstructor/` | Tesztelt alacsony szintű PDF/kép/OCR/geometriai és rajzoló primitívek |
| `tests/`, `scripts/*smoke.py`, `scripts/benchmark_v5.py` | Automatizált regressziók, tényleges OCR és böngésző |

A régi `reconstructor.model.Document` csak futás közbeni adapter a korábbi rajzoló kódhoz. A v5 egyetlen tartós dokumentumformátuma az IR. A régi v4 API külön kompatibilitási kapcsolóval engedélyezhető; alapból nem érhető el.

## IR adatmodell

Koordináták: **bal felső origó, PDF-pont (72 pont/hüvelyk), normalizált oldal**. Az EXIF/tájolás/dőlés/perspektíva előfeldolgozás után ezek a vászonhoz tartozó koordináták. Az eredeti feltöltés és a normalizált PDF külön asset.

```json
{
  "schema_version": "docstudio.ir/1.0",
  "coordinates": "top-left; PDF points; normalized page",
  "filename": "pelda.pdf",
  "sha256": "...",
  "source_asset": "...",
  "source_pdf_asset": "...",
  "normalized_pdf_asset": "...",
  "revision": 1,
  "profile": {"kind": "scanned", "label": "Szkennelt", "reasons": [], "pages": 1},
  "pages": [{
    "number": 1, "width": 595.0, "height": 842.0,
    "words": [{
      "id": "p1-n1", "text": "Összesen", "bbox": [40, 80, 95, 92],
      "origin": [40, 90], "size": 12, "font": "Liberation Sans",
      "source": "paddle-ppocrv5-latin", "confidence": 0.93,
      "alternatives": [], "reviewed": false
    }],
    "blocks": [], "images": [], "rules": [], "paths": [],
    "warnings": [], "diagnostics": {}
  }],
  "provenance": [], "edits": [], "warnings": [], "options": {}
}
```

Ez rövidített szemléltetés. A formális schema és a kitöltött `examples/ir-example.json` az irányadó. A `words` listából a stabil azonosítókat használják a blokkok és cellák; a szemantikai olvasási rendet a blokkok adják. Cellák: `row`, `col`, `rowspan`, `colspan`, `bbox`, `words`, opcionális kézi `override`.

A képek és forrásbájtok az `AssetStore` tartalom alapján címzett fájljai. Olvasáskor SHA256-ellenőrzés történik. A JSON önmagában nem viszi magával a bináris asseteket. A CLI-csomag igen. Az IR-változatok `ir-1.json`, `ir-2.json` stb. néven maradnak meg; javítás nem írja felül az előzőt.

## Állapotgép

```mermaid
stateDiagram-v2
    [*] --> queued
    queued --> profiling: indítás
    profiling --> processing: profil kész
    processing --> input_review: IR elkészült
    processing --> failed: első beolvasás hibás
    input_review --> processing: hibagomb
    input_review --> input_review: javítás vagy visszaállítás
    input_review --> input_accepted: beolvasás elfogadása
    input_accepted --> exporting: export kérése
    exporting --> export_review: fájl és előnézet kész
    exporting --> input_accepted: exporthiba
    export_review --> exporting: export hibagomb
    export_review --> ready: előnézet elfogadása
    ready --> exporting: új célformátum
    ready --> input_review: kézi javítás
```

Az elfogadás nem automatikus. A `version` a munkafolyamat optimista zárolási száma; a `revision` a dokumentum IR-változatának sorszáma. Elavult módosítás: HTTP 409. Újraszámolás alatt nem lehet szerkeszteni, visszaállítani vagy letörölni a feladatot. Ha újrapróbálás hibázik, a kész előző IR visszakerül az ellenőrzési állapotba.

Visszaállításkor a korábbi változat lesz aktuális. Az ezt követő javítás új, monoton növekvő revisiont hoz létre; nem használja újra a régi sorszámot. Az export az IR-revisiont és a kész fájl hashét rögzíti. Letöltés csak `ready` állapotban, egyező hash mellett lehetséges. Kézi javítás és bemeneti újrafelismerés érvényteleníti az előző exportot.

## Stratégiák és visszacsatolás

| Jelzés | Valós beavatkozás |
|---|---|
| Zagyva/hiányos szöveg | Paddle ↔ Tesseract váltás, kontraszt és PSM; későbbi próbán engedélyezett Vision választható |
| Összefolyt oszlopok | Kisebb gap_factor, térköz- és vonalalapú blokkszétválasztás |
| Táblázat szétesett | TATR, majd következő próbán szigorú geometriai rács; hiányzó modellnél explicit figyelmeztetés |
| Word elemek szétcsúsztak | Soronkénti doboz helyett külön pozicionált szavak |
| Word rossz margók | Oldalhoz rögzített pozicionálás és nulla margó |
| Word folyószöveg | Folyó bekezdés-/táblázatexport, eltérő tördelési céllal |
| Excel üres/összevont cellák | Üres sor/oszlop tömörítés, összevonások kikapcsolása |
| Excel számok szövegként | Explicit magyar számkonverzió, azonosítók és nem számszerű szöveg megőrzése |
| Excel oszlopok elcsúsztak | Szemantikai cellarács tömörítése, összevonások nélkül |

Nincs be nem kötött LayoutLM-, Camelot- vagy Tabula-ág. A felület az elérhető motorokat és a ténylegesen futott stratégiát mutatja. A TATR nem végez OCR-t: a rácsot a képből ismeri fel, majd az OCR-szavakat rendeljük a cellákhoz. Hibás rács esetén marad használható geometriai változat.

### Szkennelt oldalak koordinátái és táblázatai

A RapidOCR 3.4.2 adaptere egyszer vetíti vissza a szódobozokat az eredeti képméretre. A könyvtár belső képméretezése és a szódobozok ismételt visszavetítése hosszú nyugtákon eltolódást okozott; a javítást 6000 pixel magas, négy szövegsoros neurális regressziós teszt ellenőrzi. A Latin CTC-dobozok szélességét külön, a detektált sorhoz igazítjuk. Ez geometriai korrekció, nem szövegjavítás.

A keskeny nyugtabetűknél a betűmagasságot az észlelt tintamagasság adja, a vízszintes illesztés külön skálával történik. Az eljárás legalább nyolc monospace soron keres következetes összenyomást, ezért egyetlen magas zajdoboz nem kapcsolja be. Az azonos vízszintes területet elfoglaló szomszédos sorok távolsága korlátozza a betűmagasságot; ezzel elkerülhető, hogy a szélességből becsült eltérő betűméretek egymásra csússzanak. Ez fontközelítés, nem az eredeti nyomtató betűkészletének helyreállítása.

A kontrasztszegény képek normalizálása csak az OCR ideiglenes bemenetén történik. A képi PDF táblázatrácsának kereséséhez a felismert IR-szövegből ideiglenes, valódi betűs PDF készül. Így a vonalalapú kereső már szövegtartalommal tudja ellenőrizni a cellákat. A neurális táblázatjavaslatot elutasítjuk, ha átfedő vagy a meglévő tábla szavait jelentősen elhagyná; a diagnosztika a jelöltek és elutasítások számát is megmutatja.

## Feldolgozás és biztonsági határok

Egy alkalmazásfolyamat és egy CPU worker. SQLite-ban a jobmetaadat van, a dokumentum assetek és verziók a háttértáron. A kész állapotok megőrződnek; újraindításkor a megszakadt feladat nem tűnik sikeresnek. A háttérfeladatsor nem elosztott.

A tulajdonos szerver által aláírt, HttpOnly, SameSite böngészőmunkamenethez kötött. A módosító böngészőkérések eredetét, a feltöltések méretét, az OOXML kibontott méretét, a kiválasztott motor elérhetőségét és a változatszámot ellenőrizzük. A publikus éles mód jelszót és HTTPS-beállítást követel. Az Office-konverzió külön profillal, makrók és hivatkozásfrissítés tiltásával fut. Internetelérést igénylő OCR nincs automatikusan bekapcsolva.


## V6 kiegészítés: elrendezés és előnézet

A kezdeti OCR/kinyerési út változatlan. A `studio/layout_grid.py` az IR szavainak koordinátáiból, stabil függőleges térközökből és az első oszlop rekordkezdetéből készít új rácsot. A többsoros szavak/dátumok cellán belüli sorok maradnak. A fejléc által jelölt üres oszlop nem törlődik. Ez általános geometriai eljárás; nincs Expedia- vagy ügyfélspecifikus mezőlista a motorban.

A `studio/output/excel_layout.py` alapmódja a lapelrendezés: a táblázatot és a mellette/fölötte lévő bekezdéseket közös cellageometriára vetíti. A betűstílusok rich text, a logók külön XLSX-rajzobjektumok. A szöveg nem oldalkép. A PDF valóban üres lapjai kimaradnak az XLSX-ből. A tömörítés kizárólag üres térközt rövidít.

A `studio/output/excel.py::preview` a már elmentett XLSX-et olvassa vissza: értékek, adattípusok, stílusok, rich-text szakaszok, oszlopszélességek, sormagasságok, összevonások és képhorgonyok. A böngésző ezt jeleníti meg; nem futtat új dokumentumfelismerést. A LibreOffice nyomtatási előnézet külön kapcsolható. A webböngésző és az Office nem azonos betűtördelő motor, ezért pixelazonosságot nem állítunk.

A hibás oszlopok újrafelismerése teljesen újraépíti a táblázatblokkokat is. Három eltérő vágási szabály fut; vonalas táblázatnál a harmadik az ismert vonalakra igazít. Scan esetén a Router más elérhető OCR-motorra vált, és PSM/kontraszt-paramétereket is módosít. Natív PDF betűrétegét szükségtelen OCR-rel rontani: ott az oszlop- és rekordfelismerés vált. A diagnosztika megkülönbözteti a szöveg/pozíció és a szerkezet változását; azonos eredményt nem állít javulásnak.

Az inline szerkesztő az aktuális IR-verziót zároló számmal ment. Nyitott javítás alatt a jóváhagyás és lapváltás tiltott, Enter ment, Escape elveti a piszkozatot. Az állapotfrissítés nem törli a megkezdett szöveget. A középen lévő első jóváhagyás formátumválasztót nyit; a második a kész fájl ellenőrzött letöltését indítja. Megváltoztatott exportbeállítás mellett előbb új előnézet kell.

Az első Excel-export a TATR, vonalrács, kézi szerkezet és natív XLSX explicit cellarácsát és cellafelülírásait tiszteletben tartja. A pusztán szövegillesztésből becsült korábbi rácsot újraépíti. Az export oszlophiba-gombja az explicit rács helyett is kérhet eltérő geometriai próbát.
