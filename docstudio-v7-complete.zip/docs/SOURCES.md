# Hivatalos források és függőségek

A megvalósítás az alábbi elsődleges dokumentációkra támaszkodik; a linkek az adott könyvtár hivatalos oldalai.

- Tesseract képminőség, DPI, binarizálás, zaj és oldalszegmentálás: https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html
- Hivatalos, pontosságra optimalizált LSTM-modellek: https://github.com/tesseract-ocr/tessdata_best
- A letöltött modellverzió: https://github.com/tesseract-ocr/tessdata_best/tree/4.1.0
- Tesseract futtatási módok: https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html
- PyMuPDF OCR: https://pymupdf.readthedocs.io/en/latest/recipes-ocr.html
- PyMuPDF többfolyamatos feldolgozás, a threading korlátja: https://pymupdf.readthedocs.io/en/latest/recipes-multiprocessing.html
- OpenCV geometriai transzformációk: https://docs.opencv.org/4.x/da/d54/group__imgproc__transform.html
- FastAPI moduláris alkalmazások: https://fastapi.tiangolo.com/tutorial/bigger-applications/
- Starlette munkamenetek: https://www.starlette.io/middleware/#sessionmiddleware
- Ollama OpenAI-kompatibilis végpont, képi bemenet: https://docs.ollama.com/api/openai-compatibility
- GitHub Codespaces konfiguráció: https://docs.github.com/en/codespaces/setting-up-your-project-for-codespaces/introduction-to-dev-containers
- Dev Container életciklus: https://containers.dev/implementors/json_reference/

## Rögzített modellek

| Modell | Forráscímke | SHA256 |
|---|---|---|
| hun.traineddata | tessdata_best / 4.1.0 | `08786ad5fe25d502d1cfcdf606ba215f320409a1630109582fa1a38d93b3e32d` |
| eng.traineddata | tessdata_best / 4.1.0 | `8280aed0782fe27257a68ea10fe7ef324ca0f8d85bd2fd145d1c2b560bcb66ba` |

Az OSD-modell elsőként a rendszer Tesseract-csomagjából másolódik, ennek hiányában a hivatalos `tessdata/4.1.0` forrásból töltődik. A telepítő mindhárom modell tényleges SHA256-át a `models/tessdata/manifest.json` fájlba írja. A két nyelvi modell hash-eltérését hibának tekinti; az OSD rendszercsomag-verziója változhat.

## Licenc

A kód a felhasználó meglévő projektjének továbbfejlesztése; az átadás nem állapít meg új licencet a korábbi szerzői jogok helyett. A Python- és rendszerfüggőségek saját licencei érvényesek. A PyMuPDF AGPL/kereskedelmi licencelését terjesztés és zárt üzleti szolgáltatás előtt külön tisztázni kell: https://pymupdf.readthedocs.io/en/latest/about.html#license-and-copyright

A csomag nem tartalmaz letöltött modellbinárisokat, külső fontfájlokat vagy a felhasználó számlafájlját. A telepítő a fenti hivatalos modelleket tölti le; a konténer a fontokat és rendszerkönyvtárakat csomagkezelőből telepíti.


## V6 elrendezés és rácsos előnézet

- [openpyxl rich text](https://openpyxl.readthedocs.io/en/3.1.3/rich_text.html): cellán belüli betűformázás.
- [openpyxl drawing anchors](https://openpyxl.readthedocs.io/en/latest/_modules/openpyxl/drawing/spreadsheet_drawing.html): XLSX képek helye és mérete.
- [actions/checkout](https://github.com/actions/checkout/releases) és [actions/setup-python](https://github.com/actions/setup-python/releases): a CI-ben használt v7 kiadások.
