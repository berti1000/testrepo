# DocStudio 7 – kiadási tesztjelentés

Dátum: 2026. november 5. Környezet: Linux, Python 3.12, Tesseract 5 hun/eng, valódi PP-OCRv5 Latin ONNX-modellek, LibreOffice Writer/Calc és Chromium headless (Playwright 1.51.0). A mellékelt Codespaces-konfiguráció Python 3.11-et használ.

## Automatizált ellenőrzés

- **163 sikeres pytest eset, 0 kihagyás**, 45,78 másodperc. A valódi OCR- és Office-integrációs tesztek be voltak kapcsolva. Egy függőségi deprecation warning nem érintette az eredményeket.
- **27 sikeres böngészős ellenőrzés:** 14 a csatolt ötoldalas pénzügyi PDF-en, 13 generált dokumentumon. JavaScript-hiba: 0. A tényleges XLSX-ből megjelenített összes ellenőrzött munkalapon 0 függőlegesen levágott cellaszöveg; 390 px-es mobilnézet is ellenőrizve.
- Ruff, JavaScript- és Bash-szintaxis, devcontainer JSON ellenőrizve.
- A csomag tartalmaz generált dokumentumokat előállító teszteket, valódi OCR-próbákat és a saját dokumentumokhoz használható `scripts/verify_v7.py` programot.

A tesztek konkrét regressziókat ellenőriznek. A sikeres teszt nem általános OCR-pontosságmérés és nem bizonyítja minden dokumentum hibátlan újraalkotását.

## Szkennelt minták

A felhasználótól kapott aláírásos űrlapkivágást, a lekerekített fejlécű számla képkivágását és a teljes, egyoldalas szkennelt nyugta-PDF-et valódi PP-OCRv5-tel dolgoztuk fel. A két képkivágás nem teljes eredeti dokumentum. Az elérhető állományokon PDF-, PNG- és XLSX-export is készült.

A legutóbbi beolvasások: 6.88 s / 32 szó; 26.99 s / 247 szó; 18.01 s / 248 szó. A részletes futásidők és szószámok az `evidence-v7/samples.json` fájlban szerepelnek. A futásidő a beolvasást méri, nem tartalmazza a telepítést és az Office-exportot; egyetlen helyi futás eredménye, nem általános sebességígéret.

Vizuálisan ellenőrizve:

- Az űrlapon a kék aláírás, a pontozott kitöltővonalak és az eredeti vékony rácsvonalak megmaradnak. A grafika nem egyenes szakaszokkal újrarajzolt aláírás.
- A számlán a lekerekített fejléc, a szaggatott tételhatárok és a vonalvastagságok forráspixelei megmaradnak. A sorszám felirata és az azonosító külön helyet kap.
- A felismert szöveg valódi betűként kerül a grafikai réteg fölé; szerkeszthető. A grafika raszteres megőrzése nem vektoros alakzatfelismerés.
- A generált grafikai regresszióteszt pontos pixelelérést ellenőriz a szövegtől távoli íveken, pontokon és aláíráson, továbbá a felismert eredeti betűk eltávolítását.
- A nyugta teljes exportpróbája az utolsó oszlopon túli cellaösszevonási hibát tárt fel. A határkezelést javítottuk, külön sűrű szövegű regresszióteszt készült, majd a mintát újrafuttattuk.

Maradt OCR-eltérés például apró sorszámokban és egyes rövidítésekben; a vászonszerkesztővel javíthatók. A felismert szöveg és a rajz átfedése, szorosan érintkező betűk/vonalak, valamint a kézírás továbbra is nehéz eset. Nem állítunk 100%-os felismerést vagy teljes pixelazonosságot.

## Excel: a csatolt remittance_expedia_0914.pdf

| Ellenőrzés | Eredmény |
|---|---|
| Munkalapok / LibreOffice nyomtatási oldalak | 5 / 5 |
| Részletező rekordok | 71 / 71 |
| Kifizetések összege | 4 732,71 EUR |
| Újrarendezési stratégiák | Mindháromnál 71 rekord, azonos végösszeg |
| Részletező oszlopok | 10 minden adatoldalon |
| Sormagasság | Legalább 18 pt; az eredeti függőleges kiterjedésből és a mért szövegből csak növekszik |
| Cellaszöveg zsugorítása | Kikapcsolva |
| Megjegyzés / megjegyzés-XML / piros megjegyzésjel | 0 |
| Stílus | Rich text, explicit ARGB szín, hordozható betűcsaládok, külön logókép |
| Előnézet és letöltés | A jóváhagyott tényleges XLSX SHA256-azonossága ellenőrizve |

A fejléc és az első adatlap tényleges LibreOffice-renderét vizuálisan is ellenőriztük. Az előnézeti rács a kész munkafüzetből olvassa a cellákat, méreteket, összevonásokat és képeket. A program nem az iLovePDF belső algoritmusát használja; a képernyőképek vizuális referenciák. Az eredeti lap üres függőleges területe megmaradhat, ezért az eredmény nem azonos a referencia tömörített elrendezésével.

A nyers forrásszöveg képletnek látszó értéke nem válik futtatható Excel-képletté. A hosszú és kezdő nullás azonosítók szövegek maradnak. A korábbi 80 tételes, 7 601,49 EUR-os júliusi mintához tartozó regresszióteszt is sikeres volt a teljes tesztfutásban.

## Szerkesztés és visszacsatolás

Ellenőrzött: inline szöveg-, betűméret-, félkövérség- és betűcsalád-szerkesztés; mentés és verzióváltás; Escape piszkozateldobás; nagyobb betűre változtatott szó szomszédainak elmozdítása; korábbi változat visszaállítása; eltérő paraméterű oszlop-újraszegmentálás; ikonos formátumválasztó; középre igazított jóváhagyás; munkalapfülek; teljes cellaérték; rács/nyomtatási nézet; elavult export jóváhagyásának tiltása; automatikus letöltés; PNG/ZIP kiterjesztés; batch ZIP; újratöltés; mobilnézet. A nagy bevezető címblokk eltűnését böngészőteszt is ellenőrzi.

## PDF / Word / Vision

Az új pénzügyi PDF DOCX-exportja LibreOffice-ban 5 oldal. A renderelt DOCX és az IR nem-whitespace karaktereinek multihalmaza egyezik: nincs hiányzó vagy hozzáadott karakter. Ez tartalmi regresszióellenőrzés, nem a betűalakok pixelazonosságának mérése.

A Vision kapcsolatellenőrzése valódi HTTP-státuszokat kezelő mocktesztekkel futott: siker, 401, 403, 404, 500 és hiányzó modellbeállítás. A teszt nem küld dokumentumot a szolgáltatónak. A modell-lista elérése még nem bizonyítja, hogy a modell képet fogad. Élő Vision-feldolgozásra ebben a környezetben nem volt beállított szolgáltató; a felhasználó távoli API-hibájának konkrét oka ezért nem állapítható meg ebből a futásból.

## Sebesség és telepítés

A neurális első olvasatot alapból nem követi kötelező, külön Tesseract-ellenőrzés; ez a felületen bekapcsolható. A kiegyensúlyozott klasszikus OCR jó első eredménynél kihagyhat további meneteket. A vonalfelismerés egyszer készít NumPy képtömböt, nem kontúronként. Ezek a változtatások csökkentik a felesleges munkát, de az oldal mérete, CPU és választott ellenőrzés továbbra is befolyásolja az időt.

A Yarn-tároló javítása vegyes `.list` és `.sources` mintákkal tesztelt: más tárolók változatlanok; a javítás megismételhető; az aláírás-ellenőrzés nincs kikapcsolva. A telepítési szkriptek Python 3.11/3.12-t követelnek.

Microsoft Excel/Word saját renderét, Docker-buildet, élő Codespaces-indítást és új TATR-modellsúlyos futást ebben a kiadási környezetben nem végeztünk. A CI-konfiguráció tartalmaz Docker- és böngészős ellenőrzést, de a mellékelt konfiguráció nem bizonyítja annak távoli lefutását.

## Reprodukálás

```bash
RUN_OCR_TESTS=1 RUN_OFFICE_TESTS=1 DOCSTUDIO_SAMPLE_PDF=/teljes/utvonal/remittanceDetails_expedia0717.pdf .venv/bin/python -m pytest tests -q
.venv/bin/python scripts/browser_v7.py
.venv/bin/python scripts/browser_v7.py --sample /teljes/utvonal/remittance_expedia_0914.pdf
.venv/bin/python scripts/verify_v7.py /teljes/utvonal/remittance_expedia_0914.pdf --engine native --with-office
.venv/bin/python scripts/verify_v7.py /teljes/utvonal/scan.png /teljes/utvonal/nyugta.pdf --engine paddle
```

A saját dokumentumok és az azokról készült képernyőképek nincsenek a forráscsomagban. A megosztható gépi összesítők az `evidence-v7/` könyvtárban vannak. Korábbi kiadások történeti mérései: `V6_TEST_REPORT.md`, `V5_TEST_REPORT.md`.
