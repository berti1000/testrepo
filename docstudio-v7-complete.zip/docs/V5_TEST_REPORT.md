# DocStudio 5 — tesztjegyzőkönyv

Dátum: **2026. november 3.** A végleges kódon futtatott ellenőrzések. Linux, Python 3.12.14; a pontos Python-csomagverziók az `evidence/versions.json` fájlban találhatók. A Docker/Codespaces konfiguráció Python 3.11-re készült; annak távoli futtatását nem állítjuk.

## Automatizált regresszió

**112 sikeres teszt, 0 hiba, 0 kihagyás**, 55.36 másodperc. Egy Starlette/AnyIO deprecation figyelmeztetés. A `RUN_OCR_TESTS=1 RUN_OFFICE_TESTS=1` kapcsolókkal valódi Tesseract, helyi neurális OCR és LibreOffice is futott.

Ellenőrzött: IR-validáció, állapotátmenetek, feltöltés és verzióütközés, oldalszintű újrapróba, kézi javítás/visszaállítás, munkamenet-izoláció, pontos eredetifájl-megőrzés, numerikus konverzió és kezdő nullák, szövegként kezelt képletjelöltek, valódi DOCX/XLSX-előnézet, Word-visszaolvasás, exporthash-egyezés. A Vision HTTP/JSON-szerződése szimulált szolgáltatással futott.

Új célzott regressziók: hosszú scan dupla koordináta-visszavetítésének megszüntetése (1400×6000 pixeles, négy soros neurális teszt); CTC szóköz-/összegmegőrzés; kontrasztszegény OCR-bemenet; képi PDF vonalas táblázata az IR-ből; rövid numerikus táblázatok; hiányos TATR-rács elutasítása; Word szövegdoboz-véletlentördelés; keskeny nyugtabetűk külön magasság-/szélességillesztése és szomszédos sorok ütközésének korlátozása; többsoros összevont Excel-cellák magassága. Ruff, JavaScript- és shell-szintaxis ellenőrzés sikeres.

## Ismert szövegű neurális OCR-benchmark

A `scripts/benchmark_v5.py` **10 szavas, 79 karakteres** magyar/angol tesztlap nyolc változatát dolgozza fel. A WER/CER a tényleges TXT-export olvasási rendjét hasonlítja a referenciához, kis-/nagybetűt figyelmen kívül hagyva. Ez szűk regressziós minta, nem általános OCR-pontosságmérés.

| Változat | Szóhibaarány (WER) | Karakterhibaarány (CER) | Összeg + kezdő nullás ID pontos | Látható betűs futam |
|---|---:|---:|---|---:|
| clean | 10.0% | 1.27% | igen | 10 |
| low-contrast | 10.0% | 1.27% | igen | 10 |
| noise | 10.0% | 1.27% | igen | 10 |
| blur | 10.0% | 1.27% | igen | 10 |
| skew | 10.0% | 2.53% | igen | 10 |
| rotation-90 | 10.0% | 2.53% | igen | 10 |
| rotation-180 | 10.0% | 1.27% | igen | 10 |
| rotation-270 | 10.0% | 1.27% | igen | 10 |

Minden változatban a `347.25` összeg és a `0012345678` azonosító pontos. Egy ékezetes szó hibás maradt; a független Tesseract-olvasat ezt ellenőrzési eltérésként jelölte. A regressziós felső küszöb WER 20%, CER 6%; ez nem minőségi ígéret más dokumentumra. Nincs kézi javítás a mért eredményekben.

## Öt valódi felhasználói PDF

Két A4-es számla és három A3-oldalon lévő nyugta, köztük egy hosszú, keskeny betűs blokk. Mind az öt fájl alapfeldolgozása és a három oldalszintű hibastratégia (szöveg, oszlopok, táblázat) lefutott: **5 + 15 = 20 művelet**. A kiadási minták tájoláskorrekció nélkül készültek, mert az eredetik álló helyzetűek. Az automatikus tájolást a szintetikus 90/180/270 fokos esetek vizsgálják.

| Minta | OCR-szó/jelölt | Látható PDF-betűs futam | DOCX / XLSX előnézeti oldalak | Eredeti bájtazonos |
|---|---:|---:|---:|---|
| minta-01 | 197 | 197 | 1 / 4 | igen |
| minta-02 | 357 | 357 | 1 / 3 | igen |
| minta-03 | 248 | 248 | 1 / 5 | igen |
| minta-04 | 163 | 163 | 1 / 4 | igen |
| minta-05 | 94 | 93 | 1 / 3 | igen |

A mintaszámok a külön eredménycsomag számozott mappáinak felelnek meg. A forráskód ZIP nem tartalmazza a privát számlákat. Az eredménycsomagban ott az eredeti PDF, a felismert IR és assetei, a valódi betűkből újraalkotott PDF, a DOCX/XLSX, ezek LibreOffice-előnézete, valamint a három újrapróba IR-je és PDF-je.

A PP-OCRv5 Latin ONNX és mindkét helyi TATR-modell ténylegesen futott. A diagnosztika megkülönbözteti az elfogadott TATR-rácsot a geometriai tartaléktól. Üres vagy hiányos neurális táblázatjavaslatnál a geometriai rács marad meg; a motor puszta lefutása nem jelent helyes táblázatot. A szószám és a betűs futamok száma sem pontossági mutató. A mintákhoz nincs teljes, kézzel ellenőrzött referenciaátírás, ezért nem adunk rájuk OCR-pontossági százalékot.

## Böngésző és export

Valódi Chromium Headless + Uvicorn: **8 ellenőrzött folyamat, 0 JavaScript-hiba**. Többfájlos feltöltés, neurális vászon, szó javítása és visszaállítása, oszlophiba miatti újrapróba, tényleges Word-előnézet és exportjavítás, elfogadás utáni SHA256-azonos letöltés, Excel számkonverzió/rács, elfogadott exportok ZIP-je, újratöltés és 390 pixeles mobilnézet.

A CLI mind a hat formátumot elkészítette (PDF, DOCX, XLSX, JSON, HTML, TXT), az IR és assetek mellett. A DOCX/XLSX előnézetek az elkészült fájlok renderelései. Az öt minta PDF-, Word- és Excel-képét vizuálisan is ellenőriztük; ez nem automatizált pixelazonossági bizonyíték.

## Megmaradó minőségi korlátok

- A keskeny, ismeretlen nyomtatóbetűk mérete/térköze és a hosszú nyugta egyes sorai eltérnek a forrástól. Külön javítás készült a kattintható szódobozok eltolódására és a keskeny betűk miatt összetorlódó sorokra; ezek nem állítják helyre az ismeretlen eredeti fontot.
- Átfedő bélyegző, apró lábléc és egyes magyar ékezetek továbbra is bizonytalanok. A táblázat és az összeg–megnevezés összerendelés ellenőrzést igényel.
- Az Excel szemantikai adatrács; a számla lapképének pontos másolata nem célja. Wordben szerkeszthető, pozicionált szöveg készül, de 100%-os pixelazonosság nem garantált. Az eredeti feltöltés bájtpontosan külön megmarad.
- Microsoft Wordben külön renderelési próba nem történt; a mért előnézet LibreOffice-ból származik.

## Nem futtatott ellenőrzések

Docker image build és valódi GitHub Codespaces-indítás (nincs itt Docker daemon vagy felhasználói GitHub-repo); élő Vision/Ollama API (nincs beállított modell); nagyforgalmú terhelés, többgépes queue, kézírás és független biztonsági audit. A helyi futás nem igazolja ezeket. A csomag egyetlen feldolgozóval és legalább 8 GB memóriával használható; több külön OCR/Office tesztfolyamat párhuzamos indítása nagyobb memóriát igényelhet.

## Megismétlés

```bash
RUN_OCR_TESTS=1 RUN_OFFICE_TESTS=1 .venv/bin/python -m pytest tests -q
.venv/bin/python scripts/benchmark_v5.py
.venv/bin/python scripts/verify_samples.py /sajat/mappam/*.pdf --output test-results/sajat --no-orientation
.venv/bin/python scripts/studio_browser_smoke.py --sample /sajat/mappam/sajat.pdf
```

A mintateszt üres kimeneti mappát kér, korábbi eredményt nem ír felül. A böngészős képernyőképek csak helyi QA-fájlok; a szállított csomagoknak nem részei.
