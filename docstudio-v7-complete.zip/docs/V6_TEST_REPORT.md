# DocStudio 6 – kiadási tesztjelentés

Dátum: 2026. november 5. Környezet: Linux, Python 3.12, Tesseract 5 + hun/eng modellek, LibreOffice Writer/Calc, Chromium headless (Playwright 1.51.0). A kiadás Python 3.11-es Codespaces-konfigurációt tartalmaz.

## Összesítés

- **137 sikeres pytest eset, 1 kihagyott eset.** Valódi Tesseract- és LibreOffice-tesztek bekapcsolva. A kihagyott esethez helyi PP-OCRv5 ONNX-modellek szükségesek; ezek nem voltak telepítve ebben a kiadási környezetben. A neurális OCR és TATR korábbi kiadásban mért eredményei külön, történeti jelentésben vannak; nem állítjuk, hogy itt újramértük őket.
- **12 sikeres böngészős ellenőrzés a csatolt pénzügyi PDF-fel; 11 a generált tesztdokumentummal.** JavaScript-hiba: 0. A rács ellenőrzött nézetében nem maradt függőlegesen levágott cellaszöveg. A 390 px-es mobilnézet nem lóg túl az ablakon.
- Ruff, Python- és Bash-szintaxis, JavaScript-szintaxis, devcontainer JSON ellenőrizve.
- A csatolt PDF 6 oldalából 5 tartalmaz adatot. Az XLSX **5 munkalap / 5 nyomtatási oldal**; az üres hatodik oldalt kihagyja. A PDF- és DOCX-export 6 oldalas maradt.

## A csatolt PDF → Excel ellenőrzése

| Ellenőrzés | Eredmény |
|---|---|
| Részletező rekordok | 80 / 80, egyedi azonosítók |
| Részletező mezők | 10 oszlop minden érintett oldalon |
| Kifizetésoszlop összege | 7 601,49, egyezik a dokumentum végösszegével |
| Üres, fejléccel azonosított mezők | Vendor Invoice Number és Reason megmarad |
| Többsoros nevek és dátumok | Egy cellában, az eredeti rekord sorában |
| Forrásszavak megőrzése | Minden szó megmarad; szövegmódban szó-multihalmaz egyezés mindhárom oszlopstratégiánál |
| Elrendezési ütközés | 0 az alapmódban |
| Logó | Külön XLSX-kép, a szöveg valódi cellatartalom |
| Biztonság | OCR-ből származó, képletnek látszó szöveg nem futtatható képlet |
| Előnézet | A tényleges munkafüzet értékei, méretei, stílusai, összevonásai és képei |
| Letöltés | SHA256-egyezés a jóváhagyott fájllal |

Az összegek és rekordok mérhető adatellenőrzése nem jelent általános pixelazonossági garanciát. Az iLovePDF képernyőképei vizuális referenciák voltak; a program saját, általános koordináta-algoritmust használ.

## Képalapú ellenőrzés

A csatolt PDF első részletező oldalát 300 dpi-s képpé rendereltük, majd a meglévő Tesseract-úton olvastuk be:

| Változat | Pontos tételazonosítók az Excelben | Felismert oszlopok | Felismert szöveg megőrizve az exportban |
|---|---:|---:|---|
| Tiszta képmásolat | 20 / 20 | 10 | Igen |
| Mesterségesen 60%-os kontrasztra halványítva | 20 / 20 | 8 | Igen |

A halvány fejléceknél maradt OCR-/struktúrahiba. Két hibagombos próba eltérő PSM/kontraszt/határparaméterrel valóban új eredményt adott (276 és 307 szó; 7 és 8 oszlop), de ez nem jelentett igazolt minőségjavulást. A rendszer ezért mutatja a módszert és a változást, és megtartja a visszaállítható előző változatot. Az azonosítók egyezése nem a teljes OCR pontossága.

A pytest-csomag ezen felül tiszta, elforgatott, ferde és perspektivikus generált scaneket, magyar karaktereket, forrásmegőrzést, bizonytalan szavakat és exportokat vizsgál. A jól működő első beolvasási út nem változott.

## Vászon és jóváhagyás

Ellenőrzött: kattintásos inline szerkesztés; Enter mentés; Escape piszkozateldobás; állapotfrissítés közbeni piszkozatmegőrzés; korábbi IR-változat visszaállítása; oszlophibás újraszegmentálás; szerkezeti réteg bekapcsolása; középre igazított jóváhagyás; 7 formátumikon; automatikus előnézet; munkalapfülek; cellaérték-megjelenítés; rács/nyomtatási nézet kapcsolás; megváltoztatott beállításoknál elavult jóváhagyás tiltása; jóváhagyás előtti letöltési tiltás; SHA256-azonos automatikus letöltés; PNG/ZIP kiterjesztés; batch ZIP; újratöltés és mobilnézet.

## PDF / Word regresszió

A `reconstructor/extract.py`, `reconstructor/ocr.py`, `reconstructor/preprocess.py`, `reconstructor/render.py` és `studio/output/word.py` bájtra azonos a v5 forráscsomagban lévő változattal. A beolvasási hibagombok Router/utófeldolgozási útja módosult.

A csatolt PDF-ből készült PDF- és DOCX-fájl tényleges renderét ellenőriztük. Mindkettőnél egyezik a nem-whitespace karakterek multihalmaza az IR-rel, hiányzó vagy hozzáadott karakter nélkül. Ez a tartalom megőrzését ellenőrzi, nem a betűalakok pixelazonosságát. Az első és második oldal vizuális ellenőrzésen is átesett. A Microsoft Word saját renderét nem futtattuk.

## Reprodukálás

```bash
RUN_OCR_TESTS=1 RUN_OFFICE_TESTS=1 DOCSTUDIO_SAMPLE_PDF=/teljes/utvonal/remittanceDetails_expedia0717.pdf .venv/bin/python -m pytest tests -q
.venv/bin/python scripts/browser_v6.py
.venv/bin/python scripts/browser_v6.py --sample /teljes/utvonal/remittanceDetails_expedia0717.pdf
```

A saját PDF és a róla készült böngészőképek nincsenek a forráscsomagban. A részletes gépi eredmények az `evidence-v6/` mappában vannak. A korábbi neurális mérések: [V5_TEST_REPORT.md](V5_TEST_REPORT.md). Docker-build, élő Codespaces-indítás, Microsoft Excel/Word és külső Vision API nem futott ebben a környezetben; a mellékelt GitHub Actions folyamat a telepített neurális motorokat és a Docker-indítást is teszteli.
