# Nyilvános példák

Kizárólag mesterséges tesztadat. A `scan-source.png` ismert tesztszöveg, a `scan-reconstructed.pdf` és PNG a végleges neurális motor eredménye. Az `ir-example.json` a hozzá tartozó tényleges IR, az `ir-assets/` a SHA256-hivatkozások tartalma. A `digital-sample.pdf` natív, szintetikus táblázatos PDF.

Az ékezetes tesztszó nem hibátlan; a nyers eredményt szándékosan meghagytuk. A példák nem az OCR általános pontosságát bizonyítják.
