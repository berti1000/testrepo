"""Editable, styled page-layout XLSX from the shared IR.

No full-page screenshot is substituted for cells. Logos are images; recognized
text is written as text/rich text or conservative numeric values. All geometry
is derived from the document, with no vendor/template-specific field names.
"""

import io
import re
from statistics import median

import openpyxl
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.drawing.image import Image
from openpyxl.drawing.spreadsheet_drawing import AbsoluteAnchor
from openpyxl.drawing.xdr import XDRPoint2D, XDRPositiveSize2D
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.page import PageMargins
from reconstructor.geometry import cluster, group_lines, text_of, union
from reconstructor.render import font_family
from studio.layout_grid import export_tables, fragments


def color(value):
    if isinstance(value, int):
        return f"FF{value:06X}"
    return "FF" + "".join(f"{max(0, min(255, round(c * 255))):02X}" for c in value[:3])


def family(word):
    return {"sans": "Arial", "serif": "Times New Roman", "mono": "Courier New"}[
        font_family(word.font)
    ]


def rich(words):
    runs = []
    index = {w.id: w for w in words}
    for i, line in enumerate(group_lines(words)):
        for j, key in enumerate(line.words):
            w = index[key]
            text = ("\n" if i and not j else " " if j else "") + w.text
            runs.append(
                TextBlock(
                    InlineFont(
                        rFont=family(w), sz=w.size, b=w.bold, i=w.italic, color=color(w.color)
                    ),
                    text,
                )
            )
    return CellRichText(runs)


def decimal(raw, locale="auto"):
    """Only decimal amounts; dates, account IDs, 16+ digits and leading zeros survive.

    Locale controls display intent, not source parsing: selecting Hungarian
    output must also correctly parse an English PDF amount such as 7,601.49.
    """
    if locale == "text":
        return None
    t = raw.strip().replace("\u00a0", " ").replace("\u202f", " ")
    if "\n" in t or len(re.sub(r"\D", "", t)) > 15:
        return None
    if re.fullmatch(r"[+-]?\.\d{2}", t):
        return float(t)
    if re.fullmatch(r"[+-]?,\d{2}", t):
        return float(t.replace(",", "."))
    if re.match(r"^[+-]?0\d", t):
        return None
    if re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)\.\d{2}", t):
        return float(t.replace(",", ""))
    if re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:[ .]\d{3})+),\d{2}", t):
        return float(t.replace(" ", "").replace(".", "").replace(",", "."))
    return None


def paragraphs(words):
    parts = sorted(fragments(words), key=lambda p: (min(w.bbox[1] for w in p), p[0].bbox[0]))
    groups = []
    for part in parts:
        box = union([w.bbox for w in part])
        candidates = []
        for i, g in enumerate(groups):
            old = union([w.bbox for w in g])
            aligned = abs(box[0] - old[0]) < 3 or abs(box[2] - old[2]) < 3
            gap = min(w.origin[1] for w in part) - max(w.origin[1] for w in g)
            size = median(w.size for w in part)
            if aligned and 2 < gap < size * 1.75 and max(w.size for w in g) / size < 1.55:
                candidates.append((gap, i))
        if candidates:
            groups[min(candidates)[1]].extend(part)
        else:
            groups.append(part)
    return groups


def effective_box(words):
    x0, _, x1, _ = union([w.bbox for w in words])
    return (
        x0,
        min(w.origin[1] - w.size * 0.94 for w in words),
        x1,
        max(w.origin[1] + w.size * 0.23 for w in words) + 1,
    )


def nearest(edges, v):
    return min(range(len(edges)), key=lambda i: abs(edges[i] - v))


def export(document, numbers="auto", compact=True, mode="layout", sensitivity=0):
    from .sheet_geometry import bands, ranges, grow, offset
    import math

    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    wb._fonts[0] = Font(name="Arial", size=11)
    wb.properties.title = document.filename
    wb.properties.creator = "DocStudio"
    for page in document.pages:
        index = page.index()
        tables = export_tables(page, sensitivity)
        used = {k for t in tables for k in t.words}
        paras = paragraphs(
            [w for w in page.words if w.id not in used and w.text and not w.visual_artifact]
        )
        items = [
            dict(words=g, box=effective_box(g), raw=text_of([w.id for w in g], index), table=False)
            for g in paras
        ]
        for t in tables:
            for c in t.cells:
                words = [index[k] for k in c.words]
                raw = c.override if c.override is not None else text_of(c.words, index)
                items.append(
                    dict(words=words, box=c.bbox, raw=raw, table=True, override=c.override)
                )
        pictures = [
            im
            for im in page.images
            if im.get("data") and not im.get("large") and not im.get("word_id")
        ]
        if not items and not pictures:
            continue
        ws = wb.create_sheet(f"{page.number}. oldal")
        extents = [p["box"] for p in items] + [p["bbox"] for p in pictures]
        bounds = union(extents)
        primary = max(tables, key=lambda t: len(t.cells), default=None)
        page_table = primary and primary.bbox[3] - primary.bbox[1] > page.height * 0.35
        xs = list(primary.x_edges) if primary else [bounds[0] - 2, bounds[2] + 3]
        if not page_table:
            for p in items:
                x = p["box"][0] - 1
                if not p["table"] and min(abs(e - x) for e in xs) > 14:
                    xs.append(x)
        xs = cluster(xs + [x for t in tables for x in t.x_edges], 3)
        xs[0] = min(xs[0], bounds[0] - 2)
        xs[-1] = max(xs[-1], bounds[2] + 3)
        if len(xs) < 2:
            xs = [0, page.width]
        rows = bands(items)
        if not rows:
            rows = [[bounds[1], bounds[3]]]
        rows[0][0] = min(rows[0][0], bounds[1])
        rows[-1][1] = max(rows[-1][1], bounds[3])
        # Preserve vertical extent. Empty space belongs to the previous band,
        # never to a series of unusable one-point worksheet rows.
        ys = [r[0] for r in rows] + [rows[-1][1]]
        heights = [max(18, ys[i + 1] - ys[i]) for i in range(len(rows))]
        widths = [max(14, b - a) for a, b in zip(xs, xs[1:])]
        ranges(items, xs, rows)
        grow(items, widths, heights)
        occupied = {}
        for item in items:
            if not item["raw"]:
                continue
            r = item["row"]
            c0, c1 = item["cols"]
            collision = next((occupied[(r, c)] for c in range(c0, c1) if (r, c) in occupied), None)
            if collision is not None:
                collision["raw"] += "\n" + item["raw"]
                collision["words"] += item["words"]
                item["skip"] = True
                heights[r] += max((w.size for w in item["words"]), default=10) * 1.4 + 6
            else:
                for c in range(c0, c1):
                    occupied[(r, c)] = item
        # Combining fragments can add lines and width requirements. Measure the
        # final cell content too; Excel cannot AutoFit merged cells reliably.
        grow([item for item in items if not item.get("skip")], widths, heights)
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = (w * 96 / 72 - 5) / 7
        # Excel limits each row to 409 pt. Split oversized bands, not their text.
        rowmap = []
        rowcount = 0
        for height in heights:
            n = max(1, math.ceil(height / 409))
            rowmap.append((rowcount + 1, rowcount + n))
            for j in range(n):
                ws.row_dimensions[rowcount + j + 1].height = height / n
            rowcount += n
        for item in items:
            if item.get("skip") or not item["raw"]:
                continue
            r0, r1 = rowmap[item["row"]]
            c0, c1 = item["cols"]
            words = item["words"]
            raw = item["raw"]
            cell = ws.cell(r0, c0 + 1)
            value = decimal(raw, numbers)
            cell.value = (
                value
                if value is not None
                else (rich(words) if words and item.get("override") is None else raw)
            )
            if value is None:
                cell.data_type = "s"
            else:
                cell.number_format = "#,##0.00"
            sample = max(words, key=lambda w: len(w.text), default=None)
            cell.font = Font(
                name=family(sample) if sample else "Arial",
                sz=sample.size if sample else 10,
                b=sample.bold if sample else False,
                i=sample.italic if sample else False,
                color=color(sample.color if sample else 0),
            )
            right = value is not None or (
                not item["table"] and abs(item["box"][2] - bounds[2]) < 12
            )
            cell.alignment = Alignment(
                horizontal="right" if right else "left",
                vertical="top",
                wrap_text=True,
                shrink_to_fit=False,
            )
            if item["table"]:
                edge = Side(style="hair", color="FFDADDE0")
                cell.border = Border(left=edge, right=edge, top=edge, bottom=edge)
            if c1 - c0 > 1 or r1 > r0:
                ws.merge_cells(start_row=r0, end_row=r1, start_column=c0 + 1, end_column=c1)
        for path in page.paths:
            b = path.get("bbox")
            if b is None or path.get("fill") is None or b[3] - b[1] < 3:
                continue
            if not any(it[0] == "re" for it in path.get("items", [])):
                continue
            fill = PatternFill("solid", fgColor=color(path["fill"]))
            for i, row in enumerate(rows):
                if b[1] - 2 <= (row[0] + row[1]) / 2 <= b[3] + 2:
                    for c in range(len(widths)):
                        if b[0] <= (xs[c] + xs[c + 1]) / 2 <= b[2]:
                            for r in range(rowmap[i][0], rowmap[i][1] + 1):
                                ws.cell(r, c + 1).fill = fill
        for rule in page.rules:
            if rule["axis"] != "h":
                continue
            edge = nearest(ys, rule["pos"])
            if edge >= len(rows) or abs(ys[edge] - rule["pos"]) > 18:
                continue
            side = Side(
                style="hair" if rule.get("width", 0.5) < 0.8 else "thin",
                color=color(rule.get("color") or (0.65, 0.65, 0.65)),
            )
            from copy import copy

            for c in range(len(widths)):
                if rule["start"] <= xs[c + 1] and rule["end"] >= xs[c]:
                    cell = ws.cell(rowmap[edge][0], c + 1)
                    border = copy(cell.border)
                    border.top = side
                    cell.border = border
        for im in pictures:
            b = im["bbox"]
            pic = Image(io.BytesIO(im["data"]))
            pic.anchor = AbsoluteAnchor(
                pos=XDRPoint2D(
                    round(offset(b[0], xs, widths) * 12700),
                    round(offset(b[1], ys, heights) * 12700),
                ),
                ext=XDRPositiveSize2D(round((b[2] - b[0]) * 12700), round((b[3] - b[1]) * 12700)),
            )
            ws.add_image(pic)
        ws.sheet_view.showGridLines = True
        ws.sheet_view.zoomScale = 100
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = "portrait" if page.width <= page.height else "landscape"
        ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.page_margins = PageMargins(
            left=0.15, right=0.15, top=0.15, bottom=0.15, header=0, footer=0
        )
        ws.print_area = f"A1:{openpyxl.utils.get_column_letter(len(widths))}{rowcount}"
        if primary:
            row = next((i for i, r in enumerate(rows) if r[0] >= primary.y_edges[1] - 0.6), 0)
            ws.freeze_panes = f"A{rowmap[row][0]}"
    if not wb.sheetnames:
        wb.create_sheet("Üres dokumentum")
    stream = io.BytesIO()
    wb.save(stream)
    return stream.getvalue()
