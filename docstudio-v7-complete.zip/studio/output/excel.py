"""Clean semantic table grids; no page-layout spacer columns."""

import io
import math
import re
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from reconstructor.export import cell_text
from reconstructor.geometry import group_lines, text_of


def style(ws):
    ws.freeze_panes = "A2"
    for col in ws.columns:
        letter = openpyxl.utils.get_column_letter(col[0].column)
        width = min(
            80,
            max(
                10,
                max((len(line) for c in col for line in str(c.value or "").split("\n")), default=8)
                + 2,
            ),
        )
        ws.column_dimensions[letter].width = width
    merged = {(r.min_row, r.min_col): r for r in ws.merged_cells.ranges}
    heights = {r: 18.0 for r in range(1, ws.max_row + 1)}
    for row in ws:
        for cell in row:
            if cell.value is None:
                continue
            region = merged.get((cell.row, cell.column))
            last_col = region.max_col if region else cell.column
            last_row = region.max_row if region else cell.row
            width = sum(
                ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width
                for c in range(cell.column, last_col + 1)
            )
            lines = sum(
                max(1, math.ceil(len(line) / max(8, width * 0.9)))
                for line in str(cell.value).split("\n")
            )
            height = min(409, (lines * 14 + 4) / (last_row - cell.row + 1))
            for r in range(cell.row, last_row + 1):
                heights[r] = max(heights[r], height)
    for r, height in heights.items():
        ws.row_dimensions[r].height = height
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0


def export(document, numbers="auto", merge=True, compact=True, mode="layout", sensitivity=0):
    if mode != "semantic":
        from .excel_layout import export as layout_export

        return layout_export(document, numbers, compact, mode, sensitivity)
    from copy import deepcopy
    from studio.layout_grid import export_tables

    document = deepcopy(document)
    for page in document.pages:
        tables = export_tables(page, sensitivity)
        if tables:
            page.blocks = tables
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    for page in document.pages:
        assigned = set()
        tables = [b for b in page.blocks if b.kind == "table"]
        for ti, block in enumerate(tables, 1):
            ws = wb.create_sheet(f"{page.number}. oldal · {ti}. tábla")
            cells = [c for c in block.cells if cell_text(c, page).strip()]
            rows = (
                sorted({r for c in cells for r in range(c.row, c.row + c.rowspan)})
                if compact
                else list(range(max((c.row + c.rowspan for c in block.cells), default=1)))
            )
            cols = (
                sorted({n for c in cells for n in range(c.col, c.col + c.colspan)})
                if compact
                else list(range(max((c.col + c.colspan for c in block.cells), default=1)))
            )
            rm = {v: i + 1 for i, v in enumerate(rows)}
            cm = {v: i + 1 for i, v in enumerate(cols)}
            for cell in cells:
                assigned.update(cell.words)
                if cell.row not in rm or cell.col not in cm:
                    continue
                r, c = rm[cell.row], cm[cell.col]
                raw = cell_text(cell, page)
                from .excel_layout import decimal

                value = decimal(raw, numbers)
                if value is None:
                    # number_value returns None for preserved text, not an empty cell.
                    value = raw
                    if numbers != "text" and re.fullmatch(r"[+-]?(?:0|[1-9]\d{0,14})", raw.strip()):
                        value = int(raw.strip())
                out = ws.cell(r, c, value)
                if isinstance(value, str):
                    out.data_type = "s"
                out.alignment = Alignment(wrap_text=True, vertical="top")
                out.font = Font(name="Liberation Sans", size=10)
                if r <= block.header_rows:
                    out.font = Font(name="Liberation Sans", size=10, bold=True, color="FFFFFF")
                    out.fill = PatternFill("solid", fgColor="173D38")
                rs = [rm[n] for n in range(cell.row, cell.row + cell.rowspan) if n in rm]
                cs = [cm[n] for n in range(cell.col, cell.col + cell.colspan) if n in cm]
                if merge and rs and cs and (len(rs) > 1 or len(cs) > 1):
                    ws.merge_cells(start_row=r, start_column=c, end_row=max(rs), end_column=max(cs))
            style(ws)
        rest = [w for w in page.words if w.id not in assigned]
        if rest or not tables:
            ws = wb.create_sheet(f"{page.number}. oldal · szöveg")
            index = page.index()
            for i, line in enumerate(group_lines(rest), 1):
                c = ws.cell(i, 1, text_of(line.words, index, False))
                c.data_type = "s"
                c.alignment = Alignment(wrap_text=True, vertical="top")
            style(ws)
    if not wb.sheetnames:
        wb.create_sheet("Üres dokumentum")
    stream = io.BytesIO()
    wb.save(stream)
    return stream.getvalue()


def preview(data):
    """Read the generated artifact, including its styles, sizes and drawing anchors.

    The browser does not independently rebuild the document. It renders this
    workbook model, while LibreOffice supplies a separate print preview.
    """
    import base64
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    from openpyxl.cell.text import InlineFont
    from openpyxl.drawing.spreadsheet_drawing import AbsoluteAnchor

    def rgb(c, default):
        return "#" + c.rgb[-6:] if c and c.type == "rgb" else default

    def font(f):
        return dict(
            font=f.rFont if isinstance(f, InlineFont) else f.name,
            size=f.sz or 11,
            bold=bool(f.b),
            italic=bool(f.i),
            color=rgb(f.color, "#000000"),
        )

    def style(c):
        return dict(
            **font(c.font),
            fill=rgb(c.fill.fgColor, "#ffffff") if c.fill.patternType else None,
            align=c.alignment.horizontal or ("right" if c.data_type == "n" else "left"),
            vertical=c.alignment.vertical or "bottom",
            wrap=bool(c.alignment.wrap_text),
            number_format=c.number_format,
            borders={
                k: {
                    "style": getattr(c.border, k).style,
                    "color": rgb(getattr(c.border, k).color, "#dadde0"),
                }
                for k in ("top", "bottom", "left", "right")
                if getattr(c.border, k) and getattr(c.border, k).style
            },
        )

    wb = openpyxl.load_workbook(io.BytesIO(data), data_only=False, rich_text=True)
    sheets = []
    for s in wb:
        widths = [
            max(1, int(s.column_dimensions[openpyxl.utils.get_column_letter(i)].width * 7 + 5))
            for i in range(1, s.max_column + 1)
        ]
        heights = [
            (s.row_dimensions[i].height or s.sheet_format.defaultRowHeight or 15) * 96 / 72
            for i in range(1, s.max_row + 1)
        ]
        styles, runs, imgs = {}, {}, []
        for row in s:
            for c in row:
                if c.has_style:
                    styles[c.coordinate] = style(c)
                if isinstance(c.value, CellRichText):
                    runs[c.coordinate] = [
                        dict(text=r.text, **font(r.font))
                        if isinstance(r, TextBlock)
                        else dict(text=str(r))
                        for r in c.value
                    ]
        for im in s._images:
            a = im.anchor
            if isinstance(a, AbsoluteAnchor):
                x, y = a.pos.x / 9525, a.pos.y / 9525
            else:
                x = sum(widths[: a._from.col]) + a._from.colOff / 9525
                y = sum(heights[: a._from.row]) + a._from.rowOff / 9525
            imgs.append(
                dict(
                    x=x,
                    y=y,
                    width=a.ext.cx / 9525 if hasattr(a, "ext") else im.width,
                    height=a.ext.cy / 9525 if hasattr(a, "ext") else im.height,
                    src="data:image/"
                    + im.format
                    + ";base64,"
                    + base64.b64encode(im._data()).decode(),
                )
            )
        sheets.append(
            dict(
                name=s.title,
                rows=[
                    [str(c.value) if isinstance(c.value, CellRichText) else c.value for c in row]
                    for row in s
                ],
                types=[[c.data_type for c in row] for row in s],
                merges=[str(m) for m in s.merged_cells.ranges],
                widths=widths,
                heights=heights,
                styles=styles,
                runs=runs,
                images=imgs,
                freeze=s.freeze_panes,
            )
        )
    return sheets
