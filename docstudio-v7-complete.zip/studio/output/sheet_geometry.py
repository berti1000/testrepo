"""Measured, monotonic Office dimensions. Merged cells cannot rely on AutoFit."""

from bisect import bisect_right
from reportlab.pdfbase import pdfmetrics
from reconstructor.render import font_for
from reconstructor.geometry import group_lines


def bands(items):
    result = []
    for item in sorted(items, key=lambda p: p["box"][1]):
        a, b = item["box"][1], item["box"][3]
        if result and a < result[-1][1] - 2:
            result[-1][1] = max(result[-1][1], b)
        else:
            result.append([a, b])
    return result


def ranges(items, xs, rows):
    for item in items:
        box = item["box"]
        table = item.get("table", False)
        item["row"] = min(range(len(rows)), key=lambda i: abs(rows[i][0] - box[1]))
        if not table:
            item["row"] = max(0, bisect_right([r[0] for r in rows], box[1] + 0.6) - 1)
        c0 = min(range(len(xs) - 1), key=lambda i: abs(xs[i] - box[0]))
        if table:
            c1 = max(c0 + 1, min(range(1, len(xs)), key=lambda i: abs(xs[i] - box[2])))
        else:
            c1 = max(c0 + 1, min(len(xs) - 1, bisect_right(xs, box[2] + 1)))
        item["cols"] = [c0, c1]
    for r in range(len(rows)):
        members = sorted((p for p in items if p["row"] == r), key=lambda p: p["box"][0])
        for left, right in zip(members, members[1:]):
            if left["cols"][1] > right["cols"][0] and right["box"][0] > left["box"][0] + 2:
                edge = max(left["cols"][0] + 1, right["cols"][0])
                if edge >= len(xs) - 1:
                    # No column remains to the right. Keep the bounded overlap;
                    # the exporter combines these fragments without losing text.
                    continue
                left["cols"][1] = edge
                right["cols"][0] = edge
                right["cols"][1] = max(edge + 1, right["cols"][1])


def measure(words, raw):
    if not words:
        return max((len(t) * 5.5 for t in raw.splitlines()), default=10), max(
            1, len(raw.splitlines())
        ) * 14 + 5
    index = {w.id: w for w in words}
    widths = []
    heights = []
    for line in group_lines(words):
        group = [index[k] for k in line.words]
        width = sum(pdfmetrics.stringWidth(w.text, font_for(w), w.size) for w in group)
        width += sum(pdfmetrics.stringWidth(" ", font_for(w), w.size) for w in group[:-1])
        widths.append(width)
        heights.append(max(w.size for w in group) * 1.4)
    return max(widths, default=10) * 1.06 + 8, sum(heights) + 6


def grow(items, widths, heights):
    for item in items:
        c0, c1 = item["cols"]
        c0 = max(0, min(len(widths) - 1, c0))
        c1 = max(c0 + 1, min(len(widths), c1))
        item["cols"] = [c0, c1]
        need, height = measure(item["words"], item["raw"])
        have = sum(widths[c0:c1])
        if need > have:
            for c in range(c0, c1):
                widths[c] += (need - have) * widths[c] / max(1, have)
        heights[item["row"]] = max(heights[item["row"]], height, 18)


def offset(value, edges, dimensions):
    i = max(0, min(len(dimensions) - 1, bisect_right(edges, value) - 1))
    return sum(dimensions[:i]) + dimensions[i] * max(
        0, (value - edges[i]) / max(0.01, edges[i + 1] - edges[i])
    )
