"""Editable positioned DOCX frames, or explicit flowing-text mode."""

import copy
import io
from lxml import etree
from docx import Document
from docx.shared import Pt
from docx.enum.section import WD_SECTION_START
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from collections import defaultdict
from statistics import median
from reconstructor.ocr import pilfont
from reconstructor.render import font_family

NS = {
    "v": "urn:schemas-microsoft-com:vml",
    "w10": "urn:schemas-microsoft-com:office:word",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing",
}


def el(prefix, name, attrs=None):
    node = etree.Element("{" + NS[prefix] + "}" + name)
    for k, v in (attrs or {}).items():
        node.set(k, str(v))
    return node


def run(para, text, word, scale):
    r = OxmlElement("w:r")
    pr = OxmlElement("w:rPr")
    f = OxmlElement("w:rFonts")
    family = {"serif": "Times New Roman", "sans": "Arial", "mono": "Courier New"}[
        font_family(word.font)
    ]
    for key in ("ascii", "hAnsi", "cs"):
        f.set(qn("w:" + key), family)
    pr.append(f)
    size = OxmlElement("w:sz")
    size.set(qn("w:val"), str(max(4, round(word.size * 2))))
    pr.append(size)
    if word.bold:
        pr.append(OxmlElement("w:b"))
    if word.italic:
        pr.append(OxmlElement("w:i"))
    width = OxmlElement("w:w")
    width.set(qn("w:val"), str(max(20, min(300, round(scale)))))
    pr.append(width)
    color = OxmlElement("w:color")
    color.set(qn("w:val"), f"{word.color:06x}")
    pr.append(color)
    r.append(pr)
    t = OxmlElement("w:t")
    t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    t.text = text
    r.append(t)
    para.append(r)


def textbox(anchor, words, ordinal, page):
    words = sorted(words, key=lambda w: w.bbox[0])
    left = min(w.bbox[0] for w in words)
    # Exact line spacing in the supported LibreOffice renderer places the baseline
    # at about 0.84 em. Anchor to the IR baseline, not to the OCR ink rectangle.
    top = median(w.origin[1] for w in words) - 0.84 * max(w.size for w in words)
    height = max(max(w.size * 1.6 for w in words), max(w.bbox[3] for w in words) - top + 3)
    # Transparent frames extend to the page edge so font-metric differences
    # cannot wrap a fitted OCR label into another printed line.
    width = max(2, page.width - left)
    r = OxmlElement("w:r")
    pict = OxmlElement("w:pict")
    shape = el(
        "v",
        "rect",
        {
            "id": f"text_{ordinal}",
            "stroked": "f",
            "filled": "f",
            "style": f"position:absolute;margin-left:{left:.3f}pt;margin-top:{top:.3f}pt;width:{width:.3f}pt;height:{height:.3f}pt;z-index:2;mso-position-horizontal-relative:page;mso-position-vertical-relative:page",
        },
    )
    box = el(
        "v",
        "textbox",
        {"inset": "0pt,0pt,0pt,0pt", "style": "mso-fit-shape-to-text:t;mso-wrap-style:none"},
    )
    content = OxmlElement("w:txbxContent")
    para = OxmlElement("w:p")
    pr = OxmlElement("w:pPr")
    spacing = OxmlElement("w:spacing")
    for k, v in {
        "before": 0,
        "after": 0,
        "line": round(max(w.size for w in words) * 20 * 1.05),
        "lineRule": "exact",
    }.items():
        spacing.set(qn("w:" + k), str(v))
    pr.append(spacing)
    para.append(pr)
    cursor = left
    for i, w in enumerate(words):
        f = pilfont(font_family(w.font), w.bold)
        natural = f.getlength(w.text) / 100 * w.size
        scale = (
            w.render_scale
            if w.render_scale is not None
            else (w.bbox[2] - w.bbox[0]) / max(0.1, natural)
        )
        if i:
            gap = max(0.1, w.bbox[0] - cursor)
            space = f.getlength(" ") / 100 * w.size
            count = max(1, round(gap / max(0.5, space)))
            run(para, " " * min(200, count), w, 100 * gap / max(0.1, count * space))
        run(para, w.text, w, scale * 100)
        cursor = w.bbox[0] + natural * scale
    content.append(para)
    box.append(content)
    shape.append(box)
    shape.append(el("w10", "wrap", {"type": "none"}))
    pict.append(shape)
    r.append(pict)
    anchor._p.append(r)


def graphics(anchor, page):
    if not (page.images or page.paths or page.rules):
        return
    import fitz
    from reconstructor.model import Document as Runtime
    from reconstructor.render import reconstructed_pdf

    p = copy.deepcopy(page)
    p.words = []
    p.blocks = []
    with fitz.open(
        stream=reconstructed_pdf(Runtime("graphics", "", b"", pages=[p])), filetype="pdf"
    ) as pdf:
        png = pdf[0].get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False).tobytes("png")
    inline = (
        anchor.add_run()
        .add_picture(io.BytesIO(png), width=Pt(page.width), height=Pt(page.height))
        ._inline
    )
    floating = el(
        "wp",
        "anchor",
        {
            "distT": 0,
            "distB": 0,
            "distL": 0,
            "distR": 0,
            "simplePos": 0,
            "relativeHeight": 0,
            "behindDoc": 1,
            "locked": 0,
            "layoutInCell": 0,
            "allowOverlap": 1,
        },
    )
    floating.append(el("wp", "simplePos", {"x": 0, "y": 0}))
    for tag in ("positionH", "positionV"):
        pos = el("wp", tag, {"relativeFrom": "page"})
        off = el("wp", "posOffset")
        off.text = "0"
        pos.append(off)
        floating.append(pos)
    floating.append(copy.deepcopy(inline.find(qn("wp:extent"))))
    floating.append(el("wp", "wrapNone"))
    for child in inline:
        if child.tag != qn("wp:extent"):
            floating.append(copy.deepcopy(child))
    inline.getparent().replace(inline, floating)


def export(document, mode="positioned", margin=0):
    if mode == "flow":
        from reconstructor.export import word_document

        return word_document(document)
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(1)
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.space_before = Pt(0)
    normal.paragraph_format.line_spacing = Pt(1)
    ordinal = 0
    for i, page in enumerate(document.pages):
        section = doc.sections[0] if i == 0 else doc.add_section(WD_SECTION_START.NEW_PAGE)
        section.page_width = Pt(page.width)
        section.page_height = Pt(page.height)
        section.left_margin = section.right_margin = section.top_margin = section.bottom_margin = (
            Pt(margin)
        )
        section.header_distance = section.footer_distance = Pt(0)
        anchor = doc.add_paragraph()
        anchor.paragraph_format.line_spacing = Pt(1)
        graphics(anchor, page)
        words = [w for w in page.words if not w.visual_artifact or w.reviewed]
        by_line = defaultdict(list)
        for w in words:
            by_line[w.line_hint or w.id].append(w)
        groups = [[w] for w in words] if mode == "precise" else list(by_line.values())
        for group in groups:
            ordinal += 1
            textbox(anchor, group, ordinal, page)
    stream = io.BytesIO()
    doc.save(stream)
    return stream.getvalue()
