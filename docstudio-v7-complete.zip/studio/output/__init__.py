"""Every editable output consumes a selected IR revision."""
