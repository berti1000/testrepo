import hashlib
import json
import io
import zipfile
from pathlib import Path
from typing import Literal
import fitz
from pydantic import BaseModel, ConfigDict, Field
from reconstructor.locking import serialized
from . import word, excel
from ..ir import to_runtime
from ..office import convert_pdf
from ..workflow import OUTPUT_ERRORS


class OutputOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")
    format: Literal["pdf", "docx", "xlsx", "png", "json", "html", "txt"] = "docx"
    word_mode: Literal["positioned", "precise", "flow"] = "positioned"
    margin: float = Field(default=0, ge=0, le=36)
    numbers: Literal["auto", "text", "hu", "en"] = "auto"
    merge: bool = True
    compact: bool = True
    excel_mode: Literal["layout", "semantic"] = "layout"
    grid_sensitivity: int = Field(default=0, ge=0, le=2)


def fallback(options, error):
    if error not in OUTPUT_ERRORS.get(options.format, {}):
        raise ValueError("A hibajelzés nem ehhez a formátumhoz tartozik")
    result = options.model_copy(deep=True)
    if options.format == "docx":
        if error == "drift":
            result.word_mode = "positioned" if options.word_mode == "precise" else "precise"
        elif error == "margins":
            result.margin = 0
            result.word_mode = "positioned"
        elif error == "flow":
            result.word_mode = "flow"
    elif options.format == "xlsx":
        if error == "numbers":
            result.numbers = (
                "auto" if options.numbers == "text" else "hu" if options.numbers != "hu" else "en"
            )
        elif error == "columns":
            result.excel_mode = "layout"
            result.grid_sensitivity = (options.grid_sensitivity + 1) % 3
        else:
            result.excel_mode = "semantic" if options.excel_mode == "layout" else "layout"
            result.merge = not options.merge
            result.compact = not options.compact if options.excel_mode == "semantic" else True
    return result


@serialized
def generate(ir, store, options, folder):
    from reconstructor.render import reconstructed_pdf, standalone_html
    from reconstructor.export import plain_text

    doc = to_runtime(ir, store)
    if options.format == "docx":
        data = word.export(doc, options.word_mode, options.margin)
    elif options.format == "xlsx":
        data = excel.export(
            doc,
            options.numbers,
            options.merge,
            options.compact,
            options.excel_mode,
            options.grid_sensitivity,
        )
    elif options.format == "pdf":
        data = reconstructed_pdf(doc)
    elif options.format == "png":
        pngs = []
        with fitz.open(stream=reconstructed_pdf(doc), filetype="pdf") as pdf:
            for page in pdf:
                pngs.append(page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False).tobytes("png"))
        if len(pngs) == 1:
            data = pngs[0]
        else:
            out = io.BytesIO()
            with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
                for i, png in enumerate(pngs, 1):
                    z.writestr(f"page-{i:03}.png", png)
            data = out.getvalue()
    elif options.format == "json":
        data = ir.dump()
    elif options.format == "txt":
        data = plain_text(doc)
    else:
        data = standalone_html(doc)
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    extension = "zip" if options.format == "png" and len(doc.pages) > 1 else options.format
    path = folder / ("document." + extension)
    path.write_bytes(data)
    info = {
        "filename": path.name,
        "format": options.format,
        "sha256": hashlib.sha256(data).hexdigest(),
        "ir_revision": ir.revision,
        "options": options.model_dump(),
        "preview_pages": 0,
        "warnings": [],
        "preview_kind": "actual-file",
    }
    if options.format in ("docx", "xlsx", "pdf"):
        pdf = data if options.format == "pdf" else convert_pdf(data, "." + options.format)
        (folder / "preview.pdf").write_bytes(pdf)
        with fitz.open(stream=pdf, filetype="pdf") as rendered:
            if len(rendered) > 300:
                raise ValueError("Az export több mint 300 oldalt hozott létre")
            info["preview_pages"] = len(rendered)
            for i, page in enumerate(rendered):
                page.get_pixmap(
                    matrix=fitz.Matrix(1400 / page.rect.width, 1400 / page.rect.width), alpha=False
                ).save(folder / f"page-{i + 1}.png")
        if options.format == "docx":
            info["warnings"].append(
                "LibreOffice-render; a Microsoft Word tördelése és betűkészlete eltérhet. Pixelazonosság nem garantált."
            )
        if options.format == "xlsx":
            info["sheets"] = excel.preview(data)
            info["warnings"].append(
                "A rács a kész XLSX celláit, méreteit, stílusait és képeit mutatja. "
                "A nyomtatási nézet LibreOffice-render; az Excel betűtördelése eltérhet."
            )
            info["strategy"] = f"{options.excel_mode} · rács {options.grid_sensitivity + 1} · " + (
                "tömörített" if options.compact else "eredeti térközök"
            )
    elif options.format == "png":
        info["preview_pages"] = len(pngs)
        for i, png in enumerate(pngs, 1):
            (folder / f"page-{i}.png").write_bytes(png)
        if len(pngs) > 1:
            info["warnings"].append(
                "Többoldalas PNG-export: az oldalképek egy ZIP-fájlban töltődnek le."
            )
    else:
        info["preview_kind"] = "text"
        info["text_preview"] = data.decode("utf-8")[:300000]
    (folder / "metadata.json").write_text(json.dumps(info, ensure_ascii=False, default=str))
    return info
