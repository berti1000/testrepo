"""Strategies -> one IR. Page retries preserve every other page byte-for-byte in IR."""

import time
from dataclasses import replace
from pathlib import Path
import fitz
from reconstructor.model import Options, fingerprint
from reconstructor.extract import read_document, render_page
from reconstructor.layout import build_layout
from reconstructor.locking import serialized
from .ir import from_runtime, to_runtime
from .office import convert_pdf, spreadsheet_document
from .profiling import profile
from .router import Router


def options_for(strategy, settings):
    return Options(
        ocr_engine="paddle" if strategy.ocr == "paddle" else "tesseract",
        contrast_factor=strategy.contrast,
        gap_factor=strategy.gap_factor,
        psm=strategy.psm,
        dpi=settings.get("dpi", 300),
        quality=settings.get("quality", "balanced"),
        deskew=settings.get("deskew", True),
        orientation=settings.get("orientation", True),
        perspective=settings.get("perspective", False),
        rotation=settings.get("rotation", 0),
        max_pages=60,
        visual_fallback=False,
    )


def finish(doc, strategy, error=None, verify_ocr=False):
    from .engines.tables import tatr, separate_columns

    with fitz.open(stream=doc.normalized_pdf, filetype="pdf") as pdf:
        for i, page in enumerate(doc.pages):
            page.diagnostics["strategy"] = strategy.dict()
            page.diagnostics["ocr_actual"] = strategy.ocr if page.ocr_ran else "native"
            if strategy.warning:
                page.warnings.append(strategy.warning)
            if strategy.ocr == "vision":
                from .engines.vision import recognize

                page.words = recognize(render_page(pdf[i], 200, 24_000_000), page, error)
                from reconstructor.graphics import preserve_graphics

                preserve_graphics(render_page(pdf[i], 200, 24_000_000), page)
                from reconstructor.typography import constrain_ocr_geometry

                constrain_ocr_geometry(page)
                build_layout(page, pdf[i], Options())
                page.diagnostics["ocr_actual"] = "vision"
            if strategy.table == "tatr":
                try:
                    tatr(render_page(pdf[i], 150, 24_000_000), page)
                except Exception as exc:
                    page.warnings.append(
                        f"TATR hiba; geometriai eredmény maradt: {type(exc).__name__}: {str(exc)[:120]}"
                    )
                    page.diagnostics["table_actual"] = "geometry-after-tatr-failure"
            elif strategy.table == "columns":
                separate_columns(page, strategy.gap_factor)
            elif strategy.table.startswith("columns-"):
                from .layout_grid import rebuild

                rebuild(page, int(strategy.table.rsplit("-", 1)[1]))
            elif strategy.table == "geometry-strict":
                build_layout(page, pdf[i], Options(gap_factor=0.55, unruled_tables=True))
            if verify_ocr and strategy.ocr == "paddle" and page.ocr_ran:
                try:
                    from .engines.verify import crosscheck

                    crosscheck(render_page(pdf[i], 250, 24_000_000), page)
                except Exception as exc:
                    page.warnings.append(
                        f"A másodlagos OCR-ellenőrzés nem futott le: {type(exc).__name__}"
                    )


@serialized
def ingest(data, filename, store, settings=None, progress=None):
    settings = settings or {}
    p = profile(data, filename, settings.get("password", ""))
    started = time.monotonic()
    if progress:
        progress(0.06, "Profil: " + p.label)
    if Path(filename).suffix.lower() == ".xlsx":
        doc = spreadsheet_document(data, filename)
        ir = from_runtime(doc, store, p)
        ir.profile.pages = len(doc.pages)
        ir.provenance = [
            {
                "operation": "import",
                "engine": "openpyxl-native",
                "seconds": round(time.monotonic() - started, 2),
            }
        ]
        return ir
    original = data
    if Path(filename).suffix.lower() == ".docx":
        data = convert_pdf(data, ".docx")
    strategy = Router().choose(
        p,
        requested=settings.get("engine", "auto"),
        contrast=settings.get("contrast", 1),
        gap_factor=settings.get("gap_factor", 0.95),
        consent=settings.get("consent", False),
    )
    opt = options_for(strategy, settings)
    opt.ocr = (
        "auto"
        if settings.get("engine", "auto") == "auto"
        else "never"
        if strategy.ocr == "native"
        else "always"
    )
    doc = read_document(
        data,
        filename if data is original else "converted.pdf",
        opt,
        settings.get("password", ""),
        (
            lambda a, b: progress(
                0.08 + 0.8 * a / max(1, b), f"Beolvasás: {a:.1f}/{b} oldal · {strategy.ocr}"
            )
        )
        if progress
        else None,
    )
    doc.filename = filename
    doc.original_input = original
    doc.sha256 = fingerprint(original)
    text = " ".join(w.text for pg in doc.pages for w in pg.words).lower()
    if p.kind in ("scanned", "mixed") and any(
        s in text for s in ("számla", "szamla", "bruttó", "invoice", "nyugta")
    ):
        p.kind = "financial"
        p.label = "Szkennelt / pénzügyi"
        p.reasons.append("Az OCR-tartalom pénzügyi dokumentumra utal")
        if Router().has("tatr") and strategy.table == "geometry":
            strategy = replace(
                strategy,
                table="tatr",
                id=strategy.id + ":post-profile-tatr",
                reason=strategy.reason + "; OCR utáni pénzügyi profil: TATR",
            )
    finish(doc, strategy, verify_ocr=settings.get("verify_ocr", False))
    ir = from_runtime(doc, store, p)
    ir.profile.pages = len(doc.pages)
    ir.provenance = [
        {
            "operation": "import",
            "strategy": strategy.dict(),
            "seconds": round(time.monotonic() - started, 2),
        }
    ]
    return ir


@serialized
def retry_page(ir, store, page_number, error, attempt, settings=None, progress=None):
    settings = settings or {}
    if not 1 <= page_number <= len(ir.pages):
        raise ValueError("Nincs ilyen oldal")
    previous = ir.pages[page_number - 1]
    current = previous.diagnostics.get("strategy", {}).get("ocr", "native")
    strategy = Router().choose(
        ir.profile,
        error,
        attempt,
        current,
        contrast=settings.get("contrast", 1),
        gap_factor=settings.get("gap_factor", 0.95),
        requested=settings.get("engine", "auto"),
        consent=settings.get("consent", False),
    )
    started = time.monotonic()
    runtime = to_runtime(ir, store)
    if strategy.ocr == "native" and previous.ocr_ran:
        raise ValueError(
            "Ez az oldal képalapú: a natív szövegkinyeréshez nincs betűréteg. Válassz OCR-motort."
        )
    with fitz.open(stream=runtime.normalized_pdf, filetype="pdf") as src, fitz.open() as one:
        one.insert_pdf(src, from_page=page_number - 1, to_page=page_number - 1)
        opt = options_for(
            strategy, {**settings, "orientation": False, "deskew": False, "perspective": False}
        )
        opt.ocr = "never" if strategy.ocr == "native" else "always"
        local = read_document(
            one.tobytes(),
            "page.pdf",
            opt,
            progress=(
                lambda a, b: progress(
                    0.1 + 0.75 * a / max(1, b), "Oldal újraalkotása · " + strategy.ocr
                )
            )
            if progress
            else None,
        )
    finish(local, strategy, error, verify_ocr=settings.get("verify_ocr", False))
    page = local.pages[0]
    from collections import Counter

    def word_signature(p):
        return Counter((w.text, tuple(round(v, 1) for v in w.bbox)) for w in p.words)

    def structure_signature(p):
        index = p.index()
        return [
            (
                b.kind,
                tuple(round(v, 1) for v in b.bbox),
                [(c.row, c.col, tuple(index[k].text for k in c.words)) for c in b.cells],
            )
            for b in p.blocks
        ]

    words_changed = word_signature(page) != word_signature(previous)
    structure_changed = structure_signature(page) != structure_signature(previous)
    page.diagnostics["retry_changes"] = dict(
        text_or_position=words_changed,
        structure=structure_changed,
        tables=sum(b.kind == "table" for b in page.blocks),
    )
    if not words_changed:
        page.warnings.append(
            "A szöveg és a betűhelyek változatlanok. "
            + (
                "A táblázatszerkezet újraépült; kapcsold be a Felismert szerkezet nézetet."
                if structure_changed
                else "Ez a stratégia ugyanazt az eredményt adta; válassz másik hibajelzést vagy motort."
            )
        )
    ids = {w.id: f"p{page_number}-r{ir.revision + 1}-w{i + 1}" for i, w in enumerate(page.words)}
    for w in page.words:
        w.id = ids[w.id]
    for b in page.blocks:
        b.id = f"p{page_number}-r{ir.revision + 1}-{b.id}"
        b.words = [ids[w] for w in b.words]
        for c in b.cells:
            c.words = [ids[w] for w in c.words]
    for im in page.images:
        if im.get("word_id") in ids:
            im["word_id"] = ids[im["word_id"]]
    page.number = page_number
    runtime.pages[page_number - 1] = page
    with (
        fitz.open(stream=runtime.normalized_pdf, filetype="pdf") as src,
        fitz.open(stream=local.normalized_pdf, filetype="pdf") as new,
        fitz.open() as merged,
    ):
        for i in range(len(src)):
            merged.insert_pdf(
                new if i == page_number - 1 else src,
                from_page=0 if i == page_number - 1 else i,
                to_page=0 if i == page_number - 1 else i,
            )
        runtime.normalized_pdf = merged.tobytes()
    result = from_runtime(runtime, store, ir.profile)
    result.provenance = ir.provenance + [
        {
            "operation": "input_retry",
            "page": page_number,
            "error": error,
            "strategy": strategy.dict(),
            "seconds": round(time.monotonic() - started, 2),
            "previous_reviewed_words": sum(w.reviewed for w in previous.words),
            "notice": "A korábbi kézi javítások a visszaállítható előző változatban maradnak.",
        }
    ]
    return result
