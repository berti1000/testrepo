"""Capability-aware Strategy Router; unavailable models are never claimed as used."""

from dataclasses import dataclass, asdict
import importlib.util
import os
import shutil
from pathlib import Path


def capabilities():
    root = Path(os.getenv("NEURAL_MODEL_DIR", "models/neural"))
    neural = bool(importlib.util.find_spec("rapidocr")) and all(
        (root / n).is_file() for n in ("det.onnx", "rec.onnx", "latin.txt")
    )
    tatr = Path(os.getenv("TATR_MODEL_DIR", "models/tatr"))
    from .engines.vision_status import configuration

    return {
        "native": {"available": True, "label": "PyMuPDF natív"},
        "paddle": {
            "available": neural,
            "label": "PaddleOCR PP-OCRv5 Latin · ONNX",
            "setup": "python scripts/install_neural.py",
        },
        "tesseract": {
            "available": bool(shutil.which("tesseract")),
            "label": "Tesseract LSTM hun+eng",
        },
        "tatr": {
            "available": bool(importlib.util.find_spec("transformers"))
            and all((tatr / k / "model.safetensors").is_file() for k in ("detection", "structure")),
            "label": "Microsoft Table Transformer",
            "setup": "bash scripts/setup_tatr.sh",
        },
        "vision": configuration(),
        "office": {
            "available": bool(
                shutil.which(os.getenv("SOFFICE", "libreoffice")) or shutil.which("soffice")
            ),
            "label": "LibreOffice fájlelőnézet",
        },
    }


@dataclass(frozen=True)
class Strategy:
    id: str
    ocr: str
    table: str = "geometry"
    contrast: float = 1.0
    gap_factor: float = 0.95
    psm: int = 3
    reason: str = ""
    warning: str = ""

    def dict(self):
        return asdict(self)


class Router:
    def __init__(self, engines=None):
        self.engines = capabilities() if engines is None else engines

    def has(self, name):
        return bool(self.engines.get(name, {}).get("available"))

    def choose(
        self,
        profile,
        error=None,
        attempt=0,
        current="",
        contrast=1,
        gap_factor=0.95,
        requested="auto",
        consent=False,
    ):
        if error not in (None, "text", "columns", "table"):
            raise ValueError("Ismeretlen hibajelzés")
        if not 0.5 <= contrast <= 2.5 or not 0.45 <= gap_factor <= 2:
            raise ValueError("Érvénytelen csúszkaérték")
        if requested not in ("auto", "native", "paddle", "tesseract", "vision"):
            raise ValueError("Ismeretlen motor")
        scan_based = profile.kind in ("scanned", "mixed") or (
            profile.kind == "financial" and (profile.raster_pages > 0 or profile.native_chars == 0)
        )
        ocr = ("paddle" if self.has("paddle") else "tesseract") if scan_based else "native"
        table = (
            "tatr"
            if scan_based and profile.kind == "financial" and self.has("tatr")
            else "geometry"
        )
        reason = "Dokumentumprofil szerinti elsődleges stratégia"
        warning = ""
        psm = 3
        if not self.has("paddle") and ocr != "native":
            warning = "A neurális OCR nincs telepítve; Tesseract tartalékmotor fut."
        if error == "text":
            ocr = "paddle" if current != "paddle" and self.has("paddle") else "tesseract"
            if attempt > 1 and self.has("vision") and consent:
                ocr = "vision"
            psm = (6, 11, 3)[attempt % 3]
            contrast = min(2.5, contrast + 0.15 * (1 + attempt % 3))
            reason = "Hiányos szöveg: másik OCR, kontraszt és szegmentálás"
        elif error == "columns":
            ocr = current if current in ("paddle", "tesseract", "native") else ocr
            if ocr != "native":
                alternate = "tesseract" if ocr == "paddle" else "paddle"
                if self.has(alternate):
                    ocr = alternate
            gap_factor = max(0.45, gap_factor * (0.75, 0.6, 0.9)[attempt % 3])
            table = f"columns-{attempt % 3}"
            psm = (4, 6, 11)[attempt % 3]
            contrast = min(2.5, contrast + 0.1 * (attempt % 3))
            reason = (
                "Oszlophiba: teljes táblázat-újraszegmentálás, új oszlophatárok és rekordillesztés"
            )
        elif error == "table":
            ocr = current if current in ("paddle", "tesseract", "native") else ocr
            table = "tatr" if self.has("tatr") and attempt % 2 == 0 else f"columns-{attempt % 3}"
            reason = "Táblázathiba: " + (
                "képi struktúrafelismerés" if table == "tatr" else "új vonal- és oszlopillesztés"
            )
            if not self.has("tatr"):
                warning = "TATR nincs telepítve; OpenCV/geometriai tartalék fut. bash scripts/setup_tatr.sh"
        if requested != "auto" and (not error or requested != current):
            ocr = requested
            reason += "; kézi motorválasztás"
        if not self.has(ocr):
            raise ValueError("A motor nincs előkészítve: " + ocr)
        if ocr == "vision" and not consent:
            raise ValueError("A Vision API oldalküldését külön engedélyezni kell")
        return Strategy(
            f"{ocr}:{table}:{attempt}:{psm}:{contrast:.2f}:{gap_factor:.2f}",
            ocr,
            table,
            contrast,
            gap_factor,
            psm,
            reason,
            warning,
        )
