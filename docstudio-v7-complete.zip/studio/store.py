"""Durable SQLite workflow metadata; immutable JSON revisions; bounded CPU queue.

Single application process by design. Storage and strategies are separate so a
future distributed worker can replace the local executor without changing IR.
"""

import json
import os
import shutil
import sqlite3
import threading
import time
import uuid
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from .ir import AssetStore, IRDocument
from .workflow import transition


class Conflict(ValueError):
    pass


class Store:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True, mode=0o700)
        self.lock = threading.RLock()
        self.executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="studio")
        with self.connection() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute(
                "CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,payload TEXT NOT NULL)"
            )

    def connection(self):
        return sqlite3.connect(self.root / "jobs.sqlite", timeout=15)

    def folder(self, id):
        if len(id) != 32 or any(c not in "0123456789abcdef" for c in id):
            raise ValueError("Invalid job ID")
        return self.root / id

    def assets(self, id):
        return AssetStore(self.folder(id) / "assets")

    def get(self, id, owner=None):
        with self.connection() as db:
            row = db.execute("SELECT owner,payload FROM jobs WHERE id=?", (id,)).fetchone()
        if not row or owner is not None and row[0] != owner:
            raise KeyError("Nincs ilyen dokumentum")
        return json.loads(row[1])

    def list(self, owner):
        with self.connection() as db:
            return [
                json.loads(r[0])
                for r in db.execute(
                    "SELECT payload FROM jobs WHERE owner=? ORDER BY rowid DESC", (owner,)
                )
            ]

    def save(self, job, owner=None):
        job["updated"] = time.time()
        with self.connection() as db:
            if owner is not None:
                db.execute(
                    "INSERT INTO jobs VALUES(?,?,?)",
                    (job["id"], owner, json.dumps(job, ensure_ascii=False)),
                )
            else:
                db.execute(
                    "UPDATE jobs SET payload=? WHERE id=?",
                    (json.dumps(job, ensure_ascii=False, default=str), job["id"]),
                )

    def create(self, data, name, owner, settings):
        from .office import validate_ooxml

        ext = Path(name).suffix.lower()
        if ext not in (
            ".pdf",
            ".png",
            ".jpg",
            ".jpeg",
            ".tif",
            ".tiff",
            ".webp",
            ".bmp",
            ".docx",
            ".xlsx",
        ):
            raise ValueError("PDF, kép, DOCX vagy XLSX tölthető fel")
        if not data or len(data) > 50 * 1024 * 1024:
            raise ValueError("Üres vagy 50 MB feletti fájl")
        if ext in (".docx", ".xlsx"):
            validate_ooxml(data, ext)
        if ext == ".pdf" and b"%PDF-" not in data[:1024]:
            raise ValueError("Hibás PDF")
        with self.lock:
            with self.connection() as db:
                count = db.execute("SELECT COUNT(*) FROM jobs").fetchone()[0]
            if count >= int(os.getenv("MAX_ACTIVE_JOBS", "20")):
                raise ValueError("A sor megtelt; törölj régi dokumentumot")
            id = uuid.uuid4().hex
            folder = self.folder(id)
            folder.mkdir(mode=0o700)
            (folder / ("source" + ext)).write_bytes(data)
            job = {
                "id": id,
                "name": Path(name.replace("\\", "/")).name[:120],
                "state": "queued",
                "version": 0,
                "revision": 0,
                "created": time.time(),
                "updated": time.time(),
                "progress": 0,
                "message": "Feldolgozásra vár",
                "history": [],
                "events": [],
                "settings": {k: v for k, v in settings.items() if k != "password"},
                "extension": ext,
                "profile": None,
                "export": None,
                "error": None,
            }
            self.save(job, owner)
            return job

    def mutate(self, id, owner, version, event):
        job = self.get(id, owner)
        if job["version"] != version:
            raise Conflict("A dokumentum közben megváltozott; frissítsd a nézetet")
        job["state"] = transition(job["state"], event)
        job["version"] += 1
        job["error"] = None
        job["events"].append(
            {"at": time.time(), "event": event, "state": job["state"], "version": job["version"]}
        )
        return job

    def progress(self, id, value, message):
        with self.lock:
            job = self.get(id)
            job["progress"] = round(value, 3)
            job["message"] = message
            self.save(job)

    def load_ir(self, id, revision=None):
        revision = self.get(id)["revision"] if revision is None else revision
        if not isinstance(revision, int) or revision < 1:
            raise ValueError("Még nincs beolvasott változat")
        return IRDocument.model_validate_json(
            (self.folder(id) / f"ir-{revision}.json").read_bytes()
        )

    def revision(self, job, ir, label):
        number = max((h["revision"] for h in job["history"]), default=0) + 1
        if number > 100:
            raise ValueError("Dokumentumonként legfeljebb 100 változat")
        ir.revision = number
        path = self.folder(job["id"]) / f"ir-{number}.json"
        temp = path.with_suffix(".tmp")
        temp.write_bytes(ir.dump())
        temp.replace(path)
        job["revision"] = number
        job["profile"] = ir.profile.model_dump()
        job["export"] = None
        job["history"].append(
            {
                "revision": number,
                "label": label,
                "at": time.time(),
                "words": sum(len(p.words) for p in ir.pages),
                "review": sum(w.needs_review for p in ir.pages for w in p.words),
            }
        )

    def dispatch_import(self, id, settings):
        self.executor.submit(self._import, id, settings)

    def _import(self, id, settings):
        try:
            from .profiling import profile
            from .pipeline import ingest

            with self.lock:
                job = self.get(id)
                job["state"] = transition(job["state"], "start")
                self.save(job)
            data = (self.folder(id) / ("source" + job["extension"])).read_bytes()
            p = profile(data, job["name"], settings.get("password", ""))
            with self.lock:
                job = self.get(id)
                job["profile"] = p.model_dump()
                job["state"] = transition(job["state"], "profiled")
                self.save(job)
            ir = ingest(
                data, job["name"], self.assets(id), settings, lambda a, m: self.progress(id, a, m)
            )
            with self.lock:
                job = self.get(id)
                self.revision(job, ir, "Első beolvasás")
                job["state"] = transition(job["state"], "processed")
                job["version"] += 1
                job["progress"] = 1
                job["message"] = "Beolvasás kész · ellenőrizd a vásznat"
                self.save(job)
        except Exception as exc:
            self.failed(id, exc)

    def failed(self, id, exc, keep=False):
        with self.lock:
            job = self.get(id)
            job["state"] = "input_review" if keep and job["revision"] else "failed"
            job["version"] += 1
            job["error"] = f"{type(exc).__name__}: {str(exc)[:400]}"
            job["message"] = "A művelet nem sikerült"
            self.save(job)

    def retry(self, id, owner, version, page, error, settings):
        with self.lock:
            job = self.mutate(id, owner, version, "retry")
            if not 1 <= page <= len(self.load_ir(id).pages):
                raise ValueError("Nincs ilyen oldal")
            job["export"] = None
            job["progress"] = 0
            job["message"] = "Új stratégia sorban áll"
            self.save(job)
        self.executor.submit(self._retry, id, page, error, settings)
        return job

    def _retry(self, id, page, error, settings):
        try:
            from .pipeline import retry_page

            ir = self.load_ir(id)
            attempt = sum(
                p.get("operation") == "input_retry"
                and p.get("page") == page
                and p.get("error") == error
                for p in ir.provenance
            )
            ir = retry_page(
                ir,
                self.assets(id),
                page,
                error,
                attempt,
                settings,
                lambda a, m: self.progress(id, a, m),
            )
            with self.lock:
                job = self.get(id)
                self.revision(job, ir, f"{page}. oldal · {error}")
                job["state"] = transition(job["state"], "processed")
                job["version"] += 1
                job["progress"] = 1
                job["message"] = "Új változat kész · hasonlítsd össze"
                self.save(job)
        except Exception as exc:
            self.failed(id, exc, True)

    def accept_input(self, id, owner, version):
        with self.lock:
            job = self.mutate(id, owner, version, "accept_input")
            job["message"] = "Beolvasás elfogadva · válassz exportot"
            self.save(job)
            return job

    def restore_revision(self, id, owner, version, revision):
        with self.lock:
            job = self.mutate(id, owner, version, "restore")
            if revision not in [h["revision"] for h in job["history"]]:
                raise ValueError("Nincs ilyen változat")
            ir = self.load_ir(id, revision)
            job["revision"] = revision
            job["profile"] = ir.profile.model_dump()
            job["export"] = None
            job["message"] = "Korábbi változat visszaállítva"
            self.save(job)
            return job

    def edit(self, id, owner, version, page, word, text, *, size=None, bold=None, font=None):
        with self.lock:
            job = self.mutate(id, owner, version, "edit")
            ir = self.load_ir(id)
            if not 1 <= page <= len(ir.pages):
                raise ValueError("Nincs ilyen oldal")
            token = next((w for w in ir.pages[page - 1].words if w.id == word), None)
            if token is None:
                raise ValueError("Nincs ilyen szövegelem")
            before = token.text
            token.original_text = token.original_text or before
            token.text = text
            token.reviewed = True
            token.visual_artifact = False
            token.render_scale = None
            before_style = dict(size=token.size, bold=token.bold, font=token.font)
            if size is not None:
                if not 4 <= size <= 120:
                    raise ValueError("A betűméret 4–120 pt lehet")
                token.size = size
            if bold is not None:
                token.bold = bool(bold)
            if font is not None:
                if font not in ("Arial", "Times New Roman", "Courier New"):
                    raise ValueError("Nem támogatott betűtípus")
                token.font = font
            if any(v is not None for v in (size, bold, font)):
                from reconstructor.render import font_for
                from reportlab.pdfbase import pdfmetrics

                width = pdfmetrics.stringWidth(token.text, font_for(token), token.size)
                x, y = token.origin
                token.bbox = (x, y - token.size * 0.95, x + max(1, width), y + token.size * 0.25)
                token.render_scale = 1
                from reconstructor.typography import reflow_edited_word

                reflow_edited_word(ir.pages[page - 1], token)
            ir.edits.append(
                dict(
                    page=page,
                    word=word,
                    before_style=before_style,
                    after_style=dict(size=token.size, bold=token.bold, font=token.font),
                    at=time.time(),
                )
            )
            ir.edits.append(
                {"page": page, "word": word, "before": before, "after": text, "at": time.time()}
            )
            self.revision(job, ir, "Kézi szövegjavítás")
            self.save(job)
            return job

    def export(self, id, owner, version, options, error=None):
        from .output.service import fallback

        with self.lock:
            job = self.mutate(id, owner, version, "export")
            if error:
                options = fallback(options, error)
            job["export"] = None
            job["progress"] = 0
            job["message"] = "Export és tényleges fájlelőnézet készül"
            self.save(job)
        self.executor.submit(self._export, id, options, error)
        return job

    def _export(self, id, options, error):
        try:
            from .output.service import generate

            ir = self.load_ir(id)
            identifier = uuid.uuid4().hex
            self.progress(id, 0.2, "Fájl létrehozása az elfogadott IR-ből")
            info = generate(ir, self.assets(id), options, self.folder(id) / "exports" / identifier)
            with self.lock:
                job = self.get(id)
                info["id"] = identifier
                info["error_tag"] = error
                job["export"] = info
                job["state"] = transition(job["state"], "exported")
                job["version"] += 1
                job["progress"] = 1
                job["message"] = "Tényleges export-előnézet kész"
                self.save(job)
        except Exception as exc:
            with self.lock:
                job = self.get(id)
                job["state"] = transition(job["state"], "fail")
                job["version"] += 1
                job["error"] = f"{type(exc).__name__}: {str(exc)[:400]}"
                job["message"] = "Exporthiba · a beolvasás megmaradt"
                self.save(job)

    def accept_export(self, id, owner, version, digest):
        with self.lock:
            job = self.mutate(id, owner, version, "accept_export")
            if not job["export"] or job["export"]["sha256"] != digest:
                raise Conflict("Az előnézet elavult")
            job["message"] = "Export elfogadva · letölthető"
            self.save(job)
            return job

    def delete(self, id, owner):
        with self.lock:
            job = self.get(id, owner)
            if job["state"] in ("queued", "profiling", "processing", "exporting"):
                raise Conflict("Futó feladat nem törölhető")
            with self.connection() as db:
                db.execute("DELETE FROM jobs WHERE id=?", (id,))
            shutil.rmtree(self.folder(id), ignore_errors=True)

    def recover(self):
        with self.lock, self.connection() as db:
            rows = db.execute("SELECT payload FROM jobs").fetchall()
            for (raw,) in rows:
                job = json.loads(raw)
                if job["state"] in ("queued", "profiling", "processing", "exporting"):
                    job["state"] = "input_review" if job["revision"] else "failed"
                    job["version"] += 1
                    job["error"] = (
                        "A szerver feldolgozás közben újraindult. A kész változatok megmaradtak."
                    )
                    self.save(job)

    def cleanup(self):
        ttl = max(60, int(os.getenv("JOB_TTL_SECONDS", "86400")))
        with self.lock, self.connection() as db:
            for id, owner, raw in db.execute("SELECT id,owner,payload FROM jobs").fetchall():
                job = json.loads(raw)
                if time.time() - job["updated"] > ttl and job["state"] not in (
                    "queued",
                    "profiling",
                    "processing",
                    "exporting",
                ):
                    self.delete(id, owner)


STORE = Store(Path(os.getenv("JOB_DIR", "/tmp/reconstructor-jobs")) / "studio-v5")
