"""Explicit review transitions: neither input nor export is silently accepted."""

from enum import StrEnum


class State(StrEnum):
    QUEUED = "queued"
    PROFILING = "profiling"
    PROCESSING = "processing"
    INPUT_REVIEW = "input_review"
    INPUT_ACCEPTED = "input_accepted"
    EXPORTING = "exporting"
    EXPORT_REVIEW = "export_review"
    READY = "ready"
    FAILED = "failed"


TRANSITIONS = {
    "queued": {"start": "profiling"},
    "profiling": {"profiled": "processing", "fail": "failed"},
    "processing": {"processed": "input_review", "fail": "failed"},
    "input_review": {
        "retry": "processing",
        "accept_input": "input_accepted",
        "edit": "input_review",
        "restore": "input_review",
    },
    "input_accepted": {
        "export": "exporting",
        "retry": "processing",
        "edit": "input_review",
        "restore": "input_review",
    },
    "exporting": {"exported": "export_review", "fail": "input_accepted"},
    "export_review": {
        "export": "exporting",
        "accept_export": "ready",
        "retry": "processing",
        "edit": "input_review",
        "restore": "input_review",
    },
    "ready": {
        "export": "exporting",
        "retry": "processing",
        "edit": "input_review",
        "restore": "input_review",
    },
    "failed": {"start": "profiling", "restore": "input_review"},
}


def transition(state, event):
    try:
        return TRANSITIONS[state][event]
    except KeyError as e:
        raise ValueError(f"Érvénytelen állapotváltás: {state} → {event}") from e


INPUT_ERRORS = {
    "text": "Zagyva / hiányos szöveg",
    "columns": "Összefolyt oszlopok",
    "table": "Táblázat szétesett",
}
OUTPUT_ERRORS = {
    "docx": {
        "drift": "Szétcsúszott elemek",
        "margins": "Rossz margók",
        "flow": "Inkább folyószöveget",
    },
    "xlsx": {
        "empty": "Túl sok üres / összevont cella",
        "numbers": "Számok szövegként",
        "columns": "Oszlopok elcsúsztak",
    },
}
