"""PP-OCRv5 Latin models with local ONNX inference and CTC-aligned word boxes."""

import os
import re
import threading
from functools import lru_cache
from pathlib import Path
import cv2
import numpy as np
from PIL import ImageEnhance, ImageOps
from reconstructor.model import Word
from reconstructor.ocr import fit_fonts, pilfont

LOCK = threading.RLock()


@lru_cache(maxsize=1)
def engine():
    from rapidocr import RapidOCR, OCRVersion, LangRec

    root = Path(os.getenv("NEURAL_MODEL_DIR", "models/neural"))
    if not all((root / n).is_file() for n in ("det.onnx", "rec.onnx", "latin.txt")):
        raise RuntimeError("Hiányzó neurális modellek: python scripts/install_neural.py")

    class CoordinateSafeRapidOCR(RapidOCR):
        def calc_word_boxes(self, img, dt_boxes, rec_res, op_record, raw_h, raw_w):
            # RapidOCR 3.4.2 build_final_output has already mapped dt_boxes to
            # original-image coordinates. cal_rec_boxes uses that geometry;
            # mapping its output again would double-scale long/padded scans.
            return self.cal_rec_boxes(
                img, dt_boxes, rec_res, self.return_single_char_box
            ).word_results

    return CoordinateSafeRapidOCR(
        params={
            "Det.model_path": str(root / "det.onnx"),
            "Det.ocr_version": OCRVersion.PPOCRV5,
            "Det.limit_side_len": 1536,
            "Det.limit_type": "max",
            "Det.box_thresh": 0.45,
            "Det.unclip_ratio": 1.5,
            "Rec.model_path": str(root / "rec.onnx"),
            "Rec.ocr_version": OCRVersion.PPOCRV5,
            "Rec.lang_type": LangRec.LATIN,
            "Rec.rec_keys_path": str(root / "latin.txt"),
            "Global.use_cls": False,
            "Global.text_score": 0.35,
            "Global.max_side_len": 4200,
            "Global.log_level": "warning",
            "EngineConfig.onnxruntime.intra_op_num_threads": 2,
            "EngineConfig.onnxruntime.inter_op_num_threads": 1,
        }
    )


def ink_window(image):
    gray = np.array(image.convert("L"))
    mask = (gray < 150).astype("uint8")
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    good = np.zeros(n, dtype="uint8")
    good[1:] = ((stats[1:, cv2.CC_STAT_AREA] >= 12) & (stats[1:, cv2.CC_STAT_HEIGHT] >= 4)).astype(
        "uint8"
    )
    ys, xs = np.nonzero(good[labels])
    if len(xs) < 80:
        return (0, 0, image.width, image.height)
    x0, x1 = np.quantile(xs, [0.001, 0.999])
    y0, y1 = np.quantile(ys, [0.001, 0.999])
    return (
        max(0, int(x0) - 35),
        max(0, int(y0) - 35),
        min(image.width, int(x1) + 35),
        min(image.height, int(y1) + 35),
    )


def tight_box(gray, box):
    x0, y0, x1, y1 = box
    a, b = max(0, int(x0)), max(0, int(y0))
    c, d = min(gray.shape[1], int(x1) + 1), min(gray.shape[0], int(y1) + 1)
    if c <= a or d <= b:
        return tuple(float(v) for v in box)
    patch = gray[b:d, a:c]
    mask = (patch < 175).astype("uint8")
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    good = np.zeros(n, dtype="uint8")
    good[1:] = (
        (stats[1:, cv2.CC_STAT_AREA] >= 3)
        & (stats[1:, cv2.CC_STAT_HEIGHT] >= max(2, patch.shape[0] * 0.08))
        & ~(
            (stats[1:, cv2.CC_STAT_WIDTH] > patch.shape[1] * 0.85)
            & (stats[1:, cv2.CC_STAT_HEIGHT] < patch.shape[0] * 0.2)
        )
    ).astype("uint8")
    yy, xx = np.nonzero(good[labels])
    if len(xx) < 3:
        return tuple(float(v) for v in box)
    return float(a + min(xx)), float(b + min(yy)), float(a + max(xx) + 1), float(b + max(yy) + 1)


def align_tokens(text, tokens, font):
    """Keep the recognizer's spaces. CTC geometry may split a single word/amount.

    Merge/split only when the complete character stream is identical; no textual
    correction or number guessing is involved. Return [] for an unmatched stream.
    """
    source = [(re.sub(r"\s", "", t), score, box) for t, score, box in tokens]
    target = re.findall(r"\S+", text)
    if "".join(t for t, _, _ in source) != "".join(target):
        return []
    spans = []
    offset = 0
    for t, score, box in source:
        if t:
            spans.append((offset, offset + len(t), t, score, box))
            offset += len(t)
    result = []
    offset = 0
    for value in target:
        stop = offset + len(value)
        fragments = []
        scores = []
        for start, end, token, score, (a, b, c, d) in spans:
            lo, hi = max(offset, start), min(stop, end)
            if lo >= hi:
                continue
            length = max(0.1, font.getlength(token))
            left = a + (c - a) * font.getlength(token[: lo - start]) / length
            right = a + (c - a) * font.getlength(token[: hi - start]) / length
            fragments.append((left, b, right, d))
            scores.extend([score] * (hi - lo))
        if fragments:
            result.append(
                (
                    value,
                    sum(scores) / len(scores),
                    (
                        min(p[0] for p in fragments),
                        min(p[1] for p in fragments),
                        max(p[2] for p in fragments),
                        max(p[3] for p in fragments),
                    ),
                )
            )
        offset = stop
    return result


def normalize_ctc_boxes(tokens, left, right):
    """Map a recognizer's compressed CTC extent back to the detected line."""
    if not tokens:
        return tokens, False
    a = min(t[2][0] for t in tokens)
    b = max(t[2][2] for t in tokens)
    coverage = (b - a) / max(1, right - left)
    if b <= a or 0.8 <= coverage <= 1.25:
        return tokens, False
    ratio = (right - left) / (b - a)
    return [
        (text, score, (left + (box[0] - a) * ratio, box[1], left + (box[2] - a) * ratio, box[3]))
        for text, score, box in tokens
    ], True


def normalize_contrast(image):
    """Stretch washed-out OCR input only. Source pixels and IR text are untouched."""
    lo, hi = np.percentile(np.asarray(image.convert("L")), [0.5, 99.5])
    applied = 40 <= hi - lo < 160
    return (ImageOps.autocontrast(image, cutoff=0.1) if applied else image), {
        "applied": bool(applied),
        "input_range": [round(float(lo), 1), round(float(hi), 1)],
    }


def recognize(image, page, contrast=1.0, progress=None):
    crop = ink_window(image)
    patch = ImageEnhance.Contrast(image.crop(crop)).enhance(contrast)
    patch, contrast_info = normalize_contrast(patch)
    scale = max(1, min(2, 1600 / max(patch.size)))
    if scale > 1:
        patch = patch.resize((round(patch.width * scale), round(patch.height * scale)))
    if progress:
        progress(0.1)
    with LOCK:
        result = engine()(np.array(patch)[:, :, ::-1], use_cls=False, return_word_box=True)
    if progress:
        progress(0.8)
    words = []
    lines = []
    corrected_ctc = 0
    gray = np.array(image.convert("L"))
    sx, sy = page.width / image.width, page.height / image.height
    font = pilfont("sans", False)
    if result.boxes is not None:
        for li, (poly, text, score) in enumerate(zip(result.boxes, result.txts, result.scores)):
            text = text.strip()
            if not text:
                continue
            xs, ys = np.array(poly, dtype=float).T
            left, top, right, bottom = tight_box(
                gray,
                (
                    min(xs) / scale + crop[0],
                    min(ys) / scale + crop[1],
                    max(xs) / scale + crop[0],
                    max(ys) / scale + crop[1],
                ),
            )
            box = tuple(float(v) for v in (left * sx, top * sy, right * sx, bottom * sy))
            lines.append(
                Word(
                    f"line-{li}",
                    text,
                    box,
                    (box[0], box[3]),
                    max(2, box[3] - box[1]),
                    confidence=float(score),
                    line_hint=f"neural-{li}",
                )
            )
            tokens = []
            if len(result.word_results) == len(result.txts):
                for token, conf, points in result.word_results[li]:
                    tx, ty = np.array(points, dtype=float).T
                    coords = (
                        min(tx) / scale + crop[0],
                        min(ty) / scale + crop[1],
                        max(tx) / scale + crop[0],
                        max(ty) / scale + crop[1],
                    )
                    tokens.append((token, float(conf), coords))
            if tokens:
                # The Latin v5 CTC stride can leave word coordinates in the
                # recognition crop's compressed width. The detector line is in
                # page coordinates. Restore that scale before ink trimming.
                tokens, corrected = normalize_ctc_boxes(tokens, left, right)
                corrected_ctc += int(corrected)
                tokens = [(t, c, tight_box(gray, box)) for t, c, box in tokens]
            tokens = align_tokens(text, tokens, font)
            if not tokens:
                full = max(1, font.getlength(text))
                for t in re.finditer(r"\S+", text):
                    a = left + (right - left) * font.getlength(text[: t.start()]) / full
                    b = left + (right - left) * font.getlength(text[: t.end()]) / full
                    tokens.append((t.group(), float(score), (a, top, b, bottom)))
            for token, confidence, (a, t, b, d) in tokens:
                if not token.strip() or b <= a or d <= t:
                    continue
                box = tuple(float(v) for v in (a * sx, t * sy, b * sx, d * sy))
                words.append(
                    Word(
                        f"p{page.number}-n{len(words) + 1}",
                        token,
                        box,
                        (box[0], box[3]),
                        max(2, box[3] - box[1]),
                        source="paddle-ppocrv5-latin",
                        confidence=confidence,
                        line_hint=f"neural-{li}",
                    )
                )
    typography = fit_fonts(image, lines, page.width, page.height) if lines else {}
    index = {w.line_hint: w for w in lines}
    for word in words:
        line = index[word.line_hint]
        word.font, word.size, word.bold = line.font, line.size, line.bold
        word.origin = (word.bbox[0], line.origin[1])
        word.visual_artifact = line.visual_artifact
        from reconstructor.render import font_family

        family = font_family(line.font)
        width = pilfont(family, line.bold).getlength(line.text) / 100 * line.size
        word.render_scale = max(0.5, min(2, (line.bbox[2] - line.bbox[0]) / max(0.1, width)))
    from .typography import refine_condensed_lines

    condensed_typography = refine_condensed_lines(words)
    return (
        words,
        {
            "engine": "paddle-ppocrv5-latin-onnx",
            "inference_crop_px": list(crop),
            "token_boxes": "CTC-aligned; ink-trimmed; shared baseline and glyph scale",
            "coordinate_mapping": "original-image coordinates; single inverse transform",
            "neural_lines": len(result.txts or []),
            "text_line_regions": [
                {"line_hint": line.line_hint, "bbox": list(line.bbox)} for line in lines
            ],
            "rescaled_ctc_lines": corrected_ctc,
            "ocr_contrast_normalization": contrast_info,
            "typography": typography,
            "condensed_typography": condensed_typography,
        },
        [],
    )
