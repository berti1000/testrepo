"""Configuration and explicit connectivity check; never sends a document."""

import os
from urllib.parse import urlparse
import httpx


def configuration():
    base = os.getenv("VISION_BASE_URL", "").strip().rstrip("/")
    model = os.getenv("VISION_MODEL", "").strip()
    missing = [k for k, v in [("VISION_BASE_URL", base), ("VISION_MODEL", model)] if not v]
    valid = urlparse(base).scheme in ("http", "https") and bool(urlparse(base).hostname)
    return dict(
        available=not missing and valid,
        label="Vision API · külön engedéllyel",
        model=model,
        setup=("Hiányzó beállítás: " + ", ".join(missing))
        if missing
        else (
            "Érvénytelen VISION_BASE_URL"
            if not valid
            else "Beállítva; a kapcsolat külön tesztelhető."
        ),
        purpose="Nehéz szövegek és táblázatok második olvasata. Az aláírásokat és vonalakat a helyi grafikai motor őrzi meg.",
    )


def connection_test():
    config = configuration()
    if not config["available"]:
        return dict(ok=False, message=config["setup"])
    try:
        with httpx.Client(timeout=8, follow_redirects=False, trust_env=False) as client:
            r = client.get(
                os.environ["VISION_BASE_URL"].rstrip("/") + "/models",
                headers={"Authorization": "Bearer " + os.getenv("VISION_API_KEY", "local")},
            )
        if r.status_code in (401, 403):
            return dict(ok=False, message="Hibás API-kulcs vagy hiányzó hozzáférés.")
        if r.status_code == 404:
            return dict(
                ok=False,
                message="A /models végpont nem található. OpenAI-kompatibilis alapcím kell, általában /v1 végződéssel.",
            )
        r.raise_for_status()
        models = [m.get("id") for m in r.json().get("data", []) if isinstance(m, dict)]
        if config["model"] not in models:
            return dict(
                ok=False,
                message="A VISION_MODEL értéke nem szerepel a szolgáltató modell-listájában.",
            )
        return dict(
            ok=True,
            message="Kapcsolat és modellnév rendben. Ez még nem igazolja a képfeldolgozást: képet fogadó modell szükséges. Dokumentumot nem küldtünk.",
        )
    except httpx.TimeoutException:
        return dict(ok=False, message="A Vision szerver 8 másodpercen belül nem válaszolt.")
    except (httpx.HTTPError, ValueError, TypeError):
        return dict(
            ok=False,
            message="Nem érhető el kompatibilis Vision szolgáltató. Ellenőrizd a címet és a szerver futását.",
        )
