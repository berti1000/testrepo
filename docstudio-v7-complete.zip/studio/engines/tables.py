"""Microsoft TATR detection + structure recognition, including spanning cells."""

import os
import threading
from pathlib import Path
from functools import lru_cache
from reconstructor.model import Block, Cell
from reconstructor.geometry import group_lines, split_line, union

LOCK = threading.RLock()


@lru_cache(maxsize=2)
def model(kind):
    from transformers import AutoConfig, AutoImageProcessor, TableTransformerForObjectDetection

    root = Path(os.getenv("TATR_MODEL_DIR", "models/tatr")) / kind
    config = AutoConfig.from_pretrained(root, local_files_only=True)
    # The checkpoint already includes the backbone. Never fetch separate timm weights.
    config.use_pretrained_backbone = False
    return AutoImageProcessor.from_pretrained(
        root, local_files_only=True, use_fast=False
    ), TableTransformerForObjectDetection.from_pretrained(
        root, config=config, local_files_only=True, use_safetensors=True
    ).eval()


def detect(image, kind, threshold):
    import torch

    processor, net = model(kind)
    with LOCK, torch.inference_mode():
        result = net(**processor(images=image, return_tensors="pt"))
    result = processor.post_process_object_detection(
        result, threshold=threshold, target_sizes=torch.tensor([image.size[::-1]])
    )[0]
    return [
        (net.config.id2label[int(k)], float(s), [float(x) for x in b])
        for k, s, b in zip(result["labels"], result["scores"], result["boxes"])
    ]


def bands(items, label, axis):
    found = sorted((b[axis], b[axis + 2], s) for k, s, b in items if k == label)
    out = []
    for lo, hi, score in found:
        if (
            out
            and max(0, min(hi, out[-1][1]) - max(lo, out[-1][0]))
            / max(1, min(hi - lo, out[-1][1] - out[-1][0]))
            > 0.6
        ):
            if score > out[-1][2]:
                out[-1] = (lo, hi, score)
        else:
            out.append((lo, hi, score))
    return (
        [out[0][0]] + [(a[1] + b[0]) / 2 for a, b in zip(out, out[1:])] + [out[-1][1]]
        if out
        else []
    )


def select_complete_tables(candidates, existing):
    """Reject overlapping hypotheses and partial replacements of established grids."""
    kept, owned = [], set()
    for table in sorted(candidates, key=lambda b: -(b.confidence or 0)):
        if owned.intersection(table.words):
            continue
        kept.append(table)
        owned.update(table.words)
    protected = set()
    for old in existing:
        if old.kind != "table" or not old.words:
            continue
        overlap = set(old.words) & owned
        if overlap and len(overlap) / len(set(old.words)) < 0.9:
            protected.update(old.words)
    result = [t for t in kept if not protected.intersection(t.words)]
    return result, len(candidates) - len(result)


def tatr(image, page):
    tables = []
    sx, sy = page.width / image.width, page.height / image.height
    for label, score, box in detect(image, "detection", 0.65):
        if label != "table":
            continue
        x0, y0, x1, y1 = box
        crop = (
            max(0, int(x0) - 12),
            max(0, int(y0) - 12),
            min(image.width, int(x1) + 12),
            min(image.height, int(y1) + 12),
        )
        if crop[2] <= crop[0] or crop[3] <= crop[1]:
            continue
        found = detect(image.crop(crop), "structure", 0.55)
        xs = bands(found, "table column", 0)
        ys = bands(found, "table row", 1)
        if len(xs) < 3 or len(ys) < 3 or len(xs) * len(ys) > 5000:
            continue
        xs = [(v + crop[0]) * sx for v in xs]
        ys = [(v + crop[1]) * sy for v in ys]
        cells = []
        for r in range(len(ys) - 1):
            for c in range(len(xs) - 1):
                b = (xs[c], ys[r], xs[c + 1], ys[r + 1])
                ids = [
                    w.id
                    for w in page.words
                    if b[0] <= (w.bbox[0] + w.bbox[2]) / 2 < b[2]
                    and b[1] <= (w.bbox[1] + w.bbox[3]) / 2 < b[3]
                ]
                cells.append(Cell(r, c, 1, 1, b, ids))
        covered = set()
        merged = []
        for label, _, b in found:
            if label not in ("table spanning cell", "table projected row header"):
                continue
            b = (
                (b[0] + crop[0]) * sx,
                (b[1] + crop[1]) * sy,
                (b[2] + crop[0]) * sx,
                (b[3] + crop[1]) * sy,
            )
            selected = [
                c
                for c in cells
                if b[0] <= (c.bbox[0] + c.bbox[2]) / 2 <= b[2]
                and b[1] <= (c.bbox[1] + c.bbox[3]) / 2 <= b[3]
            ]
            keys = {(c.row, c.col) for c in selected}
            if len(keys) < 2 or keys & covered:
                continue
            r0, r1 = min(c.row for c in selected), max(c.row for c in selected)
            c0, c1 = min(c.col for c in selected), max(c.col for c in selected)
            if len(keys) != (r1 - r0 + 1) * (c1 - c0 + 1):
                continue
            covered |= keys
            merged.append(
                Cell(
                    r0,
                    c0,
                    r1 - r0 + 1,
                    c1 - c0 + 1,
                    (xs[c0], ys[r0], xs[c1 + 1], ys[r1 + 1]),
                    [w for c in selected for w in c.words],
                )
            )
        cells = [c for c in cells if (c.row, c.col) not in covered] + merged
        ids = [w for c in cells for w in c.words]
        tables.append(
            Block(
                f"p{page.number}-tatr{len(tables) + 1}",
                "table",
                (xs[0], ys[0], xs[-1], ys[-1]),
                ids,
                cells,
                xs,
                ys,
                "tatr",
                score,
            )
        )
    candidates = len(tables)
    tables, rejected = select_complete_tables(tables, page.blocks)
    if tables:
        assigned = {w for t in tables for w in t.words}
        page.blocks = tables + [b for b in page.blocks if not assigned.intersection(b.words)]
        remaining = {w.id for w in page.words} - {w for b in page.blocks for w in b.words}
        for line in group_lines([w for w in page.words if w.id in remaining]):
            page.blocks.append(
                Block(f"p{page.number}-rest{len(page.blocks)}", "paragraph", line.bbox, line.words)
            )
        page.blocks.sort(key=lambda b: (b.bbox[1], b.bbox[0]))
    page.diagnostics["tatr_tables"] = len(tables)
    page.diagnostics["tatr_candidates"] = candidates
    page.diagnostics["tatr_rejected_partial"] = rejected
    page.diagnostics["table_actual"] = (
        "tatr+geometry"
        if tables
        else ("geometry-after-tatr-incomplete" if rejected else "geometry-after-tatr-empty")
    )
    if rejected:
        page.warnings.append(
            "Hiányos vagy átfedő TATR-rács elvetve; a teljesebb geometriai cellaszerkezet megmaradt."
        )
    if not tables:
        page.warnings.append("TATR nem adott megbízható rácsot; a geometriai eredmény megmaradt.")


def separate_columns(page, gap):
    index = page.index()
    blocks = []
    for block in page.blocks:
        if block.kind == "table":
            blocks.append(block)
            continue
        for line in group_lines([index[w] for w in block.words]):
            for ids in split_line(line, index, gap, page.rules):
                blocks.append(
                    Block(
                        f"p{page.number}-col{len(blocks)}",
                        "paragraph",
                        union([index[w].bbox for w in ids]),
                        ids,
                        method="whitespace-columns",
                    )
                )
    page.blocks = blocks
    page.diagnostics["table_actual"] = "whitespace-columns"
