"""Independent OCR disagreements are evidence for review, never silent corrections."""

import pytesseract


def crosscheck(image, page):
    data = pytesseract.image_to_data(
        image,
        lang="hun+eng",
        config="--oem 1 --psm 3",
        output_type=pytesseract.Output.DICT,
        timeout=60,
    )
    sx, sy = page.width / image.width, page.height / image.height
    candidates = []
    for i, raw in enumerate(data["text"]):
        text = raw.strip()
        if not text or float(data["conf"][i]) < 80:
            continue
        a, b, c, d = (float(data[k][i]) for k in ["left", "top", "width", "height"])
        candidates.append((text, (a * sx, b * sy, (a + c) * sx, (b + d) * sy)))
    count = 0
    for word in page.words:
        matches = []
        for text, box in candidates:
            intersection = max(0, min(box[2], word.bbox[2]) - max(box[0], word.bbox[0])) * max(
                0, min(box[3], word.bbox[3]) - max(box[1], word.bbox[1])
            )
            union = (
                (box[2] - box[0]) * (box[3] - box[1])
                + (word.bbox[2] - word.bbox[0]) * (word.bbox[3] - word.bbox[1])
                - intersection
            )
            if (
                intersection / max(0.01, union) > 0.45
                and 0.5 <= len(text) / max(1, len(word.text)) <= 2
            ):
                matches.append((intersection / max(0.01, union), text))
        if matches:
            candidate = max(matches)[1]
            if candidate != word.text and candidate not in word.alternatives:
                word.alternatives.append(candidate)
                count += 1
    page.diagnostics["crosscheck"] = {
        "engine": "tesseract-hun-eng",
        "disagreements": count,
        "policy": "review-only; primary text unchanged",
    }
    if count:
        page.warnings.append(
            f"{count} szónál eltérő motorolvasat van; a sárga kereteket ellenőrizd. A fő olvasat nem változott."
        )
