"""Local OCR and explicitly opted-in Vision engines."""
