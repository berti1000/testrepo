"""Keep condensed receipt glyph heights independent of horizontal fitting."""

from bisect import bisect_left, bisect_right
from collections import defaultdict
from statistics import median

from reconstructor.ocr import pilfont
from reconstructor.render import font_family


def refine_condensed_lines(words):
    groups = defaultdict(list)
    for word in words:
        if word.line_hint:
            groups[word.line_hint].append(word)
    metrics = []
    for group in groups.values():
        if font_family(group[0].font) != "mono":
            continue
        font = pilfont("mono", group[0].bold)
        usable = [
            w
            for w in group
            if len(w.text) >= 2 and any(c.isalnum() for c in w.text) and not w.visual_artifact
        ]
        if not usable:
            continue
        sizes = []
        for word in usable:
            _, top, _, bottom = font.getbbox(word.text, anchor="ls")
            sizes.append((word.bbox[3] - word.bbox[1]) / max(0.1, (bottom - top) / 100))
        text = " ".join(w.text for w in group)
        x0, x1 = min(w.bbox[0] for w in group), max(w.bbox[2] for w in group)
        width = x1 - x0
        size = max(2, min(120, median(sizes)))
        advance = max(0.1, font.getlength(text) / 100)
        _, top, _, bottom = font.getbbox(text, anchor="ls")
        metrics.append(
            {
                "words": group,
                "center": median((w.bbox[1] + w.bbox[3]) / 2 for w in usable),
                "x0": x0,
                "x1": x1,
                "width": width,
                "size": size,
                "advance": advance,
                "top": top,
                "bottom": bottom,
                "aspect": size * advance / max(0.1, width),
            }
        )
    aspect = median(m["aspect"] for m in metrics) if metrics else 1
    info = {"applied": False, "median_aspect_ratio": round(aspect, 3), "lines": 0}
    # Require repeated evidence of condensed typography, not a single tall box.
    if len(metrics) < 8 or aspect < 1.45:
        return info
    metrics.sort(key=lambda m: m["center"])
    centers = [m["center"] for m in metrics]
    limited = 0
    for m in metrics:
        size, center = m["size"], m["center"]
        ink_height = max(0.1, (m["bottom"] - m["top"]) / 100)
        radius = size * ink_height / 0.82
        neighbors = metrics[
            bisect_left(centers, center - radius) : bisect_right(centers, center + radius)
        ]
        gaps = []
        for other in neighbors:
            gap = abs(center - other["center"])
            overlap = max(0, min(m["x1"], other["x1"]) - max(m["x0"], other["x0"]))
            if gap > 2 and overlap / max(1, min(m["width"], other["width"])) > 0.5:
                gaps.append(gap)
        if gaps:
            size = max(2, min(size, 0.82 * min(gaps) / ink_height))
        limited += size < m["size"]
        baseline = center - (m["top"] + m["bottom"]) / 200 * size
        scale = max(0.25, min(2, m["width"] / (m["advance"] * size)))
        for word in m["words"]:
            word.size = size
            word.origin = (word.bbox[0], baseline)
            word.render_scale = scale
    return dict(info, applied=True, lines=len(metrics), neighbor_limited_lines=limited)
