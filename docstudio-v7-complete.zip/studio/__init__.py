"""DocStudio 5: transparent processing and review over an immutable IR."""

__version__ = "5.0.0"
