"""Rebuild table geometry from the IR's words, never from PDF text order.

Persistent vertical whitespace determines columns (including empty columns with
headers). The first occupied column anchors records, so wrapped names and dates
stay in the same record. This is deliberately independent of OCR and of an
earlier, potentially incorrect, table segmentation.
"""

from bisect import bisect_right
from reconstructor.geometry import group_lines, split_line, union, intersection
from reconstructor.model import Block, Cell


def fragments(words, gap=0.85):
    index = {w.id: w for w in words}
    return [
        [index[k] for k in ids]
        for line in group_lines(words)
        for ids in split_line(line, index, gap)
    ]


def detect_tables(page, sensitivity=0):
    """Return disjoint, conservative table candidates; retain all text outside.

    Sensitivity 0 uses persistent whitespace; 1 anchors dividers nearer the
    next column; 2 prefers explicit vertical rules when available.
    """
    words = [w for w in page.words if w.text.strip()]
    index = {w.id: w for w in words}
    lines = group_lines(words)
    dense = [
        i
        for i, line in enumerate(lines)
        if len(split_line(line, index, 0.7 + 0.1 * (sensitivity % 2))) >= 4
    ]
    groups = []
    for i in dense:
        if (
            groups
            and lines[i].baseline - lines[groups[-1][-1]].baseline < max(46, lines[i].size * 6)
            and 0.82 < lines[i].size / max(1, lines[groups[-1][-1]].size) < 1.22
        ):
            groups[-1].append(i)
        else:
            groups.append([i])
    result = []
    for group in groups:
        if len(group) < 2:
            continue
        first, last = group[0], group[-1]
        # Include the final record's wrapped continuation, but not a distant footer.
        while (
            last + 1 < len(lines)
            and lines[last + 1].baseline - lines[last].baseline < lines[last].size * 1.6
            and 0.82 < lines[last + 1].size / max(1, lines[last].size) < 1.22
        ):
            last += 1
        ids = [k for line in lines[first : last + 1] for k in line.words]
        items = [index[k] for k in ids]
        parts = fragments(items, 0.8)
        intervals = sorted((min(w.bbox[0] for w in p), max(w.bbox[2] for w in p)) for p in parts)
        occupied = []
        for left, right in intervals:
            if occupied and left - occupied[-1][1] < 3.5:
                occupied[-1][1] = max(right, occupied[-1][1])
            else:
                occupied.append([left, right])
        if not 4 <= len(occupied) <= 40:
            continue
        box = union([w.bbox for w in items])
        fraction = (0.5, 0.78, 0.25)[sensitivity % 3]
        x = (
            [box[0] - 2]
            + [a[1] + (b[0] - a[1]) * fraction for a, b in zip(occupied, occupied[1:])]
            + [box[2] + 2]
        )
        if sensitivity % 3 == 2:
            for j in range(1, len(x) - 1):
                rules = [
                    r["pos"]
                    for r in page.rules
                    if r["axis"] == "v"
                    and r["start"] <= box[1] + 5
                    and r["end"] >= box[3] - 5
                    and occupied[j - 1][1] <= r["pos"] <= occupied[j][0]
                ]
                if rules:
                    x[j] = min(rules, key=lambda pos: abs(pos - x[j]))
        # Use first-column line starts as record anchors, grouping close wraps.
        anchors = []
        for line in group_lines([w for w in items if (w.bbox[0] + w.bbox[2]) / 2 < x[1]]):
            if anchors and line.baseline - anchors[-1][-1].baseline <= line.size * 1.65:
                anchors[-1].append(line)
            else:
                anchors.append([line])
        if len(anchors) < 2:
            continue
        y = [box[1] - 2]
        for previous, following in zip(anchors, anchors[1:]):
            # Midway between completed record and next record, including wraps
            # in other columns, rather than splitting at each text baseline.
            start = following[0].bbox[1]
            end = max(
                (
                    w.bbox[3]
                    for w in items
                    if previous[0].baseline - 1 <= w.origin[1] < following[0].baseline - 2
                ),
                default=previous[-1].bbox[3],
            )
            y.append((min(end, start - 1) + start) / 2)
        y.append(box[3] + 4)
        if any(b - a < 3 for a, b in zip(y, y[1:])):
            continue
        cells = [
            Cell(r, c, 1, 1, (x[c], y[r], x[c + 1], y[r + 1]))
            for r in range(len(y) - 1)
            for c in range(len(x) - 1)
        ]
        for w in items:
            c = min(len(x) - 2, max(0, bisect_right(x, (w.bbox[0] + w.bbox[2]) / 2) - 1))
            r = min(len(y) - 2, max(0, bisect_right(y, w.origin[1] - w.size * 0.4) - 1))
            cells[r * (len(x) - 1) + c].words.append(w.id)
        result.append(
            Block(
                f"p{page.number}-grid{len(result)}",
                "table",
                (x[0], y[0], x[-1], y[-1]),
                ids,
                cells,
                x,
                y,
                f"persistent-whitespace-{sensitivity % 3}",
                header_rows=1,
            )
        )
    return result


def rebuild(page, sensitivity=0):
    tables = detect_tables(page, sensitivity)
    assigned = {k for t in tables for k in t.words}
    rest = []
    for part in fragments(
        [w for w in page.words if w.id not in assigned], 0.55 + sensitivity * 0.1
    ):
        rest.append(
            Block(
                f"p{page.number}-column{len(rest)}",
                "paragraph",
                union([w.bbox for w in part]),
                [w.id for w in part],
                method="resegmented-whitespace",
            )
        )
    page.blocks = sorted(tables + rest, key=lambda b: (b.bbox[1], b.bbox[0]))
    page.diagnostics["table_actual"] = f"persistent-whitespace-{sensitivity}"


def export_tables(page, sensitivity=0):
    """Respect explicit / ruled / model-derived IR grids on the first export.

    Alignment-only guesses are the source of the old PDF export problem and
    are rebuilt. An explicit export error can also replace a trusted grid.
    """
    inferred = detect_tables(page, sensitivity)
    trusted = (
        [
            b
            for b in page.blocks
            if b.kind == "table"
            and b.method in ("tatr", "ruled", "manual", "xlsx-native")
            and len(b.x_edges) > 1
            and len(b.y_edges) > 1
            and b.cells
        ]
        if sensitivity == 0
        else []
    )
    return sorted(
        trusted
        + [b for b in inferred if not any(intersection(b.bbox, t.bbox) > 0 for t in trusted)],
        key=lambda b: (b.bbox[1], b.bbox[0]),
    )
