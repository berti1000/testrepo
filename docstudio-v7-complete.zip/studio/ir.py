"""Canonical, versioned JSON IR. Binary assets are immutable SHA256 references."""

from __future__ import annotations
import copy
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator
from reconstructor.model import Document, Page


class Profile(BaseModel):
    kind: Literal["text", "financial", "scanned", "mixed", "spreadsheet", "word"]
    label: str
    reasons: list[str]
    pages: int
    native_chars: int = 0
    raster_pages: int = 0


class IRDocument(BaseModel):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)
    schema_version: Literal["docstudio.ir/1.0"] = "docstudio.ir/1.0"
    coordinates: Literal["top-left; PDF points; normalized page"] = (
        "top-left; PDF points; normalized page"
    )
    filename: str
    sha256: str
    source_asset: str
    source_pdf_asset: str
    normalized_pdf_asset: str
    revision: int = Field(default=0, ge=0)
    profile: Profile
    pages: list[Page] = Field(min_length=1, max_length=60)
    options: dict = Field(default_factory=dict)
    warnings: list[str] = Field(default_factory=list)
    edits: list[dict] = Field(default_factory=list)
    provenance: list[dict] = Field(default_factory=list)

    @model_validator(mode="after")
    def validate_geometry(self):
        if [p.number for p in self.pages] != list(range(1, len(self.pages) + 1)):
            raise ValueError("Consecutive page numbers required")
        for page in self.pages:
            if not 0 < page.width <= 14400 or not 0 < page.height <= 14400:
                raise ValueError("Invalid page size")
            ids = {w.id for w in page.words}
            if len(ids) != len(page.words) or len(ids) > 16000:
                raise ValueError("Duplicate IDs or excessive word count")
            for w in page.words:
                a, b, c, d = w.bbox
                if (
                    not all(math.isfinite(v) for v in (*w.bbox, *w.origin, w.size))
                    or c <= a
                    or d <= b
                    or not 0 < w.size <= 1000
                ):
                    raise ValueError("Invalid word geometry")
                if len(w.text) > 4000 or w.confidence is not None and not 0 <= w.confidence <= 1:
                    raise ValueError("Invalid text/confidence")
                if w.render_scale is not None and not 0.1 <= w.render_scale <= 5:
                    raise ValueError("Invalid glyph scale")
            for block in page.blocks:
                refs = set(block.words) | {w for cell in block.cells for w in cell.words}
                if not refs <= ids:
                    raise ValueError("Dangling word reference")
        return self

    def dump(self):
        return self.model_dump_json(indent=2).encode("utf-8")


class AssetStore:
    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def put(self, data):
        key = hashlib.sha256(data).hexdigest()
        path = self.root / key
        if not path.exists():
            temp = path.with_suffix(".tmp")
            temp.write_bytes(data)
            temp.replace(path)
        return key

    def get(self, key):
        if not re.fullmatch("[a-f0-9]{64}", key):
            raise ValueError("Invalid asset ID")
        data = (self.root / key).read_bytes()
        if hashlib.sha256(data).hexdigest() != key:
            raise ValueError("Asset checksum mismatch")
        return data


def from_runtime(doc, store, profile):
    pages = copy.deepcopy(doc.pages)
    for page in pages:
        for im in page.images:
            data = im.pop("data", None)
            if data:
                im["asset"] = store.put(data)
    return IRDocument(
        filename=doc.filename,
        sha256=doc.sha256,
        profile=profile,
        pages=pages,
        source_asset=store.put(doc.original_input),
        source_pdf_asset=store.put(doc.source_pdf),
        normalized_pdf_asset=store.put(doc.normalized_pdf or doc.source_pdf),
        options=doc.options,
        warnings=doc.warnings,
        edits=doc.edits,
    )


def to_runtime(ir, store):
    pages = copy.deepcopy(ir.pages)
    for page in pages:
        for im in page.images:
            key = im.pop("asset", None)
            if key:
                im["data"] = store.get(key)
    return Document(
        ir.filename,
        ir.sha256,
        store.get(ir.source_pdf_asset),
        pages,
        warnings=ir.warnings[:],
        options=ir.options.copy(),
        edits=ir.edits[:],
        normalized_pdf=store.get(ir.normalized_pdf_asset),
        original_input=store.get(ir.source_asset),
    )


def write_schema(path):
    Path(path).write_text(json.dumps(IRDocument.model_json_schema(), ensure_ascii=False, indent=2))
