from pathlib import Path
import fitz
from .ir import Profile


def profile(data, filename, password=""):
    ext = Path(filename).suffix.lower()
    if ext == ".xlsx":
        return Profile(
            kind="spreadsheet",
            label="Natív munkafüzet",
            reasons=["OOXML cellák közvetlen beolvasása"],
            pages=1,
        )
    if ext == ".docx":
        return Profile(
            kind="word",
            label="Word-dokumentum",
            reasons=["LibreOffice oldalkép és natív szöveg"],
            pages=1,
        )
    if ext != ".pdf":
        return Profile(
            kind="scanned",
            label="Képi dokumentum",
            reasons=["Raszteres kép: OCR szükséges"],
            pages=1,
            raster_pages=1,
        )
    with fitz.open(stream=data, filetype="pdf") as doc:
        if doc.needs_pass and not doc.authenticate(password):
            raise ValueError("Hibás vagy hiányzó PDF-jelszó")
        if not 1 <= len(doc) <= 60:
            raise ValueError("PDF korlát: 1–60 oldal")
        chars = scanned = lines = 0
        for p in doc:
            chars += len(p.get_text())
            lines += len(p.get_drawings())
            scanned += any(
                (fitz.Rect(im["bbox"]) & p.rect).get_area() / p.rect.get_area() > 0.7
                for im in p.get_image_info()
            )
        text = " ".join(doc[i].get_text() for i in range(min(3, len(doc)))).lower()
        kind = (
            "financial"
            if any(s in text for s in ("számla", "invoice", "bruttó", "nettó")) or lines > 25
            else "scanned"
            if scanned == len(doc)
            else "mixed"
            if scanned
            else "text"
        )
        return Profile(
            kind=kind,
            label={
                "financial": "Táblázatos / pénzügyi",
                "scanned": "Szkennelt dokumentum",
                "mixed": "Vegyes dokumentum",
                "text": "Szövegnehéz / natív PDF",
            }[kind],
            reasons=[
                f"{len(doc)} oldal, {scanned} képi oldal",
                f"{chars} natív karakter; {lines} rajzelem",
            ],
            pages=len(doc),
            native_chars=chars,
            raster_pages=scanned,
        )
