"""Safe OOXML validation, isolated rendering, and native spreadsheet ingestion."""

import io
import os
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


def validate_ooxml(data, ext):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        items = z.infolist()
        required = "word/document.xml" if ext == ".docx" else "xl/workbook.xml"
        if required not in z.namelist() or len(items) > 10000:
            raise ValueError("Érvénytelen OOXML fájl")
        if sum(i.file_size for i in items) > 150 * 1024 * 1024:
            raise ValueError("Túl nagy kibontott Office-fájl")
        if any("vbaproject" in i.filename.lower() for i in items):
            raise ValueError("Makrós dokumentum nem támogatott")


def convert_pdf(data, ext):
    if ext not in (".docx", ".xlsx"):
        raise ValueError("DOCX vagy XLSX szükséges")
    validate_ooxml(data, ext)
    binary = shutil.which(os.getenv("SOFFICE", "libreoffice")) or shutil.which("soffice")
    if not binary:
        raise RuntimeError("LibreOffice szükséges a tényleges Word/Excel előnézethez")
    with tempfile.TemporaryDirectory(prefix="docstudio-office-") as directory:
        root = Path(directory)
        profile = root / "profile"
        (profile / "user").mkdir(parents=True)
        (
            profile / "user/registrymodifications.xcu"
        ).write_text("""<?xml version="1.0"?><oor:items xmlns:oor="http://openoffice.org/2001/registry">
<item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="MacroSecurityLevel" oor:op="fuse"><value>3</value></prop></item>
<item oor:path="/org.openoffice.Office.Writer/Content/Update"><prop oor:name="Link" oor:op="fuse"><value>0</value></prop></item>
<item oor:path="/org.openoffice.Office.Calc/Content/Update"><prop oor:name="Link" oor:op="fuse"><value>0</value></prop></item></oor:items>""")
        src = root / ("document" + ext)
        src.write_bytes(data)
        env = os.environ.copy()
        env["SAL_USE_VCLPLUGIN"] = "svp"
        env["XDG_CONFIG_HOME"] = str(root / "config")
        env["XDG_CACHE_HOME"] = str(root / "cache")
        result = subprocess.run(
            [
                binary,
                "-env:UserInstallation=" + profile.as_uri(),
                "--headless",
                "--nologo",
                "--nodefault",
                "--norestore",
                "--convert-to",
                "pdf",
                "--outdir",
                str(root),
                str(src),
            ],
            env=env,
            capture_output=True,
            timeout=120,
        )
        target = root / "document.pdf"
        if result.returncode or not target.exists():
            raise RuntimeError(
                f"Office render sikertelen (kilépési kód: {result.returncode}): "
                + (result.stdout + result.stderr).decode(errors="replace")[:400]
            )
        return target.read_bytes()


def spreadsheet_document(data, filename):
    import openpyxl
    from reconstructor.model import Document, Page, Word, Block, Cell, fingerprint
    from reconstructor.render import reconstructed_pdf

    validate_ooxml(data, ".xlsx")
    wb = openpyxl.load_workbook(io.BytesIO(data), data_only=False, keep_links=False)
    cached = openpyxl.load_workbook(io.BytesIO(data), data_only=True, keep_links=False)
    doc = Document(filename, fingerprint(data), b"", original_input=data)
    for ws in wb:
        if ws.max_row * ws.max_column > 50000 or ws.max_column > 100:
            raise ValueError("XLSX korlát: 50 000 cella, 100 oszlop laponként")
        used = [c for row in ws for c in row if c.value is not None]
        if not used:
            continue
        merges = [
            m for m in ws.merged_cells.ranges if ws.cell(m.min_row, m.min_col).value is not None
        ]
        lo = min(c.column for c in used)
        hi = max([c.column for c in used] + [m.max_col for m in merges])
        last = max([c.row for c in used] + [m.max_row for m in merges])
        for start in range(1, last + 1, 40):
            if len(doc.pages) >= 60:
                raise ValueError("XLSX legfeljebb 60 oldal")
            stop = min(last + 1, start + 40)
            number = len(doc.pages) + 1
            xs = [24.0]
            for c in range(lo, hi + 1):
                xs.append(
                    xs[-1]
                    + max(
                        40,
                        min(
                            180, ws.column_dimensions[openpyxl.utils.get_column_letter(c)].width * 5
                        ),
                    )
                )
            ys = [30.0 + (r - start) * 24 for r in range(start, stop + 1)]
            page = Page(number, max(595, xs[-1] + 24), max(200, ys[-1] + 24), mode="spreadsheet")
            cells = []
            for r in range(start, stop):
                for c in range(lo, hi + 1):
                    src = ws.cell(r, c)
                    span = next(
                        (m for m in merges if m.min_col == c and m.min_row <= r <= m.max_row), None
                    )
                    if isinstance(src, openpyxl.cell.cell.MergedCell):
                        if r != start or span is None:
                            continue
                        src = ws.cell(span.min_row, span.min_col)
                        page.warnings.append(
                            f"{ws.title}!{src.coordinate}: többoldalas egyesített cella folytatása"
                        )
                    value = src.value
                    if src.data_type == "f":
                        value = cached[ws.title].cell(r, c).value
                        if value is None:
                            value = src.value
                            page.warnings.append(
                                f"{ws.title}!{src.coordinate}: képlet tárolt érték nélkül; szövegként megőrizve"
                            )
                    text = "" if value is None else str(value)
                    rs = cs = 1
                    if span is not None:
                        rs = min(stop - r, span.max_row - r + 1)
                        cs = min(hi - c + 1, span.max_col - c + 1)
                    box = (xs[c - lo], ys[r - start], xs[c - lo + cs], ys[r - start + rs])
                    ids = []
                    if text:
                        w = Word(
                            f"p{number}-x{len(page.words) + 1}",
                            text,
                            (box[0] + 3, box[1] + 4, box[2] - 3, box[1] + 18),
                            (box[0] + 3, box[1] + 15),
                            min(14, float(src.font.sz or 10)),
                            bold=bool(src.font.b),
                            source="xlsx-native",
                            line_hint=f"row-{r}",
                        )
                        page.words.append(w)
                        ids = [w.id]
                    cells.append(Cell(r - start, c - lo, rs, cs, box, ids))
            page.blocks = [
                Block(
                    f"p{number}-sheet",
                    "table",
                    (xs[0], ys[0], xs[-1], ys[-1]),
                    [w.id for w in page.words],
                    cells,
                    xs,
                    ys,
                    "xlsx-native",
                    header_rows=1 if start == 1 else 0,
                )
            ]
            page.diagnostics = {
                "engine": "openpyxl-native",
                "sheet": ws.title,
                "first_row": start,
                "last_row": stop - 1,
            }
            doc.pages.append(page)
    if not doc.pages:
        doc.pages = [Page(1, 595, 842)]
    doc.source_pdf = doc.normalized_pdf = reconstructed_pdf(doc)
    return doc
