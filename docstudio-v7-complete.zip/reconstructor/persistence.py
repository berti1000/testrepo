"""Safe, versioned JSON snapshots; never execute pickle data."""

import base64
import gzip
import json
from dataclasses import asdict
from .model import Document, Page, Word, Block, Cell


def _encode(value):
    if isinstance(value, bytes):
        return {"__bytes__": base64.b64encode(value).decode("ascii")}
    if isinstance(value, dict):
        return {k: _encode(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_encode(v) for v in value]
    return value


def _decode(value):
    if isinstance(value, dict):
        if set(value) == {"__bytes__"}:
            return base64.b64decode(value["__bytes__"], validate=True)
        return {k: _decode(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_decode(v) for v in value]
    return value


def save(document, path):
    temp = path.with_suffix(".tmp")
    with gzip.open(temp, "wt", encoding="utf-8") as stream:
        json.dump(
            {"version": 4, "document": _encode(asdict(document))},
            stream,
            ensure_ascii=False,
            allow_nan=False,
        )
    temp.replace(path)


def load(path):
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        data = json.load(stream)
    if data["version"] != 4:
        raise ValueError("Unsupported snapshot version")
    raw = _decode(data["document"])
    pages = []
    for p in raw.pop("pages"):
        p["words"] = [Word(**w) for w in p["words"]]
        for b in p["blocks"]:
            b["cells"] = [Cell(**c) for c in b["cells"]]
        p["blocks"] = [Block(**b) for b in p["blocks"]]
        pages.append(Page(**p))
    return Document(**raw, pages=pages)
