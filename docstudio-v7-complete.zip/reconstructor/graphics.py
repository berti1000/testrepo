"""Preserve original curves/dots/ink; erase recognized text, never redraw strokes."""

import io
import cv2
import numpy as np
from PIL import Image
from .preprocess import line_masks


def preserve_graphics(image, page):
    pixels = np.array(image.convert("RGB"))
    gray = cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY)
    hsv = cv2.cvtColor(pixels, cv2.COLOR_RGB2HSV)
    colored = (hsv[:, :, 1] > 65) & (hsv[:, :, 2] < 245)
    h, v = line_masks(image)
    protected = (h | v) > 0
    sx, sy = image.width / page.width, image.height / page.height
    erase = np.zeros(gray.shape, np.uint8)
    retained = 0
    for word in page.words:
        if word.visual_artifact or not word.text:
            continue
        a, b, c, d = word.bbox
        x0, y0 = max(0, int(a * sx) - 2), max(0, int(b * sy) - 2)
        x1, y1 = (
            min(image.width, int(np.ceil(c * sx)) + 2),
            min(image.height, int(np.ceil(d * sy)) + 2),
        )
        patch = gray[y0:y1, x0:x1]
        if not patch.size:
            continue
        ink = patch < 180
        if (word.confidence or 0) < 0.75 and np.count_nonzero(
            colored[y0:y1, x0:x1] & ink
        ) > 0.35 * max(1, np.count_nonzero(ink)):
            word.visual_artifact = True
            retained += 1
            continue
        if np.count_nonzero(ink) > 0 and np.count_nonzero(
            colored[y0:y1, x0:x1] & ink
        ) > 0.35 * np.count_nonzero(ink):
            red, green, blue = np.median(pixels[y0:y1, x0:x1][ink], axis=0).astype(int)
            word.color = int(red * 65536 + green * 256 + blue)
        erase[y0:y1, x0:x1] = 255
    # Word-level CTC boxes may omit trailing glyphs on condensed receipts.
    # Remove the complete detected text line before laying out its words, so
    # an old glyph cannot remain beside the edited/reflowed replacement.
    eligible = {w.line_hint for w in page.words if w.text and not w.visual_artifact}
    retained_lines = {w.line_hint for w in page.words if w.visual_artifact}
    for region in page.diagnostics.get("text_line_regions", []):
        key = region.get("line_hint")
        if key not in eligible or key in retained_lines:
            continue
        a, b, c, d = region["bbox"]
        x0, y0 = max(0, int(a * sx) - 2), max(0, int(b * sy) - 2)
        x1, y1 = min(image.width, int(np.ceil(c * sx)) + 2), min(
            image.height, int(np.ceil(d * sy)) + 2
        )
        erase[y0:y1, x0:x1] = 255
    # CTC boxes sometimes trim a letter's edge. Erase the complete touched
    # glyph component, while retaining long rules and disconnected dots.
    foreground = ((gray < 180) & ~protected).astype("uint8")
    n, labels, stats, _ = cv2.connectedComponentsWithStats(foreground, 8)
    touched = np.bincount(labels[erase > 0], minlength=n) > 0
    typical = max(
        5, np.median([(w.bbox[3] - w.bbox[1]) * sy for w in page.words]) if page.words else 12
    )
    touched &= (stats[:, cv2.CC_STAT_WIDTH] < typical * 12) & (
        stats[:, cv2.CC_STAT_HEIGHT] < typical * 2.5
    )
    touched[0] = False
    erase[touched[labels]] = 255
    # Include antialiased fringes of touched glyph components.
    erase = cv2.dilate(erase, np.ones((3, 3), np.uint8))
    erase[protected] = 0
    # Local paper/fill color, without inventing replacement strokes.
    background = cv2.morphologyEx(pixels, cv2.MORPH_CLOSE, np.ones((17, 17), np.uint8))
    result = pixels.copy()
    result[erase > 0] = background[erase > 0]
    stream = io.BytesIO()
    Image.fromarray(result).save(stream, format="PNG", compress_level=3)
    # Keep detected rules for layout, but do not paint them over retained ink.
    page.paths = [p for p in page.paths if p.get("source") != "raster"]
    page.images = [
        p
        for p in page.images
        if p.get("source") not in ("isolated-raster-graphics", "source-graphics")
    ]
    page.images.append(
        dict(
            bbox=(0.0, 0.0, page.width, page.height),
            large=True,
            background=True,
            source="source-graphics",
            data=stream.getvalue(),
        )
    )
    page.diagnostics["graphics"] = dict(
        method="source ink minus recognized text",
        vector_redraw=False,
        retained_handwriting_candidates=retained,
    )
