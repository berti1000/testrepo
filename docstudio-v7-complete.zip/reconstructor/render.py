from __future__ import annotations
import base64
import html
import io
import math
import os
import re
from functools import lru_cache
from pathlib import Path
import fitz
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from .model import Document, Page, Word
from .locking import serialized


@lru_cache(maxsize=12)
def font_path(family: str = "sans", bold: bool = False, italic: bool = False) -> str:
    suffix = (
        "-BoldItalic"
        if bold and italic
        else "-Bold"
        if bold
        else "-Italic"
        if italic
        else "-Regular"
    )
    lib = {"sans": "LiberationSans", "serif": "LiberationSerif", "mono": "LiberationMono"}[family]
    candidates = [
        f"/usr/share/fonts/truetype/liberation2/{lib}{suffix}.ttf",
        f"/usr/share/fonts/truetype/liberation/{lib}{suffix}.ttf",
    ]
    dej = {"sans": "DejaVuSans", "serif": "DejaVuSerif", "mono": "DejaVuSansMono"}[family]
    d_suffix = (
        "-BoldOblique" if bold and italic else "-Bold" if bold else "-Oblique" if italic else ""
    )
    if family == "serif":
        d_suffix = d_suffix.replace("Oblique", "Italic")
    candidates += [f"/usr/share/fonts/truetype/dejavu/{dej}{d_suffix}.ttf"]
    win = {"sans": "arial", "serif": "times", "mono": "cour"}[family]
    win_suffix = "bi" if bold and italic else "bd" if bold else "i" if italic else ""
    candidates.append(
        str(Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts" / f"{win}{win_suffix}.ttf")
    )
    if os.environ.get("DOCUMENT_FONT_DIR"):
        candidates.insert(0, str(Path(os.environ["DOCUMENT_FONT_DIR"]) / f"{lib}{suffix}.ttf"))
    for path in candidates:
        if Path(path).is_file():
            return path
    if italic:
        return font_path(family, bold, False)
    if bold:
        return font_path(family, False, False)
    raise RuntimeError("A Unicode font is missing. Use Docker or install Liberation/DejaVu fonts.")


def font_family(name: str) -> str:
    n = name.lower()
    if any(s in n for s in ("courier", "mono", "consolas")):
        return "mono"
    if any(s in n for s in ("times", "serif", "cambria", "georgia")) and "sans" not in n:
        return "serif"
    return "sans"


@lru_cache(maxsize=12)
def registered_font(family="sans", bold=False, italic=False) -> str:
    name = f"Reconstruction-{family}-{int(bold)}-{int(italic)}"
    pdfmetrics.registerFont(TTFont(name, font_path(family, bold, italic)))
    return name


def font_for(word: Word) -> str:
    return registered_font(font_family(word.font), word.bold, word.italic)


def rgb(value, default=(0.0, 0.0, 0.0)):
    if value is None:
        return default
    if isinstance(value, int):
        return ((value >> 16 & 255) / 255, (value >> 8 & 255) / 255, (value & 255) / 255)
    vals = list(value)
    if len(vals) == 1:
        return tuple([float(vals[0])] * 3)
    if len(vals) == 4:
        c, m, y, k = vals
        return ((1 - c) * (1 - k), (1 - m) * (1 - k), (1 - y) * (1 - k))
    return tuple(max(0.0, min(1.0, float(x))) for x in vals[:3])


def hex_color(value) -> str:
    return "".join(f"{round(v * 255):02X}" for v in rgb(value))


def _draw_paths(c, page: Page):
    c.saveState()
    c.transform(1, 0, 0, -1, 0, page.height)
    for item in page.paths:
        c.saveState()
        c.setLineWidth(max(0.05, float(item.get("width") or 0.6)))
        cap = item.get("line_cap", (0, 0, 0))
        cap = cap[0] if isinstance(cap, (list, tuple)) else cap
        c.setLineCap(int(cap or 0))
        c.setLineJoin(int(item.get("line_join") or 0))
        dash = re.match(r"\[([^\]]*)\]\s*([\d.-]+)", (item.get("dashes") or "[] 0"))
        if dash:
            parts = [float(v) for v in dash.group(1).split() if float(v) > 0]
            if parts:
                c.setDash(parts, float(dash.group(2)))
        stroke = item.get("color") is not None
        fill = item.get("fill") is not None
        if stroke:
            c.setStrokeColorRGB(*rgb(item["color"]))
        if fill:
            c.setFillColorRGB(*rgb(item["fill"]))
        c.setStrokeAlpha(float(item.get("stroke_opacity", 1) or 0))
        c.setFillAlpha(float(item.get("fill_opacity", 1) or 0))
        path = c.beginPath()
        last = None
        for primitive in item["items"]:
            kind = primitive[0]
            if kind == "l":
                a, b = primitive[1:3]
                if last is None or math.dist(last, a) > 0.05:
                    path.moveTo(*a)
                path.lineTo(*b)
                last = b
            elif kind == "c":
                a, b, d, e = primitive[1:5]
                if last is None or math.dist(last, a) > 0.05:
                    path.moveTo(*a)
                path.curveTo(*b, *d, *e)
                last = e
            elif kind == "re":
                x0, y0, x1, y1 = primitive[1]
                if len(primitive) > 2 and primitive[2] < 0:
                    path.moveTo(x0, y0)
                    path.lineTo(x0, y1)
                    path.lineTo(x1, y1)
                    path.lineTo(x1, y0)
                    path.close()
                else:
                    path.rect(x0, y0, x1 - x0, y1 - y0)
                last = None
            elif kind == "qu":
                path.moveTo(*primitive[1])
                for point in primitive[2:]:
                    path.lineTo(*point)
                path.close()
                last = None
        if item.get("close") and last is not None:
            path.close()
        c.drawPath(
            path, stroke=int(stroke), fill=int(fill), fillMode=0 if item.get("even_odd") else 1
        )
        c.restoreState()
    c.restoreState()


def word_scale(word: Word, font: str) -> float:
    natural = pdfmetrics.stringWidth(word.text, font, word.size)
    if natural <= 0:
        return 1.0
    dx, dy = word.direction
    if abs(dy) < 0.12:
        width = word.bbox[2] - word.bbox[0]
    elif abs(dx) < 0.12:
        width = word.bbox[3] - word.bbox[1]
    else:
        return 1.0
    return max(
        0.1, min(5.0, width / natural, word.render_scale if word.render_scale is not None else 5.0)
    )


def draw_page(c, page: Page):
    for image in page.images:
        if image.get("data") and image.get("background") and not image.get("word_id"):
            c.drawImage(
                ImageReader(io.BytesIO(image["data"])), 0, 0, width=page.width, height=page.height
            )
    _draw_paths(c, page)
    for image in page.images:
        if image.get("data") and not image.get("background"):
            x0, y0, x1, y1 = image["bbox"]
            c.drawImage(
                ImageReader(io.BytesIO(image["data"])),
                x0,
                page.height - y1,
                width=x1 - x0,
                height=y1 - y0,
                mask="auto",
            )
    index = page.index()
    fragments = {}
    for image in page.images:
        word = index.get(image.get("word_id"))
        if word and word.text and not word.reviewed and word.original_text is None:
            fragments[word.id] = image
            x0, y0, x1, y1 = image["bbox"]
            c.drawImage(
                ImageReader(io.BytesIO(image["data"])),
                x0,
                page.height - y1,
                width=x1 - x0,
                height=y1 - y0,
            )
    for word in page.words:
        if word.id in fragments:
            continue
        if word.visual_artifact and not word.reviewed and word.original_text is None:
            continue
        if not word.text:
            continue
        c.saveState()
        c.translate(word.origin[0], page.height - word.origin[1])
        c.rotate(-math.degrees(math.atan2(word.direction[1], word.direction[0])))
        c.setFillColorRGB(*rgb(word.color))
        c.setFillAlpha(word.alpha)
        font = font_for(word)
        text = c.beginText(0, 0)
        text.setFont(font, word.size)
        text.setHorizScale(word_scale(word, font) * 100)
        text.textOut(word.text)
        c.drawText(text)
        c.restoreState()


@serialized
def reconstructed_pdf(document: Document, pages: list[Page] | None = None) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pageCompression=1, invariant=1)
    c.setTitle("Reconstructed document")
    c.setAuthor("Document Reconstructor")
    for page in document.pages if pages is None else pages:
        fragments = {im.get("word_id") for im in page.images if im.get("word_id")}
        for word in page.words:
            if word.id in fragments and not word.reviewed and word.original_text is None:
                continue
            font = font_for(word)
            glyphs = pdfmetrics.getFont(font).face.charToGlyph
            missing = {
                ord(ch) for ch in word.text if not ch.isspace() and not glyphs.get(ord(ch), 0)
            }
            if missing:
                codes = ", ".join(f"U+{n:04X}" for n in sorted(missing)[:5])
                raise ValueError(
                    "The substitute font cannot render "
                    + codes
                    + ". Use the source-preserving PDF or configure a suitable Unicode font."
                )
        c.setPageSize((page.width, page.height))
        draw_page(c, page)
        c.showPage()
    c.save()
    return buf.getvalue()


@serialized
def preserved_pdf(document):
    """Untouched source PDF, or losslessly embedded original image pixels."""
    if b"%PDF-" in document.original_input[:1024]:
        return document.original_input
    return document.source_pdf


@serialized
def searchable_pdf(document):
    """Normalized page appearance plus an invisible, fitted Unicode text layer."""
    with fitz.open(stream=document.normalized_pdf or document.source_pdf, filetype="pdf") as pdf:
        for index, page in enumerate(document.pages):
            if not page.ocr_ran:
                if any(
                    w.original_text is not None and w.original_text != w.text for w in page.words
                ):
                    with fitz.open(
                        stream=reconstructed_pdf(document, [page]), filetype="pdf"
                    ) as corrected:
                        pdf.delete_page(index)
                        pdf.insert_pdf(corrected, start_at=index)
                continue
            source = pdf[index]
            source.insert_font(fontname="UnicodeOCR", fontfile=font_path())
            font = fitz.Font(fontfile=font_path())
            for word in page.words:
                if not word.text:
                    continue
                natural = font.text_length(word.text, fontsize=word.size)
                scale = (word.bbox[2] - word.bbox[0]) / max(0.1, natural)
                origin = fitz.Point(*word.origin)
                source.insert_text(
                    origin,
                    word.text,
                    fontname="UnicodeOCR",
                    fontsize=word.size,
                    render_mode=3,
                    morph=(origin, fitz.Matrix(scale, 1)),
                )
        return pdf.tobytes(garbage=3, deflate=True)


@serialized
def page_png(document, page_number=1, dpi=120, original=False, source=False):
    if source:
        payload = document.source_pdf
    elif original:
        payload = document.normalized_pdf or document.source_pdf
    else:
        payload = reconstructed_pdf(document, [document.pages[page_number - 1]])
    with fitz.open(stream=payload, filetype="pdf") as pdf:
        page = pdf[page_number - 1 if original or source else 0]
        scale = min(dpi / 72, math.sqrt(18_000_000 / page.rect.get_area()))
        return page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).tobytes("png")


@serialized
def page_svg(document: Document, page_number: int = 1) -> str:
    with fitz.open(
        stream=reconstructed_pdf(document, [document.pages[page_number - 1]]), filetype="pdf"
    ) as pdf:
        svg = pdf[0].get_svg_image(text_as_path=True)
        prefix = f"p{page_number}_"
        svg = re.sub(r'id="([^"]+)"', lambda m: 'id="' + prefix + m.group(1) + '"', svg)
        svg = re.sub(r'href="#([^"]+)"', lambda m: 'href="#' + prefix + m.group(1) + '"', svg)
        svg = re.sub(r"url\(#([^)]+)\)", lambda m: "url(#" + prefix + m.group(1) + ")", svg)
        return svg


def canvas_html(document: Document, page_number: int = 1, debug: bool = False) -> str:
    page = document.pages[page_number - 1]
    svg = page_svg(document, page_number)
    original = base64.b64encode(page_png(document, page_number, 120, True)).decode("ascii")
    boxes = []
    for word in page.words:
        low = word.needs_review
        if not debug and not low:
            continue
        x0, y0, x1, y1 = word.bbox
        color = "#c97300" if low else "#1565c0"
        boxes.append(
            f'<rect x="{x0}" y="{y0}" width="{x1 - x0}" height="{y1 - y0}" fill="none" stroke="{color}" stroke-width=".5"><title>{html.escape(word.id + ": " + word.text)}</title></rect>'
        )
    if debug:
        for block in page.blocks:
            if block.kind == "table":
                for cell in block.cells:
                    x0, y0, x1, y1 = cell.bbox
                    boxes.append(
                        f'<rect x="{x0}" y="{y0}" width="{x1 - x0}" height="{y1 - y0}" fill="none" stroke="#6a1b9a" stroke-width=".4"/>'
                    )
    return f"""<!doctype html><html lang="hu"><head><meta charset="utf-8"><style>
    body{{margin:0;font:13px sans-serif;background:#f0f2f5;color:#223}}
    .toolbar{{display:flex;gap:12px;padding:10px;align-items:center;position:sticky;top:0;background:#fff;z-index:5}}
    .scroll{{height:680px;overflow:auto;padding:12px;box-sizing:border-box}}
    .paper{{width:100%;position:relative;background:white;box-shadow:0 3px 10px #bbc}}
    .paper>svg{{width:100%;height:auto;display:block}}
    .overlay,.boxes{{position:absolute;inset:0;width:100%;height:100%;pointer-events:none}}
    </style></head><body><div class="toolbar">
    <label>Nagyitas <input type="range" min="60" max="220" value="100" oninput="document.getElementById('paper').style.width=this.value+'%'"/></label>
    <label>Eredeti ravetitese <input type="range" min="0" max="100" value="0" oninput="document.getElementById('original').style.opacity=this.value/100"/></label>
    </div><div class="scroll"><div class="paper" id="paper">{svg}
    <svg class="boxes" viewBox="0 0 {page.width} {page.height}">{"".join(boxes)}</svg>
    <img class="overlay" id="original" style="opacity:0" src="data:image/png;base64,{original}"/>
    </div></div></body></html>"""


def standalone_html(document: Document) -> bytes:
    pages = "\n".join(
        "<section>" + page_svg(document, i + 1) + "</section>" for i in range(len(document.pages))
    )
    return (
        """<!doctype html><html><head><meta charset="utf-8"><title>Reconstructed document</title>
<style>body{background:#eee;margin:20px}section{background:white;max-width:1100px;margin:20px auto;page-break-after:always}svg{width:100%;height:auto}@media print{body{margin:0;background:white}section{margin:0;max-width:none}}</style></head><body>"""
        + pages
        + "</body></html>"
    ).encode("utf-8")
