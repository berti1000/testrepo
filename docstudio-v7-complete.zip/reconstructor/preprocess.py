"""Conservative normalization; untouched source is kept separately for visual fidelity."""

import cv2
import numpy as np
from PIL import Image

cv2.setNumThreads(1)


def flatten(image):
    if image.mode in ("RGBA", "LA") or "transparency" in image.info:
        rgba = image.convert("RGBA")
        bg = Image.new("RGBA", image.size, "white")
        bg.alpha_composite(rgba)
        return bg.convert("RGB")
    return image.convert("RGB")


def contrast(image):
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
    bg = cv2.GaussianBlur(gray, (0, 0), 25)
    return Image.fromarray(cv2.divide(gray, bg, scale=255))


def line_masks(image):
    gray = cv2.cvtColor(np.array(image.convert("RGB")), cv2.COLOR_RGB2GRAY)
    inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    h, w = inv.shape
    a = cv2.morphologyEx(
        inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (max(40, w // 35), 1))
    )
    b = cv2.morphologyEx(
        inv, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (1, max(40, h // 35)))
    )
    return a, b


def without_lines(image):
    a, b = line_masks(image)
    return Image.fromarray(cv2.inpaint(np.array(image.convert("RGB")), a | b, 2, cv2.INPAINT_TELEA))


def perspective(image):
    arr = np.array(image)
    scale = min(1, 1400 / max(image.size))
    gray = cv2.cvtColor(cv2.resize(arr, None, fx=scale, fy=scale), cv2.COLOR_RGB2GRAY)
    edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 50, 150)
    edges = cv2.morphologyEx(edges, cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for c in sorted(contours, key=cv2.contourArea, reverse=True)[:8]:
        fraction = cv2.contourArea(c) / gray.size
        p = cv2.approxPolyDP(c, 0.02 * cv2.arcLength(c, True), True)
        if len(p) != 4 or not cv2.isContourConvex(p) or not 0.35 < fraction < 0.97:
            continue
        pts = p.reshape(4, 2).astype("float32") / scale
        center = pts.mean(axis=0)
        pts = pts[np.argsort(np.arctan2(pts[:, 1] - center[1], pts[:, 0] - center[0]))]
        pts = np.roll(pts, -int(np.argmin(pts.sum(axis=1))), axis=0)
        tl, tr, br, bl = pts
        w = int(max(np.linalg.norm(tr - tl), np.linalg.norm(br - bl)))
        h = int(max(np.linalg.norm(bl - tl), np.linalg.norm(br - tr)))
        if min(w, h) < 150 or not 0.35 < w / h < 2.9:
            continue
        mask = np.zeros(gray.shape, np.uint8)
        cv2.fillConvexPoly(mask, (pts * scale).astype("int32"), 255)
        outside = gray[mask == 0]
        if len(outside) < 100 or np.median(gray[mask > 0]) - np.median(outside) < 15:
            continue
        m = cv2.getPerspectiveTransform(
            pts, np.float32([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]])
        )
        return Image.fromarray(
            cv2.warpPerspective(arr, m, (w, h), borderValue=(255, 255, 255))
        ), m.tolist()
    return image, None


def deskew(image):
    scale = min(1, 1500 / max(image.size))
    gray = cv2.cvtColor(cv2.resize(np.array(image), None, fx=scale, fy=scale), cv2.COLOR_RGB2GRAY)
    inv = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    joined = cv2.dilate(inv, cv2.getStructuringElement(cv2.MORPH_RECT, (25, 1)))
    lines = cv2.HoughLinesP(
        joined, 1, np.pi / 1800, 80, minLineLength=max(70, gray.shape[1] // 9), maxLineGap=15
    )
    angles = []
    if lines is not None:
        for x1, y1, x2, y2 in lines.reshape(-1, 4):
            angle = float(np.degrees(np.arctan2(y2 - y1, x2 - x1)))
            if abs(angle) < 8:
                angles.append(angle)
    if len(angles) < 5:
        return image, 0.0
    angle = float(np.median(angles))
    if abs(angle) < 0.25 or np.median(np.abs(np.array(angles) - angle)) > 1.2:
        return image, 0.0
    return image.rotate(angle, Image.Resampling.BICUBIC, expand=True, fillcolor="white"), angle


def prepare(image, options):
    from .ocr import orient

    image = flatten(image)
    steps = []
    warnings = []
    if options.perspective:
        image, m = perspective(image)
        if m is not None:
            steps.append({"perspective_matrix": m})
        else:
            warnings.append("Nem találtam biztos lapkontúrt; perspektíva változatlan.")
    angle = options.rotation
    if angle:
        image = image.rotate(-angle, expand=True, fillcolor="white")
    elif options.orientation:
        image, angle, score = orient(image, options.languages)
    steps.append({"clockwise_orientation": angle})
    if options.deskew:
        image, skew = deskew(image)
        if skew:
            steps.append({"deskew_degrees": round(skew, 3)})
    if image.width * image.height > options.max_pixels:
        scale = (options.max_pixels / (image.width * image.height)) ** 0.5
        image = image.resize(
            (int(image.width * scale), int(image.height * scale)), Image.Resampling.LANCZOS
        )
    return image, steps, warnings
