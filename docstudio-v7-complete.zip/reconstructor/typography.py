"""Bound OCR text by measured word slots and neighboring baselines."""

from collections import defaultdict
from statistics import median


def constrain_ocr_geometry(page):
    groups = defaultdict(list)
    for w in page.words:
        if w.text and not w.visual_artifact:
            groups[w.line_hint or f"y{round(w.origin[1])}"].append(w)
    typical = (
        median(w.size for ws in groups.values() for w in ws if len(w.text) > 3)
        if any(len(w.text) > 3 for ws in groups.values() for w in ws)
        else 12
    )
    for ws in groups.values():
        for w in ws:
            if len(w.text) <= 3 and any(c.isdigit() for c in w.text) and w.size > typical * 1.6:
                w.size = typical
                w.origin = (w.bbox[0], w.bbox[3])
    adjusted = 0
    lines = []
    for words in groups.values():
        words.sort(key=lambda w: w.bbox[0])
        for left, right in zip(words, words[1:]):
            if left.bbox[0] + 1 < right.bbox[0] < left.bbox[2]:
                left.bbox = (
                    *left.bbox[:2],
                    max(left.bbox[0] + 1, right.bbox[0] - 0.4),
                    left.bbox[3],
                )
                adjusted += 1
        lines.append((median(w.origin[1] for w in words), words))
    lines.sort(key=lambda v: v[0])
    for i, (baseline, words) in enumerate(lines):
        for other_base, other in lines[i + 1 : i + 9]:
            gap = other_base - baseline
            if gap <= 2:
                continue
            if gap > max(w.size for w in words) * 2:
                break
            if min(max(w.bbox[2] for w in words), max(w.bbox[2] for w in other)) <= max(
                min(w.bbox[0] for w in words), min(w.bbox[0] for w in other)
            ):
                continue
            needed = 0.23 * max(w.size for w in words) + 0.86 * max(w.size for w in other) + 0.8
            if needed > gap:
                factor = max(0.5, (gap - 0.8) / max(1, needed - 0.8))
                for w in words + other:
                    w.size = max(2, w.size * factor)
                adjusted += 1
            break
    # CTC word boxes are less reliable than line bounds. Allocate readable
    # advances inside each line fragment; retain genuine inter-column gaps.
    from reportlab.pdfbase import pdfmetrics
    from .render import font_for

    for _, words in lines:
        fragments = []
        for w in words:
            if not fragments or w.bbox[0] - fragments[-1][-1].bbox[2] > max(10, w.size * 1.7):
                fragments.append([w])
            else:
                fragments[-1].append(w)
        for group in fragments:
            if len(group) < 2:
                continue
            left = min(w.bbox[0] for w in group)
            right = max(w.bbox[2] for w in group)
            advances = [pdfmetrics.stringWidth(w.text, font_for(w), w.size) for w in group]
            spaces = [pdfmetrics.stringWidth(" ", font_for(w), w.size) for w in group[:-1]]
            scale = max(0.1, min(5, (right - left) / max(1, sum(advances) + sum(spaces))))
            x = left
            for i, w in enumerate(group):
                width = max(0.5, advances[i] * scale)
                w.bbox = (x, w.bbox[1], x + width, w.bbox[3])
                w.origin = (x, w.origin[1])
                w.render_scale = scale
                x += width + (spaces[i] * scale if i < len(spaces) else 0)
    page.diagnostics["typography_collision_adjustments"] = adjusted


def reflow_edited_word(page, token):
    """Make room for an enlarged word inside its line/cell without overlap."""
    field = next((c for b in page.blocks for c in b.cells if token.id in c.words), None)
    allowed = set(field.words) if field else None
    peers = [
        w
        for w in page.words
        if w.id == token.id
        or (
            (allowed is None or w.id in allowed)
            and w.line_hint == token.line_hint
            and abs(w.origin[1] - token.origin[1]) < max(3, token.size * 0.5)
            and abs(w.direction[1]) < 0.1
        )
    ]
    peers.sort(key=lambda w: w.bbox[0])
    start = peers.index(token)
    cursor = token.bbox[2]
    moved = 0
    for w in peers[start + 1 :]:
        gap = max(0.8, min(w.size, token.size) * 0.2)
        delta = max(0, cursor + gap - w.bbox[0])
        if delta:
            a, b, c, d = w.bbox
            w.bbox = (a + delta, b, c + delta, d)
            w.origin = (w.origin[0] + delta, w.origin[1])
            moved += 1
        cursor = w.bbox[2]
    left = peers[0].bbox[0]
    right = field.bbox[2] - 1 if field else page.width - 4
    end = max(w.bbox[2] for w in peers)
    if end > right and right > left:
        scale = (right - left) / (end - left)
        for w in peers:
            a, b, c, d = w.bbox
            w.bbox = (left + (a - left) * scale, b, left + (c - left) * scale, d)
            w.origin = (w.bbox[0], w.origin[1])
            w.render_scale = None
    return moved


def unify_document_fonts(document):
    """Use a dominant family for ambiguous scan pages; keep strong differences."""
    from collections import Counter
    from .render import font_family

    pages = [p for p in document.pages if p.ocr_ran]
    votes = Counter()
    for p in pages:
        for w in p.words:
            if not w.visual_artifact:
                votes[font_family(w.font)] += len(w.text)
    if not votes:
        return
    dominant = votes.most_common(1)[0][0]
    names = {"sans": "Liberation Sans", "serif": "Liberation Serif", "mono": "Liberation Mono"}
    for p in pages:
        info = p.diagnostics.get("typography", {})
        if (
            info.get("font_family_approximation") != dominant
            and info.get("font_family_margin", 1) < 0.10
        ):
            for w in p.words:
                w.font = names[dominant]
                w.render_scale = None
            constrain_ocr_geometry(p)
            p.diagnostics["document_font_normalized"] = dominant
