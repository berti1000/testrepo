from __future__ import annotations

import io
import math
import time
import os
from .locking import serialized
import warnings
from dataclasses import asdict

import fitz
import numpy as np
from PIL import Image, ImageOps, ImageSequence

from .model import Document, Options, Page, Word, fingerprint
from .geometry import area, clean, deduplicate, union


class DocumentError(RuntimeError):
    pass


def _point(p):
    return [float(p.x), float(p.y)]


def _rect(r):
    return tuple(float(v) for v in r)


def _quality(words: list[Word]) -> bool:
    text = "".join(w.text for w in words)
    if not text:
        return False
    bad = sum(c == "\ufffd" or ord(c) < 32 or 0xE000 <= ord(c) <= 0xF8FF for c in text)
    return bad / len(text) < 0.025


def native_words(page: fitz.Page, number: int) -> list[Word]:
    # Inhibit inline image extraction here: images are handled separately with masks.
    raw = page.get_text("rawdict", flags=fitz.TEXTFLAGS_RAWDICT & ~fitz.TEXT_PRESERVE_IMAGES)
    words = []
    for bi, block in enumerate(raw.get("blocks", [])):
        for li, line in enumerate(block.get("lines", [])):
            direction = tuple(float(v) for v in line.get("dir", (1, 0)))
            for span in line.get("spans", []):
                chars = span.get("chars", [])
                groups, current = [], []
                size = float(span.get("size", 10))
                for ch in chars:
                    value = ch.get("c", "")
                    if value.isspace():
                        if current:
                            groups.append(current)
                            current = []
                        continue
                    # Some PDFs position every glyph and omit actual space characters.
                    if current and abs(direction[1]) < 0.1:
                        gap = ch["bbox"][0] - current[-1]["bbox"][2]
                        if gap > max(1.1, size * 0.2):
                            groups.append(current)
                            current = []
                    current.append(ch)
                if current:
                    groups.append(current)
                flags = int(span.get("flags", 0))
                for group in groups:
                    text = clean("".join(c.get("c", "") for c in group))
                    if not text:
                        continue
                    bbox = union([_rect(c["bbox"]) for c in group])
                    if not all(math.isfinite(x) for x in bbox) or not 0 < size < 1000:
                        continue
                    # size and origin are font metrics, NOT glyph-box height/bottom.
                    words.append(
                        Word(
                            id=f"p{number}-w{len(words) + 1}",
                            text=text,
                            bbox=bbox,
                            origin=tuple(float(x) for x in group[0].get("origin", span["origin"])),
                            size=size,
                            font=span.get("font", "Helvetica"),
                            bold=bool(flags & 16),
                            italic=bool(flags & 2),
                            superscript=bool(flags & 1),
                            color=int(span.get("color", 0)),
                            alpha=float(span.get("alpha", 255)) / 255,
                            direction=direction,
                            line_hint=f"n-{bi}-{li}",
                            source="native",
                        )
                    )
    return deduplicate(words)


def _add_rule(out: Page, a, b, width=0.6, color=None, source="native"):
    x0, y0 = a
    x1, y1 = b
    if abs(y1 - y0) <= 0.65 and abs(x1 - x0) >= 5:
        rule = dict(axis="h", pos=(y0 + y1) / 2, start=min(x0, x1), end=max(x0, x1))
    elif abs(x1 - x0) <= 0.65 and abs(y1 - y0) >= 5:
        rule = dict(axis="v", pos=(x0 + x1) / 2, start=min(y0, y1), end=max(y0, y1))
    else:
        return
    rule.update(width=float(width), color=color or (0, 0, 0), source=source)
    if not any(
        r["axis"] == rule["axis"]
        and abs(r["pos"] - rule["pos"]) < 0.6
        and abs(r["start"] - rule["start"]) < 1
        and abs(r["end"] - rule["end"]) < 1
        for r in out.rules
    ):
        out.rules.append(rule)


def native_graphics(page: fitz.Page, out: Page):
    for path in page.get_drawings():
        items = []
        for item in path.get("items", []):
            kind = item[0]
            if kind == "l":
                a, b = _point(item[1]), _point(item[2])
                items.append(["l", a, b])
                if path.get("color") is not None:
                    _add_rule(out, a, b, path.get("width", 0.6), path.get("color"))
            elif kind == "c":
                items.append(["c", *[_point(p) for p in item[1:5]]])
            elif kind == "re":
                rect = _rect(item[1])
                items.append(["re", list(rect), item[2] if len(item) > 2 else 1])
                x0, y0, x1, y1 = rect
                if path.get("color") is not None:
                    for a, b in [
                        ((x0, y0), (x1, y0)),
                        ((x1, y0), (x1, y1)),
                        ((x1, y1), (x0, y1)),
                        ((x0, y1), (x0, y0)),
                    ]:
                        _add_rule(out, a, b, path.get("width", 0.6), path.get("color"))
                # Filled hairline rectangles are genuine rules too.
                if path.get("fill") is not None:
                    if 0 < y1 - y0 <= 2.5:
                        _add_rule(
                            out, (x0, (y0 + y1) / 2), (x1, (y0 + y1) / 2), y1 - y0, path["fill"]
                        )
                    if 0 < x1 - x0 <= 2.5:
                        _add_rule(
                            out, ((x0 + x1) / 2, y0), ((x0 + x1) / 2, y1), x1 - x0, path["fill"]
                        )
            elif kind == "qu":
                q = item[1]
                items.append(["qu", *[_point(p) for p in [q.ul, q.ur, q.lr, q.ll]]])
            else:
                out.warnings.append(
                    f"Unsupported vector primitive: {kind}. Use source-preserving PDF for exact appearance."
                )
        out.paths.append(
            dict(
                items=items,
                color=path.get("color"),
                fill=path.get("fill"),
                width=path.get("width", 0.6),
                dashes=path.get("dashes", "[] 0"),
                close=path.get("closePath", False),
                even_odd=path.get("even_odd", False),
                line_cap=path.get("lineCap", (0, 0, 0)),
                line_join=path.get("lineJoin", 0),
                stroke_opacity=path.get("stroke_opacity", 1),
                fill_opacity=path.get("fill_opacity", 1),
                bbox=list(path.get("rect", page.rect)),
                source="native",
            )
        )
    # Capture displayed image occurrences (also inline images). Cropped render includes
    # transparency/masks and is safer than guessing an image's placement transform.
    # Text overlapping a small image is excluded from the crop when possible.
    for info in page.get_image_info(xrefs=True):
        bbox = _rect(fitz.Rect(info["bbox"]) & page.rect)
        if area(bbox) < 4:
            continue
        fraction = area(bbox) / max(1, out.width * out.height)
        if fraction > 0.45:
            out.images.append(dict(bbox=bbox, large=True, data=None))
            continue
        try:
            xref = int(info.get("xref", 0))
            if not xref:
                raise ValueError("inline image without an addressable object")
            base = fitz.Pixmap(page.parent, xref)
            meta = page.parent.extract_image(xref)
            if meta.get("smask"):
                base = fitz.Pixmap(base, fitz.Pixmap(page.parent, meta["smask"]))
            if base.colorspace and base.colorspace.n not in (1, 3):
                base = fitz.Pixmap(fitz.csRGB, base)
            im = Image.open(io.BytesIO(base.tobytes("png"))).convert("RGBA")
            a, b, c, d, e, f = info["transform"]
            scale = 2.0
            matrix = (
                np.array([[a / im.width, c / im.height], [b / im.width, d / im.height]]) * scale
            )
            inv = np.linalg.inv(matrix)
            offset = -inv @ np.array([(e - bbox[0]) * scale, (f - bbox[1]) * scale])
            coefficients = (inv[0, 0], inv[0, 1], offset[0], inv[1, 0], inv[1, 1], offset[1])
            im = im.transform(
                (
                    max(1, round((bbox[2] - bbox[0]) * scale)),
                    max(1, round((bbox[3] - bbox[1]) * scale)),
                ),
                Image.Transform.AFFINE,
                coefficients,
                Image.Resampling.BICUBIC,
            )
            buf = io.BytesIO()
            im.save(buf, format="PNG")
            out.images.append(dict(bbox=bbox, large=False, data=buf.getvalue()))
        except Exception:
            # Appearance fallback, explicitly flagged; never quietly claim exact image separation.
            pix = page.get_pixmap(clip=fitz.Rect(bbox), dpi=144, alpha=False)
            out.images.append(dict(bbox=bbox, large=False, data=pix.tobytes("png")))
            out.warnings.append(
                "An inline/complex image uses an appearance crop. Check for overlapping text in reconstruction."
            )
    if any(abs(w.direction[1]) > 0.01 for w in out.words):
        out.warnings.append(
            "Rotated text is preserved in the visual output; semantic reading order requires checking."
        )
    if page.annots():
        if next(page.annots(), None) is not None:
            out.warnings.append(
                "Annotations/form appearances are guaranteed only in the source-preserving PDF, not editable reconstruction."
            )


def image_pdf(data: bytes, options: Options) -> bytes:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            image = Image.open(io.BytesIO(data))
            count = getattr(image, "n_frames", 1)
            if count > options.max_pages:
                raise DocumentError("Too many image frames/pages.")
            doc = fitz.open()
            for frame in ImageSequence.Iterator(image):
                if frame.width * frame.height > options.max_pixels:
                    raise DocumentError("Image exceeds the configured pixel limit.")
                from .preprocess import flatten

                im = flatten(ImageOps.exif_transpose(frame))
                dpi = frame.info.get("dpi", (300, 300))
                try:
                    dx, dy = float(dpi[0]), float(dpi[1])
                except (TypeError, ValueError, IndexError):
                    dx = dy = 300
                if not 72 <= dx <= 1200 or not 72 <= dy <= 1200:
                    dx = dy = 300
                width, height = im.width * 72 / dx, im.height * 72 / dy
                p = doc.new_page(width=width, height=height)
                buf = io.BytesIO()
                im.save(buf, format="PNG")
                p.insert_image(p.rect, stream=buf.getvalue())
            result = doc.tobytes(garbage=3, deflate=True)
            doc.close()
            return result
    except DocumentError:
        raise
    except Exception as exc:
        raise DocumentError(f"Cannot read image: {exc}") from exc


def prepare_pdf(data: bytes, filename: str, options: Options, password: str = "") -> bytes:
    options.validate()
    if not data or len(data) > options.max_bytes:
        raise DocumentError("Empty input or file exceeds upload limit.")
    if b"%PDF-" not in data[:1024]:
        return image_pdf(data, options)
    try:
        with fitz.open(stream=data, filetype="pdf") as doc:
            if doc.needs_pass and not doc.authenticate(password):
                raise DocumentError("This PDF needs the correct password.")
            if len(doc) > options.max_pages or len(doc) == 0:
                raise DocumentError("PDF page count is outside the configured limit.")
            for page in doc:
                if max(page.rect.width, page.rect.height) > 14400:
                    raise DocumentError("Unreasonably large page dimensions.")
                # Bake /Rotate into the content. All later coordinates use the same frame.
                if page.rotation:
                    page.remove_rotation()
            return doc.tobytes(garbage=3, deflate=True, encryption=fitz.PDF_ENCRYPT_NONE)
    except DocumentError:
        raise
    except Exception as exc:
        raise DocumentError(f"Cannot read PDF: {exc}") from exc


def render_page(page: fitz.Page, dpi: int, pixel_limit: int) -> Image.Image:
    effective = min(float(dpi), 72 * math.sqrt(pixel_limit / (page.rect.width * page.rect.height)))
    pix = page.get_pixmap(
        matrix=fitz.Matrix(effective / 72, effective / 72), alpha=False, colorspace=fitz.csRGB
    )
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def ocr_words(image, out, options, progress=None):
    from .ocr import read_words

    if options.ocr_engine == "paddle":
        from studio.engines.neural import recognize

        words, diagnostics, warnings = recognize(image, out, options.contrast_factor, progress)
    else:
        from PIL import ImageEnhance

        words, diagnostics, warnings = read_words(
            ImageEnhance.Contrast(image).enhance(options.contrast_factor), out, options, progress
        )
    out.diagnostics.update(diagnostics)
    out.warnings.extend(warnings)
    return words


def raster_rules(image: Image.Image, out: Page):
    import cv2

    pixels = np.array(image.convert("RGB"))
    gray = cv2.cvtColor(pixels, cv2.COLOR_RGB2GRAY)
    binary = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 31, 13
    )
    sx, sy = out.width / image.width, out.height / image.height
    for axis in ("h", "v"):
        length = max(18, int((20 if axis == "h" else 14) / (sx if axis == "h" else sy)))
        kernel = cv2.getStructuringElement(
            cv2.MORPH_RECT, (length, 1) if axis == "h" else (1, length)
        )
        mask = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if (axis == "h" and (h * sy > 4 or w / h < 10)) or (
                axis == "v" and (w * sx > 4 or h / w < 10)
            ):
                continue
            if axis == "h":
                a, b = (x * sx, (y + h / 2) * sy), ((x + w) * sx, (y + h / 2) * sy)
                width = h * sy
            else:
                a, b = ((x + w / 2) * sx, y * sy), ((x + w / 2) * sx, (y + h) * sy)
                width = w * sx
            # Do not redraw a native line detected from its raster appearance.
            same = any(
                r["axis"] == axis
                and abs(r["pos"] - (a[1] if axis == "h" else a[0])) < 1.5
                and abs(r["start"] - (a[0] if axis == "h" else a[1])) < 3
                and abs(r["end"] - (b[0] if axis == "h" else b[1])) < 3
                for r in out.rules
            )
            if same:
                continue
            samples = pixels[y : y + h, x : x + w]
            ink = samples[np.mean(samples, axis=2) < 150]
            color = (np.median(ink, axis=0) / 255).tolist() if len(ink) else [0, 0, 0]
            _add_rule(out, a, b, width, color, "raster")
            out.paths.append(
                dict(
                    items=[["l", list(a), list(b)]],
                    color=color,
                    fill=None,
                    width=max(0.25, width),
                    dashes="[] 0",
                    close=False,
                    stroke_opacity=1.0,
                    fill_opacity=1.0,
                    source="raster",
                )
            )


def scan_graphics_layer(image, out):
    from .graphics import preserve_graphics

    preserve_graphics(image, out)


def preserve_uncertain_fragments(image, out):
    """Fallback is local and explicit, not a full-page image hiding fake text."""
    sx, sy = image.width / out.width, image.height / out.height
    count = 0
    for word in out.words:
        if not word.needs_review:
            continue
        x0, y0, x1, y1 = word.bbox
        coords = (
            max(0, int(x0 * sx)),
            max(0, int(y0 * sy)),
            min(image.width, math.ceil(x1 * sx)),
            min(image.height, math.ceil(y1 * sy)),
        )
        if coords[2] <= coords[0] or coords[3] <= coords[1]:
            continue
        stream = io.BytesIO()
        image.crop(coords).save(stream, format="PNG")
        bbox = (coords[0] / sx, coords[1] / sy, coords[2] / sx, coords[3] / sy)
        out.images.append(
            dict(
                bbox=bbox,
                background=True,
                word_id=word.id,
                source="uncertain-word-fragment",
                data=stream.getvalue(),
            )
        )
        count += 1
    out.diagnostics["visual_fallback_words"] = count
    if count:
        out.warnings.append(
            f"{count} bizonytalan szó/részlet eredeti képkivágással látszik. Ellenőrzés vagy javítás után valódi betűként rajzoljuk."
        )


@serialized
def read_document(data, filename, options=None, password="", progress=None):
    from .layout import build_layout
    from .preprocess import prepare

    options = options or Options()
    options.validate()
    started = time.monotonic()
    budget = max(30, int(os.getenv("JOB_TIMEOUT_SECONDS", "900")))
    pdf_bytes = prepare_pdf(data, filename, options, password)
    document = Document(
        filename, fingerprint(data), pdf_bytes, options=asdict(options), original_input=data
    )
    total_pixels = 0
    with fitz.open(stream=pdf_bytes, filetype="pdf") as source, fitz.open() as normalized:
        for i, fp in enumerate(source):
            if time.monotonic() - started > budget:
                raise DocumentError(
                    "A feldolgozási időkeret lejárt; bontsd kisebb részekre a dokumentumot."
                )
            out = Page(i + 1, float(fp.rect.width), float(fp.rect.height))
            native = native_words(fp, i + 1)
            # Large page images must not be skipped because a page number or a
            # previously faulty invisible OCR layer happens to contain some text.
            images = fp.get_image_info()
            large = any(
                area(tuple(fitz.Rect(im["bbox"]) & fp.rect)) > out.width * out.height * 0.15
                for im in images
            )
            scan_like = any(
                area(tuple(fitz.Rect(im["bbox"]) & fp.rect)) > out.width * out.height * 0.75
                for im in images
            )
            scan_like = scan_like or (large and sum(len(w.text) for w in native) < 80)
            hidden = any("glyphless" in w.font.lower() for w in native)
            need = options.ocr == "always" or (
                options.ocr == "auto" and (not _quality(native) or scan_like or hidden)
            )
            if need:
                if progress:
                    progress(i + 0.05, len(source))
                image = render_page(fp, options.dpi, options.max_pixels)
                total_pixels += image.width * image.height
                if total_pixels > 300_000_000:
                    raise DocumentError(
                        "A dokumentum meghaladja a 300 megapixeles összesített korlátot."
                    )
                oldw, oldh = image.size
                sx, sy = out.width / oldw, out.height / oldh
                image, steps, notes = prepare(image, options)
                if progress:
                    progress(i + 0.25, len(source))
                angle = next(
                    (s["clockwise_orientation"] for s in steps if "clockwise_orientation" in s), 0
                )
                if angle in (90, 270):
                    sx, sy = sy, sx
                out.width, out.height = image.width * sx, image.height * sy
                out.mode = "ocr"
                out.ocr_ran = True
                out.warnings.extend(notes)
                out.diagnostics.update(
                    preprocessing=steps,
                    pixel_size=list(image.size),
                    route_reason="Szkennelt/képi oldal vagy újrafelismerés",
                )
                # One coordinate system for preview, words, tables, and searchable PDF.
                npg = normalized.new_page(width=out.width, height=out.height)
                stream = io.BytesIO()
                image.save(stream, format="PNG")
                npg.insert_image(npg.rect, stream=stream.getvalue())
                out.words = ocr_words(
                    image,
                    out,
                    options,
                    (lambda fraction: progress(i + 0.25 + 0.55 * fraction, len(source)))
                    if progress
                    else None,
                )
                if options.raster_lines:
                    raster_rules(image, out)
                if options.scan_graphics:
                    scan_graphics_layer(image, out)
                if options.visual_fallback:
                    preserve_uncertain_fragments(image, out)
                layout_page = normalized[-1]
            else:
                out.words = native
                native_graphics(fp, out)
                if not native:
                    out.mode = "image"
                    out.warnings.append("OCR kikapcsolva; nincs szerkeszthető szöveg.")
                # Native graphics/images are already extracted above; adding an
                # OCR background here would cover the original digital objects.
                # Exception: a full-page scan with an existing text layer and
                # OCR explicitly disabled still needs its isolated graphics.
                if options.scan_graphics and any(
                    im.get("large") and im.get("data") is None for im in out.images
                ):
                    preview = render_page(fp, 180, options.max_pixels)
                    if options.raster_lines:
                        raster_rules(preview, out)
                    scan_graphics_layer(preview, out)
                normalized.insert_pdf(source, from_page=i, to_page=i)
                layout_page = fp
            out.words = deduplicate(out.words)
            if out.ocr_ran:
                from .typography import constrain_ocr_geometry

                constrain_ocr_geometry(out)
            if len(out.words) > options.max_words:
                raise DocumentError("Az oldal meghaladja a szókorlátot; nincs csendes csonkolás.")
            build_layout(out, layout_page, options)
            document.pages.append(out)
            document.warnings.extend(f"{i + 1}. oldal: {w}" for w in out.warnings)
            if progress:
                progress(i + 1, len(source))
        from .typography import unify_document_fonts

        unify_document_fonts(document)
        document.normalized_pdf = normalized.tobytes(garbage=3, deflate=True)
    return document
