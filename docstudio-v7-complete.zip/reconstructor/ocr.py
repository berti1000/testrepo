"""Multi-pass Tesseract LSTM; aligned visible words with font-metric baselines."""

import math
from functools import lru_cache
from statistics import median
from bisect import bisect_left, bisect_right
import cv2
import numpy as np
import pytesseract
from PIL import Image, ImageDraw, ImageFont
from .model import Word
from .geometry import clean
from .preprocess import contrast, without_lines


@lru_cache(maxsize=1)
def installed_languages():
    return set(pytesseract.get_languages(config=""))


def validate_languages(languages):
    missing = set(languages.split("+")) - installed_languages()
    if missing:
        raise RuntimeError("Hiányzó OCR nyelvi modell: " + ", ".join(sorted(missing)))


def recognize(image, languages, psm=3, dpi=300, timeout=60, threshold=0):
    data = pytesseract.image_to_data(
        image,
        lang=languages,
        output_type=pytesseract.Output.DICT,
        config=f"--oem 1 --psm {psm} --dpi {dpi} -c thresholding_method={threshold}",
        timeout=timeout,
    )
    words = []
    for i, raw in enumerate(data["text"]):
        text = clean(str(raw)).strip()
        confidence = float(data["conf"][i])
        if not text or confidence < 0 or data["width"][i] <= 0 or data["height"][i] <= 0:
            continue
        x, y, w, h = [int(data[k][i]) for k in ("left", "top", "width", "height")]
        words.append(
            dict(
                text=text,
                confidence=max(0, min(1, confidence / 100)),
                bbox=(x, y, x + w, y + h),
                line=f"{data['block_num'][i]}:{data['par_num'][i]}:{data['line_num'][i]}",
            )
        )
    return words


def quality(words):
    chars = sum(len(w["text"]) for w in words)
    conf = sum(w["confidence"] * len(w["text"]) for w in words) / max(1, chars)
    alpha = sum(sum(c.isalnum() for c in w["text"]) for w in words) / max(1, chars)
    score = conf * (0.4 + 0.6 * alpha) * min(1, math.log1p(chars) / math.log(120))
    return dict(chars=chars, words=len(words), confidence=round(conf, 4), score=round(score, 4))


def orient(image, languages):
    validate_languages(languages)
    probe = image.copy()
    probe.thumbnail((1800, 1800))
    if max(probe.size) < 1400:
        scale = min(4, 1400 / max(probe.size))
        probe = probe.resize(
            (round(probe.width * scale), round(probe.height * scale)), Image.Resampling.LANCZOS
        )
    try:
        result = pytesseract.image_to_osd(probe, output_type=pytesseract.Output.DICT, timeout=20)
        if float(result.get("orientation_conf", 0)) >= 12:
            angle = int(result["rotate"])
            return (
                image.rotate(-angle, expand=True, fillcolor="white"),
                angle,
                float(result["orientation_conf"]),
            )
    except (pytesseract.TesseractError, RuntimeError):
        pass
    candidates = []
    for angle in (0, 90, 180, 270):
        try:
            q = quality(
                recognize(
                    probe.rotate(-angle, expand=True, fillcolor="white"),
                    languages,
                    psm=11,
                    timeout=20,
                )
            )
        except (pytesseract.TesseractError, RuntimeError):
            q = dict(chars=0, score=0)
        candidates.append((q, angle))
        if (
            angle == 0
            and q.get("chars", 0) >= 80
            and q.get("confidence", 0) >= 0.90
            and q["score"] >= 0.85
        ):
            return image, 0, q["score"]
    best, angle = max(candidates, key=lambda v: v[0]["score"])
    original = candidates[0][0]
    if best["chars"] >= 12 and best["score"] > original["score"] + 0.12:
        return image.rotate(-angle, expand=True, fillcolor="white"), angle, best["score"]
    return image, 0, original["score"]


@lru_cache(maxsize=8)
def pilfont(family="sans", bold=False):
    from .render import font_path

    return ImageFont.truetype(font_path(family, bold), 100)


def fit_fonts(image, words, width, height):
    gray = np.array(image.convert("L"))
    sx, sy = image.width / width, image.height / height
    candidates = [(family, bold) for bold in (False, True) for family in ("sans", "serif", "mono")]
    samples = [w for w in words if len(w.text) >= 4 and (w.confidence or 0) >= 0.75]
    if len(samples) > 40:
        samples = samples[:: max(1, len(samples) // 40)][:40]
    scores = {}
    for word in samples:
        x0, y0, x1, y1 = word.bbox
        patch = gray[
            max(0, round(y0 * sy)) : min(image.height, round(y1 * sy)),
            max(0, round(x0 * sx)) : min(image.width, round(x1 * sx)),
        ]
        if min(patch.shape, default=0) < 4:
            continue
        mask = cv2.threshold(patch, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1] / 255
        scores[word.id] = []
        for family, bold in candidates:
            font = pilfont(family, bold)
            l, t, r, b = font.getbbox(word.text, anchor="ls")
            template = Image.new("L", (max(1, r - l), max(1, b - t)), 255)
            ImageDraw.Draw(template).text((-l, -t), word.text, font=font, anchor="ls", fill=0)
            predicted = (
                np.array(
                    template.resize((patch.shape[1], patch.shape[0]), Image.Resampling.LANCZOS)
                )
                / 255
            )
            scores[word.id].append(
                float(np.mean(np.abs(predicted - mask)) / max(0.1, np.mean(1 - mask)))
            )
    family = "sans"
    family_margin = 0.0
    if scores:
        values = np.array(list(scores.values()))
        ranked = sorted(
            (float(np.median(np.min(values[:, [i, i + 3]], axis=1))), f)
            for i, f in enumerate(("sans", "serif", "mono"))
        )
        family = ranked[0][1]
        family_margin = (ranked[1][0] - ranked[0][0]) / max(0.1, ranked[0][0])
    normal = ("sans", "serif", "mono").index(family)
    reliable_metrics = {}
    for word in words:
        word.font = {
            "serif": "Liberation Serif",
            "sans": "Liberation Sans",
            "mono": "Liberation Mono",
        }[family]
        score = scores.get(word.id)
        word.bold = bool(score and score[normal + 3] + 0.10 < score[normal] * 0.90)
        font = pilfont(family, word.bold)
        _, top, _, bottom = font.getbbox(word.text, anchor="ls")
        word.size = max(2, min(120, (word.bbox[3] - word.bbox[1]) / max(0.3, (bottom - top) / 100)))
        # Dust and rules can inflate TSV boxes vertically by several times.
        # Font advance width provides an independent size estimate.
        width_size = (word.bbox[2] - word.bbox[0]) / max(0.1, font.getlength(word.text) / 100)
        plausible = 0.7 < word.size / max(1, width_size) < 1.45
        reliable_metrics[word.id] = plausible and (word.confidence or 0) >= 0.75
        if len(word.text) >= 3 and not plausible:
            word.size = max(2, min(120, width_size))
        word.origin = (word.bbox[0], word.bbox[1] - top / 100 * word.size)
    for line in {w.line_hint for w in words}:
        group = [w for w in words if w.line_hint == line]
        reliable = [w for w in group if reliable_metrics[w.id] and len(w.text) >= 3]
        # Keep genuinely mixed-size text; normalize only similar-size words.
        for w in group:
            neighbors = [v for v in reliable if 0.8 < w.size / v.size < 1.25]
            if len(neighbors) >= 2 or (neighbors and not reliable_metrics[w.id]):
                w.size = median(v.size for v in neighbors)
                w.origin = (w.bbox[0], median(v.origin[1] for v in neighbors))
    artifacts = flag_rule_artifacts(words, width)
    # Sparse segmentation can put a noisy two-letter candidate in its own
    # block, spanning both header rows. Nearby reliable text bounds its size.
    anchors = [w for w in words if (w.confidence or 0) >= 0.8 and not w.visual_artifact]
    typical_size = median(w.size for w in anchors) if anchors else 10
    for word in words:
        if (word.confidence or 0) >= 0.75 or word.visual_artifact:
            continue
        peers = [w for w in anchors if abs(w.bbox[3] - word.bbox[3]) < typical_size]
        if len(peers) >= 2:
            local_size = median(w.size for w in peers)
            if word.size > local_size * 1.7:
                word.size = local_size
                word.origin = (word.bbox[0], median(w.origin[1] for w in peers))
    for word in words:
        natural_width = pilfont(family, word.bold).getlength(word.text) / 100 * word.size
        fit = (word.bbox[2] - word.bbox[0]) / max(0.1, natural_width)
        if fit < 0.35 or fit > 2.8:
            word.visual_artifact = True
    artifacts = sum(w.visual_artifact for w in words)
    return dict(
        font_family_approximation=family,
        font_family_margin=round(family_margin, 4),
        font_sample_words=len(scores),
        suppressed_rule_candidates=artifacts,
    )


def flag_rule_artifacts(words, page_width):
    """Don't paint dotted table rules as giant letters. Keep candidates in the
    model for explicit review, rather than silently deleting extracted data.
    """
    heights = [
        w.bbox[3] - w.bbox[1] for w in words if (w.confidence or 0) >= 0.8 and len(w.text) >= 3
    ]
    typical = median(heights) if heights else 8
    for line in {w.line_hint for w in words}:
        group = [w for w in words if w.line_hint == line]
        mean_confidence = sum(w.confidence or 0 for w in group) / max(1, len(group))
        span = max(w.bbox[2] for w in group) - min(w.bbox[0] for w in group)
        thin = median(w.bbox[3] - w.bbox[1] for w in group) < typical * 0.3
        stretched = any(
            (w.bbox[2] - w.bbox[0]) / max(0.1, w.bbox[3] - w.bbox[1]) > 40
            and len(w.text) <= 4
            and (w.confidence or 0) < 0.65
            for w in group
        )
        artifact = mean_confidence < 0.6 and span > page_width * 0.3 and (thin or stretched)
        for word in group:
            word.visual_artifact = artifact
    return sum(w.visual_artifact for w in words)


def read_words(image, page, options, progress=None):
    validate_languages(options.languages)
    warnings = []
    gray = np.array(image.convert("L"))
    mask = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    _, _, stats, _ = cv2.connectedComponentsWithStats(mask)
    heights = [
        int(h) for x, y, w, h, a in stats[1:] if 3 <= h <= 80 and 1 <= w <= h * 2 and 4 <= a < 3000
    ]
    small = median(heights) if heights else 24
    scale = min(
        4.0,
        max(1.0, 24 / max(1, small)),
        (options.max_pixels / (image.width * image.height)) ** 0.5,
    )
    if scale > 1.1:
        image = image.resize(
            (round(image.width * scale), round(image.height * scale)), Image.Resampling.LANCZOS
        )
        if small < 10:
            warnings.append(
                "Apró forrásbetűk: az OCR-nagyítás nem állít helyre elveszett képrészleteket."
            )
    initial = contrast(image) if options.enhance else image
    specs = [("original", initial, options.psm, 0)]
    if options.quality in ("balanced", "accurate"):
        specs.append(("sauvola", initial, 11 if options.psm == 3 else 3, 2))
        if options.raster_lines:
            specs.append(("line-removal", without_lines(image), options.psm, 0))
    passes = []
    for pass_index, (name, variant, psm, threshold) in enumerate(specs):
        try:
            detected = recognize(
                variant, options.languages, psm, options.dpi, options.timeout, threshold
            )
            metrics = dict(name=name, psm=psm, **quality(detected))
            passes.append((detected, metrics))
            if (
                options.quality == "balanced"
                and metrics["chars"] >= 80
                and metrics["confidence"] >= 0.93
                and metrics["score"] >= 0.88
            ):
                break
        except (pytesseract.TesseractError, RuntimeError) as exc:
            warnings.append(f"OCR menet sikertelen: {name}: {str(exc)[:150]}")
        if progress:
            progress((pass_index + 1) / len(specs))
    if not passes:
        raise RuntimeError("Minden OCR-menet meghiúsult: " + "; ".join(warnings))
    maxchars = max(q["chars"] for _, q in passes)
    chosen, metrics = max(
        passes, key=lambda p: p[1]["score"] * min(1, p[1]["chars"] / max(1, maxchars * 0.85))
    )
    # Different preprocessing can give confident but contradictory words. Keep
    # the selected text, expose the alternatives and preserve the source crop.
    # A row index avoids a quadratic comparison on long pages.
    comparisons = []
    for detected, other_metrics in passes:
        if other_metrics["name"] == metrics["name"]:
            continue
        ordered = sorted(detected, key=lambda w: (w["bbox"][1] + w["bbox"][3]) / 2)
        comparisons.append((ordered, [(w["bbox"][1] + w["bbox"][3]) / 2 for w in ordered]))
    disagreements = {}
    for index, item in enumerate(chosen):
        x0, y0, x1, y1 = item["bbox"]
        area = (x1 - x0) * (y1 - y0)
        cy = (y0 + y1) / 2
        alternatives = set()
        for ordered, centers in comparisons:
            neighbors = ordered[
                bisect_left(centers, cy - (y1 - y0) * 0.6) : bisect_right(
                    centers, cy + (y1 - y0) * 0.6
                )
            ]
            best, best_overlap = None, 0.55
            for candidate in neighbors:
                a, b, c, d = candidate["bbox"]
                intersection = max(0, min(c, x1) - max(a, x0)) * max(0, min(d, y1) - max(b, y0))
                overlap = intersection / max(1, area + (c - a) * (d - b) - intersection)
                if overlap > best_overlap and candidate["confidence"] >= 0.65:
                    best, best_overlap = candidate, overlap
            if best and best["text"].casefold() != item["text"].casefold():
                alternatives.add(best["text"])
        if alternatives:
            disagreements[index] = sorted(alternatives)
    sx, sy = page.width / image.width, page.height / image.height
    words = []
    for i, item in enumerate(chosen):
        a, b, c, d = item["bbox"]
        bbox = (a * sx, b * sy, c * sx, d * sy)
        words.append(
            Word(
                f"p{page.number}-o{i + 1}",
                item["text"],
                bbox,
                (bbox[0], bbox[3]),
                max(2, bbox[3] - bbox[1]),
                source="ocr",
                confidence=item["confidence"],
                line_hint=item["line"],
                alternatives=disagreements.get(i, []),
            )
        )
    typography = fit_fonts(image, words, page.width, page.height) if words else {}
    if not words:
        warnings.append(
            "Nem találtam olvasható szöveget. A kinézetmegőrző export továbbra is elérhető."
        )
    elif metrics["confidence"] < 0.8:
        warnings.append("Alacsony OCR-bizonyosság: ellenőrizd a kiemelt szavakat.")
    return (
        words,
        dict(
            selected_pass=metrics["name"],
            passes=[q for _, q in passes],
            ocr_upscale=round(scale, 2),
            typography=typography,
            disputed_words=len(disagreements),
        ),
        warnings,
    )
