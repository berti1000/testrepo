from __future__ import annotations

from bisect import bisect_left, bisect_right
import csv
import io
import math
import re
import zipfile
from decimal import Decimal, InvalidOperation

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.utils import get_column_letter
from docx import Document as WordDocument
from docx.enum.section import WD_SECTION_START
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT, WD_ROW_HEIGHT_RULE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, RGBColor

from .model import Block, Cell, Document, Page, Word
from .geometry import (
    area,
    cluster,
    group_lines,
    intersection,
    near_index,
    numeric_like,
    split_line,
    text_of,
    union,
)
from .render import (
    font_family,
    hex_color,
    page_png,
    page_svg,
    preserved_pdf,
    reconstructed_pdf,
    standalone_html,
)


def cell_text(cell: Cell, page: Page) -> str:
    return cell.override if cell.override is not None else text_of(cell.words, page.index())


def table_matrix(block: Block, page: Page) -> list[list[str]]:
    rows = [[""] * (len(block.x_edges) - 1) for _ in range(len(block.y_edges) - 1)]
    for cell in block.cells:
        rows[cell.row][cell.col] = cell_text(cell, page)
    return rows


def plain_text(document: Document) -> bytes:
    pages = []
    for page in document.pages:
        chunks = []
        for block in page.blocks:
            if block.kind == "table":
                chunks.append("\n".join("\t".join(row) for row in table_matrix(block, page)))
            else:
                chunks.append(text_of(block.words, page.index()))
        pages.append("\n\n".join(chunks))
    return "\n\f\n".join(pages).encode("utf-8")


def _csv_safe(value: str) -> str:
    # Quoting alone does not prevent CSV formula injection in spreadsheet applications.
    return "'" + value if value.lstrip().startswith(("=", "+", "-", "@")) else value


def csv_tables(document: Document) -> bytes:
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as archive:
        count = 0
        for page in document.pages:
            for block in page.blocks:
                if block.kind != "table":
                    continue
                output = io.StringIO(newline="")
                writer = csv.writer(output, delimiter=";")
                for row in table_matrix(block, page):
                    writer.writerow([_csv_safe(v) for v in row])
                archive.writestr(
                    f"page_{page.number}_{block.id}.csv", output.getvalue().encode("utf-8-sig")
                )
                count += 1
        archive.writestr(
            "README.txt",
            f"{count} table CSV files; UTF-8 BOM; separator semicolon. Formula-like strings are prefixed with an apostrophe for safety. CSV has no visual design or merged cells.",
        )
    return buffer.getvalue()


def number_value(text: str, locale: str = "text"):
    """Opt-in conservative decimal conversion. No dates, IDs, currencies or guessing."""
    t = text.strip().replace("\u00a0", " ")
    if locale == "text" or "\n" in t or len(re.sub(r"\D", "", t)) > 15:
        return None
    if re.match(r"^[+-]?0\d", t):
        return None
    if locale == "hu":
        if not re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?: \d{3})+),\d{1,4}", t):
            return None
        t = t.replace(" ", "").replace(",", ".")
    elif locale == "en":
        if not re.fullmatch(r"[+-]?(?:\d+|\d{1,3}(?:,\d{3})+)\.\d{1,4}", t):
            return None
        t = t.replace(",", "")
    else:
        return None
    try:
        return float(Decimal(t))
    except InvalidOperation:
        return None


def _representative(ids: list[str], page: Page) -> Word | None:
    idx = page.index()
    words = [idx[k] for k in ids if k in idx]
    return max(words, key=lambda w: len(w.text), default=None)


def _font_name(word: Word | None) -> str:
    family = font_family(word.font) if word else "sans"
    return {"sans": "Arial", "serif": "Times New Roman", "mono": "Courier New"}[family]


def _border_rules(box, page: Page) -> dict:
    x0, y0, x1, y1 = box
    result = {}
    for side, axis, pos, start, end in [
        ("top", "h", y0, x0, x1),
        ("bottom", "h", y1, x0, x1),
        ("left", "v", x0, y0, y1),
        ("right", "v", x1, y0, y1),
    ]:
        matches = [
            r
            for r in page.rules
            if r["axis"] == axis
            and abs(r["pos"] - pos) <= 2
            and max(0, min(r["end"], end) - max(r["start"], start)) / max(1, end - start) > 0.6
        ]
        if matches:
            result[side] = max(matches, key=lambda r: r["width"])
    return result


def _fill(box, page: Page):
    selected = None
    for path in page.paths:
        if path.get("fill") is None:
            continue
        for primitive in path["items"]:
            if (
                primitive[0] == "re"
                and intersection(box, tuple(primitive[1])) / max(1, area(box)) > 0.7
            ):
                selected = hex_color(path["fill"])
    return selected


def _xlsx_border(box, page):
    sides = {}
    for key, r in _border_rules(box, page).items():
        sides[key] = Side(
            style="thin" if r["width"] < 1 else "medium" if r["width"] < 2.2 else "thick",
            color=hex_color(r["color"]),
        )
    return Border(**sides)


def _rich_cell_text(text, ids, page):
    index = page.index()
    words = [index[k] for k in ids if k in index and index[k].text]
    signatures = {(_font_name(w), w.size, w.bold, w.italic, w.color, w.superscript) for w in words}
    if len(signatures) < 2 or text_of(ids, index) != text:
        return text
    runs = []
    for li, line in enumerate(group_lines(words)):
        if li:
            runs.append("\n")
        for wi, key in enumerate(line.words):
            if wi:
                runs.append(" ")
            w = index[key]
            font = InlineFont(
                rFont=_font_name(w),
                sz=max(5, min(72, w.size)),
                b=w.bold,
                i=w.italic,
                color=hex_color(w.color),
                vertAlign="superscript" if w.superscript else None,
            )
            runs.append(TextBlock(font, w.text))
    rich = CellRichText(runs)
    return rich if str(rich) == text else text


def _write_xcell(
    ws, row, col, end_col, text, ids, box, page, locale="text", height=None, available_width=None
):
    target = ws.cell(row, col)
    converted = number_value(text, locale)
    if converted is not None:
        target.value = converted
        places = min(4, len(re.split("[.,]", text.strip())[-1]))
        target.number_format = "#,##0." + "0" * places
    else:
        # Explicit string type prevents formula execution without changing displayed text.
        target.value = _rich_cell_text(text, ids, page)
        target.data_type = "s"
        target.number_format = "@"
    word = _representative(ids, page)
    size = word.size if word else 10
    target.font = Font(
        name=_font_name(word),
        size=max(5, min(72, size)),
        bold=word.bold if word else False,
        italic=word.italic if word else False,
        color=hex_color(word.color if word else 0),
    )
    target.alignment = Alignment(
        horizontal="right" if numeric_like(text) else "left", vertical="center", wrap_text=True
    )
    target.border = _xlsx_border(box, page)
    fill = _fill(box, page)
    if fill:
        target.fill = PatternFill("solid", fgColor=fill)
    "; ".join(sorted({page.index()[k].source for k in ids if k in page.index()}))
    if end_col > col:
        ws.merge_cells(start_row=row, start_column=col, end_row=row, end_column=end_col)
    # Excel does not auto-fit merged/wrapped cells reliably; calculate a safe minimum.
    lines = max(1, len(text.splitlines()))
    width = max(12, (available_width if available_width is not None else box[2] - box[0]) - 5)
    estimated = sum(max(1, math.ceil(len(line) * size * 0.49 / width)) for line in text.split("\n"))
    h = max(height or 0, size * 1.22 * max(lines, estimated) + 4)
    ws.row_dimensions[row].height = max(ws.row_dimensions[row].height or 0, min(409, h))


def _setup_sheet(ws, x_edges):
    ws.sheet_view.showGridLines = False
    for col, (a, b) in enumerate(zip(x_edges, x_edges[1:]), 1):
        ws.column_dimensions[get_column_letter(col)].width = max(1.0, ((b - a) * 96 / 72 - 5) / 7)
    ws.page_setup.orientation = "landscape" if x_edges[-1] - x_edges[0] > 700 else "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.2
    ws.page_margins.top = ws.page_margins.bottom = 0.2


def _table_sheet(wb, block, page, locale, title):
    ws = wb.create_sheet(title[:31])
    _setup_sheet(ws, block.x_edges)
    for cell in block.cells:
        _write_xcell(
            ws,
            cell.row + 1,
            cell.col + 1,
            cell.col + cell.colspan,
            cell_text(cell, page),
            cell.words,
            cell.bbox,
            page,
            locale,
            (cell.bbox[3] - cell.bbox[1]) / max(1, cell.rowspan),
        )
        if cell.rowspan > 1:
            if cell.colspan > 1:
                ws.unmerge_cells(
                    start_row=cell.row + 1,
                    start_column=cell.col + 1,
                    end_row=cell.row + 1,
                    end_column=cell.col + cell.colspan,
                )
            ws.merge_cells(
                start_row=cell.row + 1,
                start_column=cell.col + 1,
                end_row=cell.row + cell.rowspan,
                end_column=cell.col + cell.colspan,
            )
    if block.header_rows:
        ws.freeze_panes = f"A{block.header_rows + 1}"
        ws.print_title_rows = f"1:{block.header_rows}"
    if not any(c.rowspan > 1 or c.colspan > 1 for c in block.cells):
        ws.auto_filter.ref = ws.dimensions
    ws.print_area = ws.dimensions
    return ws


def _page_edges(page: Page):
    tables = [b for b in page.blocks if b.kind == "table"]
    box = union([b.bbox for b in page.blocks])
    left = max(0, box[0])
    right = min(page.width, box[2])
    if not page.blocks:
        return [24, max(25, page.width - 24)]
    values = [left, right]
    for table in tables:
        values.extend(table.x_edges)
    if not tables:
        idx = page.index()
        for line in group_lines(page.words):
            chunks = split_line(line, idx)
            if len(chunks) > 1:
                for a, b in zip(chunks, chunks[1:]):
                    values.append(
                        (max(idx[k].bbox[2] for k in a) + min(idx[k].bbox[0] for k in b)) / 2
                    )
    return cluster(values, 2.0)


def _page_sheet(wb, page: Page, locale, max_cols=32, max_grid_cells=8000):
    edges = _page_edges(page)
    ncols = len(edges) - 1
    estimated_rows = (
        sum(
            len(b.y_edges) - 1
            if b.kind == "table"
            else max(1, len(group_lines([page.index()[k] for k in b.words])))
            for b in page.blocks
        )
        + len(page.blocks) * 2
    )
    if ncols > max_cols or estimated_rows * ncols > max_grid_cells:
        return None
    ws = wb.create_sheet(f"Elrendezes {page.number}")
    _setup_sheet(ws, edges)
    idx = page.index()
    row = 1
    previous_y = 0.0
    for block in page.blocks:
        gap = block.bbox[1] - previous_y
        if gap > 4:
            ws.row_dimensions[row].height = min(100, gap)
            row += 1
        if block.kind == "table":
            start = row
            for cell in block.cells:
                col = near_index(edges, cell.bbox[0]) + 1
                end_col = max(col, near_index(edges, cell.bbox[2]))
                _write_xcell(
                    ws,
                    start + cell.row,
                    col,
                    end_col,
                    cell_text(cell, page),
                    cell.words,
                    cell.bbox,
                    page,
                    locale,
                    (cell.bbox[3] - cell.bbox[1]) / max(1, cell.rowspan),
                )
                if cell.rowspan > 1:
                    if end_col > col:
                        ws.unmerge_cells(
                            start_row=start + cell.row,
                            start_column=col,
                            end_row=start + cell.row,
                            end_column=end_col,
                        )
                    ws.merge_cells(
                        start_row=start + cell.row,
                        start_column=col,
                        end_row=start + cell.row + cell.rowspan - 1,
                        end_column=end_col,
                    )
            row += len(block.y_edges) - 1
        else:
            lines = group_lines([idx[k] for k in block.words])
            chunks = split_line(lines[0], idx) if len(lines) == 1 else [block.words]
            if len(chunks) == 1:
                col = max(1, min(ncols, bisect_right(edges, block.bbox[0] + 0.01)))
                end_col = max(col, min(ncols, bisect_left(edges, block.bbox[2] - 0.01)))
                # A paragraph uses available width; it is not split into individual words.
                if end_col == col and len(text_of(block.words, idx)) > 25:
                    end_col = ncols
                _write_xcell(
                    ws,
                    row,
                    col,
                    end_col,
                    text_of(block.words, idx),
                    block.words,
                    block.bbox,
                    page,
                    height=block.bbox[3] - block.bbox[1],
                    available_width=edges[end_col] - edges[col - 1],
                )
            else:
                previous_col = 0
                for ci, ids in enumerate(chunks):
                    box = union([idx[k].bbox for k in ids])
                    col = max(previous_col + 1, min(ncols, bisect_right(edges, box[0] + 0.01)))
                    end_col = max(col, min(ncols, bisect_left(edges, box[2] - 0.01)))
                    if ci + 1 < len(chunks):
                        next_box = union([idx[k].bbox for k in chunks[ci + 1]])
                        end_col = min(
                            end_col, max(col, bisect_right(edges, next_box[0] + 0.01) - 1)
                        )
                    if col > ncols:
                        # No silent overwrite: use a continuation row when the compact grid cannot fit.
                        row += 1
                        col = 1
                        end_col = ncols
                    _write_xcell(
                        ws,
                        row,
                        col,
                        end_col,
                        text_of(ids, idx),
                        ids,
                        box,
                        page,
                        height=block.bbox[3] - block.bbox[1],
                        available_width=edges[end_col] - edges[col - 1],
                    )
                    previous_col = end_col
            row += 1
        previous_y = max(previous_y, block.bbox[3])
    if not page.words:
        ws.cell(1, 1, "No readable text; see the source-preserving PDF.")
    # Logos are images, not thousands of coloured cells.
    from openpyxl.drawing.image import Image as XLImage
    from openpyxl.drawing.spreadsheet_drawing import AbsoluteAnchor
    from openpyxl.drawing.xdr import XDRPoint2D, XDRPositiveSize2D

    for image in page.images:
        if not image.get("data") or image.get("background"):
            continue
        x0, y0, x1, y1 = image["bbox"]
        im = XLImage(io.BytesIO(image["data"]))
        im.anchor = AbsoluteAnchor(
            pos=XDRPoint2D(int(max(0, x0 - edges[0]) * 12700), int(y0 * 12700)),
            ext=XDRPositiveSize2D(int((x1 - x0) * 12700), int((y1 - y0) * 12700)),
        )
        ws.add_image(im)
    ws.print_area = f"A1:{get_column_letter(ncols)}{max(1, row - 1)}"
    return ws


def excel(document: Document, locale: str = "text", include_tables: bool = True) -> bytes:
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    notes = []
    for page in document.pages:
        layout = _page_sheet(wb, page, locale)
        if layout is None:
            notes.append(
                f"Page {page.number}: compact page grid exceeded its limit; content exported by region instead, without dropping words."
            )
            ws = wb.create_sheet(f"Szoveg {page.number}")
            ws.column_dimensions["A"].width = 100
            row = 1
            for block in page.blocks:
                if block.kind == "paragraph":
                    _write_xcell(
                        ws,
                        row,
                        1,
                        1,
                        text_of(block.words, page.index()),
                        block.words,
                        block.bbox,
                        page,
                    )
                    row += 1
        for ti, block in enumerate([b for b in page.blocks if b.kind == "table"], 1):
            if include_tables or layout is None:
                _table_sheet(wb, block, page, locale, f"Tabla {page.number}-{ti}")
    ws = wb.create_sheet("Info")
    ws.column_dimensions["A"].width = 115
    info = [
        "Source: " + document.filename,
        "SHA256: " + document.sha256,
        "Layout sheets approximate page arrangement. Tabla sheets contain only real local table columns.",
        "Source-preserving PDF is the appearance reference. Excel is editable, not pixel-identical.",
        "Numeric conversion: " + locale + " (text is the loss-minimizing default).",
        "No OCR/AI-inferred arithmetic has been inserted. Original text and coordinates are in cell comments.",
        *notes,
        *[f"Page {p.number}: {w}" for p in document.pages for w in p.warnings],
    ]
    for row, text in enumerate(info, 1):
        ws.cell(row, 1, text)
        ws.cell(row, 1).alignment = Alignment(wrap_text=True, vertical="top")
        ws.row_dimensions[row].height = max(20, math.ceil(len(text) / 110) * 15)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _set_xml(parent, tag, attrs):
    element = OxmlElement(tag)
    for key, value in attrs.items():
        element.set(qn(key), str(value))
    parent.append(element)
    return element


def _word_run(paragraph, value, word: Word | None):
    run = paragraph.add_run(value)
    run.font.name = _font_name(word)
    run.font.size = Pt(max(5, min(72, word.size if word else 10)))
    run.bold = word.bold if word else False
    run.italic = word.italic if word else False
    if word:
        run.font.color.rgb = RGBColor.from_string(hex_color(word.color))
        if word.superscript:
            run.font.superscript = True
    return run


def _add_runs(paragraph, ids, page, multiline=True):
    idx = page.index()
    for li, line in enumerate(group_lines([idx[k] for k in ids])):
        if li:
            paragraph.add_run("\n" if multiline else " ")
        for wi, key in enumerate(line.words):
            word = idx[key]
            if wi:
                paragraph.add_run(" ")
            _word_run(paragraph, word.text, word)


def _word_cell_style(cell, box, page):
    props = cell._tc.get_or_add_tcPr()
    _set_xml(props, "w:tcMar", {})
    mar = props[-1]
    for name in ("top", "left", "bottom", "right"):
        _set_xml(mar, "w:" + name, {"w:w": 60, "w:type": "dxa"})
    borders = _set_xml(props, "w:tcBorders", {})
    rules = _border_rules(box, page)
    for name in ("top", "bottom", "left", "right"):
        rule = rules.get(name)
        attrs = (
            {
                "w:val": "single",
                "w:sz": max(2, round(rule["width"] * 8)),
                "w:color": hex_color(rule["color"]),
            }
            if rule
            else {"w:val": "nil"}
        )
        _set_xml(borders, "w:" + name, attrs)
    fill = _fill(box, page)
    if fill:
        _set_xml(props, "w:shd", {"w:fill": fill, "w:val": "clear"})
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def _word_table(doc, block, page, margin):
    nr, nc = len(block.y_edges) - 1, len(block.x_edges) - 1
    table = doc.add_table(rows=nr, cols=nc)
    table.autofit = False
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    props = table._tbl.tblPr
    _set_xml(
        props, "w:tblInd", {"w:w": max(0, round((block.bbox[0] - margin) * 20)), "w:type": "dxa"}
    )
    borders = _set_xml(props, "w:tblBorders", {})
    for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
        _set_xml(borders, "w:" + side, {"w:val": "nil"})
    widths = [b - a for a, b in zip(block.x_edges, block.x_edges[1:])]
    for ci, width in enumerate(widths):
        table.columns[ci].width = Pt(width)
        for row in table.rows:
            row.cells[ci].width = Pt(width)
    for ri, row in enumerate(table.rows):
        row.height = Pt(max(6, block.y_edges[ri + 1] - block.y_edges[ri]))
        row.height_rule = WD_ROW_HEIGHT_RULE.AT_LEAST
        if ri < block.header_rows:
            _set_xml(row._tr.get_or_add_trPr(), "w:tblHeader", {"w:val": "true"})
    for data in block.cells:
        target = table.cell(data.row, data.col)
        if data.rowspan > 1 or data.colspan > 1:
            target = target.merge(
                table.cell(data.row + data.rowspan - 1, data.col + data.colspan - 1)
            )
        target.text = ""
        paragraph = target.paragraphs[0]
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.0
        paragraph.paragraph_format.keep_with_next = False
        value = cell_text(data, page)
        paragraph.alignment = (
            WD_ALIGN_PARAGRAPH.RIGHT if numeric_like(value) else WD_ALIGN_PARAGRAPH.LEFT
        )
        if data.override is not None:
            _word_run(paragraph, value, _representative(data.words, page))
        else:
            _add_runs(paragraph, data.words, page)
        _word_cell_style(target, data.bbox, page)
    return table


def word_document(document: Document) -> bytes:
    doc = WordDocument()
    normal = doc.styles["Normal"]
    normal.font.name = "Arial"
    normal.font.size = Pt(10)
    normal.paragraph_format.space_after = Pt(0)
    for pi, page in enumerate(document.pages):
        section = doc.sections[0] if pi == 0 else doc.add_section(WD_SECTION_START.NEW_PAGE)
        section.page_width = Pt(page.width)
        section.page_height = Pt(page.height)
        content = (
            union([b.bbox for b in page.blocks])
            if page.blocks
            else (24, 24, page.width - 24, page.height - 24)
        )
        margin = max(8, min(24, content[0] - 2, page.width - content[2] - 2))
        section.left_margin = section.right_margin = Pt(margin)
        section.top_margin = Pt(max(8, min(24, content[1] - 2)))
        section.bottom_margin = Pt(10)
        section.header_distance = section.footer_distance = Pt(0)
        previous_y = section.top_margin.pt
        image_events = [
            ("image", im["bbox"][1], im)
            for im in page.images
            if im.get("data") and not im.get("background")
        ]
        events = [("block", b.bbox[1], b) for b in page.blocks] + image_events
        for kind, top, item in sorted(events, key=lambda x: x[1]):
            if kind == "image":
                im = item
                x0, y0, x1, y1 = im["bbox"]
                para = doc.add_paragraph()
                para.paragraph_format.left_indent = Pt(max(0, x0 - margin))
                para.paragraph_format.space_before = Pt(max(0, min(40, top - previous_y)))
                para.add_run().add_picture(
                    io.BytesIO(im["data"]), width=Pt(x1 - x0), height=Pt(y1 - y0)
                )
                previous_y = max(previous_y, y1)
                continue
            block = item
            gap = max(0, min(60, block.bbox[1] - previous_y))
            if block.kind == "table":
                if gap > 3:
                    p = doc.add_paragraph()
                    p.paragraph_format.space_after = Pt(0)
                    p.paragraph_format.line_spacing = Pt(max(1, gap))
                    p.add_run().font.size = Pt(1)
                _word_table(doc, block, page, margin)
            else:
                para = doc.add_paragraph()
                pf = para.paragraph_format
                pf.left_indent = Pt(max(0, block.bbox[0] - margin))
                pf.space_before = Pt(gap)
                pf.space_after = Pt(0)
                pf.line_spacing = 1.05
                idx = page.index()
                lines = group_lines([idx[k] for k in block.words])
                chunks = split_line(lines[0], idx) if len(lines) == 1 else [block.words]
                if len(chunks) > 1:
                    for ci, ids in enumerate(chunks):
                        box = union([idx[k].bbox for k in ids])
                        value = text_of(ids, idx, False)
                        if ci:
                            right = numeric_like(value)
                            pos = (box[2] if right else box[0]) - block.bbox[0]
                            pf.tab_stops.add_tab_stop(
                                Pt(max(1, pos)),
                                WD_TAB_ALIGNMENT.RIGHT if right else WD_TAB_ALIGNMENT.LEFT,
                            )
                            para.add_run("\t")
                        _add_runs(para, ids, page, False)
                else:
                    _add_runs(para, block.words, page)
                # Actual nearby rules only; no invented paragraph box.
                near = [
                    r
                    for r in page.rules
                    if r["axis"] == "h"
                    and 0 <= r["pos"] - block.bbox[3] <= 4
                    and r["end"] >= block.bbox[2] - 3
                    and r["start"] <= block.bbox[0] + 3
                ]
                if near:
                    ppr = para._p.get_or_add_pPr()
                    border = _set_xml(ppr, "w:pBdr", {})
                    r = near[0]
                    _set_xml(
                        border,
                        "w:bottom",
                        {
                            "w:val": "single",
                            "w:sz": max(2, round(r["width"] * 8)),
                            "w:color": hex_color(r["color"]),
                            "w:space": 2,
                        },
                    )
            previous_y = max(previous_y, block.bbox[3])
        if not page.words:
            doc.add_paragraph("No readable text on this page. See source-preserving PDF.")
    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()


def image_archive(document: Document, extension="png") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for i in range(len(document.pages)):
            payload = (
                page_svg(document, i + 1).encode("utf-8")
                if extension == "svg"
                else page_png(document, i + 1, 160)
            )
            z.writestr(f"page_{i + 1:03d}.{extension}", payload)
    return buf.getvalue()


def all_exports(document: Document, locale="text") -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("01_original_appearance.pdf", preserved_pdf(document))
        from .render import searchable_pdf

        z.writestr("09_searchable_normalized.pdf", searchable_pdf(document))
        z.writestr("02_reconstructed.pdf", reconstructed_pdf(document))
        z.writestr("03_editable.xlsx", excel(document, locale))
        z.writestr("04_editable.docx", word_document(document))
        z.writestr("05_reconstructed.html", standalone_html(document))
        z.writestr("06_text.txt", plain_text(document))
        z.writestr("07_model_and_audit.json", document.to_json())
        z.writestr("08_tables_csv.zip", csv_tables(document))
        z.writestr(
            "README.txt",
            "01: Original PDF bytes, or original decoded image pixels embedded losslessly in PDF. No OCR edits or geometric corrections.\n"
            "02: Visible reconstructed characters, rules and graphics; uncertain words may keep their original image crop until reviewed.\n"
            "03/04: Editable tables/text; Office layout is not guaranteed identical.\n"
            "09: Corrected orientation/perspective image with invisible searchable OCR text.\n"
            "Text corrections affect reconstructed/editable/searchable outputs. Low confidence must be reviewed.\n"
            "For an image upload, download source-file separately to retain its original metadata/encoding.\n"
            "This is not a redaction tool. Reconstructed outputs do not retain digital signatures.\n",
        )
    return buf.getvalue()
