from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any
import hashlib
import json

Box = tuple[float, float, float, float]


@dataclass
class Options:
    ocr: str = "auto"  # auto | always | never
    languages: str = "hun+eng"
    dpi: int = 300
    psm: int = 3
    quality: str = "balanced"
    orientation: bool = True
    rotation: int = 0
    perspective: bool = False
    deskew: bool = True
    enhance: bool = False
    raster_lines: bool = True
    scan_graphics: bool = True  # Raster graphic layer, with recognized text removed
    visual_fallback: bool = False  # Explicit opt-in; pure text reconstruction is the default
    unruled_tables: bool = True
    max_pages: int = 60
    max_bytes: int = 50 * 1024 * 1024
    max_pixels: int = 24_000_000
    max_words: int = 16000
    timeout: int = 90
    gap_factor: float = 0.95
    ocr_engine: str = "tesseract"
    contrast_factor: float = 1.0

    def validate(self) -> None:
        if self.ocr_engine not in ("paddle", "tesseract") or not 0.5 <= self.contrast_factor <= 2.5:
            raise ValueError("Invalid OCR engine/contrast")
        if self.quality not in ("fast", "balanced", "accurate") or self.rotation not in (
            0,
            90,
            180,
            270,
        ):
            raise ValueError("Invalid quality/rotation")
        if (
            not self.languages
            or len(self.languages) > 40
            or not all(p.isalnum() and p.isascii() for p in self.languages.split("+"))
        ):
            raise ValueError("Invalid OCR languages")
        if self.ocr not in {"auto", "always", "never"}:
            raise ValueError("Invalid OCR mode")
        if not 150 <= self.dpi <= 450 or self.psm not in {3, 4, 6, 11}:
            raise ValueError("Invalid OCR resolution or segmentation mode")
        if not 0.45 <= self.gap_factor <= 2.0:
            raise ValueError("Invalid gap factor")
        if not 1 <= self.max_pages <= 1000 or not 1 <= self.timeout <= 600:
            raise ValueError("Invalid resource limit")


@dataclass
class Word:
    id: str
    text: str
    bbox: Box
    origin: tuple[float, float]
    size: float
    font: str = "Helvetica"
    bold: bool = False
    italic: bool = False
    color: int = 0
    alpha: float = 1.0
    direction: tuple[float, float] = (1.0, 0.0)
    source: str = "native"
    confidence: float | None = None  # not a calibrated probability
    line_hint: str = ""
    superscript: bool = False
    original_text: str | None = None
    reviewed: bool = False
    alternatives: list[str] = field(default_factory=list)
    visual_artifact: bool = False
    render_scale: float | None = None

    @property
    def needs_review(self) -> bool:
        return not self.reviewed and (
            bool(self.alternatives)
            or self.visual_artifact
            or (self.confidence is not None and self.confidence < 0.75)
        )


@dataclass
class Line:
    words: list[str]
    bbox: Box
    baseline: float
    size: float


@dataclass
class Cell:
    row: int
    col: int
    rowspan: int
    colspan: int
    bbox: Box
    words: list[str] = field(default_factory=list)
    # Only explicit human edits override the recognized text.
    override: str | None = None


@dataclass
class Block:
    id: str
    kind: str  # paragraph | table
    bbox: Box
    words: list[str] = field(default_factory=list)
    cells: list[Cell] = field(default_factory=list)
    x_edges: list[float] = field(default_factory=list)
    y_edges: list[float] = field(default_factory=list)
    method: str = "text"
    confidence: float | None = None
    header_rows: int = 0
    warnings: list[str] = field(default_factory=list)


@dataclass
class Page:
    number: int
    width: float
    height: float
    words: list[Word] = field(default_factory=list)
    paths: list[dict[str, Any]] = field(default_factory=list)
    images: list[dict[str, Any]] = field(default_factory=list)
    rules: list[dict[str, Any]] = field(default_factory=list)
    blocks: list[Block] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    mode: str = "native"
    ocr_ran: bool = False
    diagnostics: dict = field(default_factory=dict)

    def index(self) -> dict[str, Word]:
        return {w.id: w for w in self.words}


@dataclass
class Document:
    filename: str
    sha256: str
    source_pdf: bytes = field(repr=False)
    pages: list[Page] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    options: dict[str, Any] = field(default_factory=dict)
    edits: list[dict[str, Any]] = field(default_factory=list)

    normalized_pdf: bytes = field(default=b"", repr=False)
    original_input: bytes = field(default=b"", repr=False)

    def to_json(self) -> bytes:
        # Do not serialize input file bytes, font programs, or raw image bytes.
        result: dict[str, Any] = {
            "schema": "document-reconstructor/4",
            "coordinate_system": "top-left, PDF points (72/inch)",
            "filename": self.filename,
            "source_sha256": self.sha256,
            "options": self.options,
            "warnings": self.warnings,
            "edits": self.edits,
            "pages": [],
        }
        for page in self.pages:
            item = asdict(page)
            item["images"] = [{k: v for k, v in im.items() if k != "data"} for im in page.images]
            result["pages"].append(item)
        return json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")


def fingerprint(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()
