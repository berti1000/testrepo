from __future__ import annotations

import statistics
from bisect import bisect_right
from collections import Counter

from .model import Block, Cell, Options, Page, Word
from .geometry import (
    area,
    cluster,
    contains,
    group_lines,
    intersection,
    near_index,
    numeric_like,
    split_line,
    text_of,
    union,
)


def _rule_tables(page: Page, pdf_page) -> list[Block]:
    additions = []
    for r in page.rules:
        if r.get("source") != "raster":
            continue
        if r["axis"] == "h":
            additions.append(((r["start"], r["pos"]), (r["end"], r["pos"])))
        else:
            additions.append(((r["pos"], r["start"]), (r["pos"], r["end"])))
    try:
        found = pdf_page.find_tables(
            strategy="lines_strict",
            add_lines=additions or None,
            snap_tolerance=2,
            join_tolerance=2,
            intersection_tolerance=3,
            edge_min_length=5,
        )
    except Exception as exc:
        page.warnings.append("Ruled table detection failed; alignment fallback used: " + str(exc))
        return []
    tables = []
    for ti, table in enumerate(found.tables):
        rects = [tuple(float(v) for v in b) for b in table.cells if b]
        if table.row_count < 2 or table.col_count < 2 or not rects:
            continue
        xs = cluster([x for b in rects for x in (b[0], b[2])], 1.0)
        ys = cluster([y for b in rects for y in (b[1], b[3])], 1.0)
        cells = []
        assigned = set()
        for box in sorted(set(rects), key=lambda b: (b[1], b[0])):
            col, row = near_index(xs, box[0]), near_index(ys, box[1])
            end_col, end_row = near_index(xs, box[2]), near_index(ys, box[3])
            if end_col <= col or end_row <= row:
                continue
            ids = [w.id for w in page.words if w.id not in assigned and contains(box, w, pad=0)]
            assigned.update(ids)
            cells.append(Cell(row, col, end_row - row, end_col - col, box, ids))
        if not cells:
            continue
        table_block = Block(
            f"p{page.number}-t{ti + 1}",
            "table",
            tuple(table.bbox),
            words=list(assigned),
            cells=cells,
            x_edges=xs,
            y_edges=ys,
            method="ruled",
            confidence=None,
        )
        # Only mark a header when the first populated row is clearly non-numeric.
        idx = page.index()
        first = [c for c in cells if c.row == 0 and c.words]
        if first and not any(numeric_like(text_of(c.words, idx, False)) for c in first):
            table_block.header_rows = 1
        tables.append(table_block)
    # Prefer the outer/larger detected table to overlapping alternative hypotheses.
    kept = []
    for table in sorted(tables, key=lambda t: -area(t.bbox)):
        if not any(
            intersection(table.bbox, old.bbox) / max(1, min(area(table.bbox), area(old.bbox))) > 0.5
            for old in kept
        ):
            kept.append(table)
    return kept


def _chunk(ids, index, row):
    bbox = union([index[k].bbox for k in ids])
    return dict(ids=ids, box=bbox, row=row, numeric=numeric_like(text_of(ids, index, False)))


def _track_box(track):
    boxes = [c["box"] for c in track]
    return tuple(statistics.median(b[i] for b in boxes) for i in range(4))


def _distance(chunk, track):
    a, b = chunk["box"], _track_box(track)
    horizontal_overlap = max(0, min(a[2], b[2]) - max(a[0], b[0]))
    numeric = chunk["numeric"] and sum(c["numeric"] for c in track) >= len(track) / 2
    anchor = abs(a[2] - b[2]) if numeric else abs(a[0] - b[0])
    center = abs((a[0] + a[2] - b[0] - b[2]) / 2)
    if horizontal_overlap / max(1, min(a[2] - a[0], b[2] - b[0])) > 0.25:
        return min(anchor, center) * 0.6
    return min(anchor, center)


def safe_merge_rare_tracks(tracks: list[list[dict]], tolerance: float) -> list[list[dict]]:
    """No frequency-only deletion. Numeric and 2+-row tracks are NEVER merged here."""
    tracks = [list(t) for t in tracks]
    changed = True
    while changed:
        changed = False
        for i, track in enumerate(tracks):
            if len({c["row"] for c in track}) > 1 or any(c["numeric"] for c in track):
                continue
            candidates = []
            for j, other in enumerate(tracks):
                if i == j or {c["row"] for c in track} & {c["row"] for c in other}:
                    continue
                # Even a rare non-number needs real interval overlap, not just a nearby anchor.
                a, b = _track_box(track), _track_box(other)
                overlap = max(0, min(a[2], b[2]) - max(a[0], b[0]))
                if overlap <= 0:
                    continue
                d = _distance(track[0], other)
                if d < tolerance:
                    candidates.append((d, j))
            if candidates:
                j = min(candidates)[1]
                tracks[j].extend(track)
                tracks.pop(i)
                changed = True
                break
    return tracks


def _aligned_table(lines, page: Page, options: Options, ordinal: int) -> Block | None:
    index = page.index()
    rows = [
        [_chunk(ids, index, ri) for ids in split_line(line, index, options.gap_factor, page.rules)]
        for ri, line in enumerate(lines)
    ]
    dense_pair = sum(sum(c["numeric"] for c in row) >= 3 for row in rows) >= 2
    minimum = 2 if dense_pair else 3
    if len(rows) < minimum or sum(len(row) >= 2 for row in rows) < minimum:
        return None
    # Body numbers establish the tracks; a word such as Amount does not create a new anchor.
    body_indices = [
        i for i, row in enumerate(rows) if len(row) >= 2 and any(c["numeric"] for c in row)
    ]
    if len(body_indices) < 2:
        # Also support non-numeric repeated tables, but require more evidence.
        if len(rows) < 4:
            return None
        body_indices = list(range(len(rows)))
    seed = max(body_indices, key=lambda i: (len(rows[i]), sum(c["numeric"] for c in rows[i])))
    tracks = [[c] for c in rows[seed]]
    size = statistics.median(l.size for l in lines)
    tolerance = max(5.0, size * 0.9)
    for ri in body_indices:
        if ri == seed:
            continue
        for chunk in rows[ri]:
            candidates = [
                (_distance(chunk, track), j)
                for j, track in enumerate(tracks)
                if not any(c["row"] == ri for c in track)
            ]
            if candidates and min(candidates)[0] <= tolerance:
                tracks[min(candidates)[1]].append(chunk)
            else:
                tracks.append([chunk])
    tracks = safe_merge_rare_tracks(tracks, tolerance)
    tracks.sort(key=lambda t: (_track_box(t)[0] + _track_box(t)[2]) / 2)
    stable = sum(len({c["row"] for c in t}) >= 2 for t in tracks)
    if stable < 2 or len(tracks) > 48:
        return None
    boxes = [_track_box(t) for t in tracks]
    centers = [(b[0] + b[2]) / 2 for b in boxes]
    # Strongly overlapping hypotheses are ambiguous: do not pretend to have a table.
    if any(centers[i + 1] - centers[i] < 3 for i in range(len(centers) - 1)):
        return None
    all_box = union([line.bbox for line in lines])
    edges = [min(all_box[0], boxes[0][0]) - 2]
    for a, b in zip(boxes, boxes[1:]):
        # Use the whitespace between occupied intervals, not the two different alignments.
        edge = (a[2] + b[0]) / 2 if a[2] <= b[0] else ((a[0] + a[2] + b[0] + b[2]) / 4)
        edges.append(max(edges[-1] + 2, edge))
    edges.append(max(edges[-1] + 3, all_box[2] + 2))
    ys = [lines[0].bbox[1] - 2]
    for a, b in zip(lines, lines[1:]):
        ys.append((a.bbox[3] + b.bbox[1]) / 2)
    ys.append(lines[-1].bbox[3] + 2)
    mapped = []
    for ri, row in enumerate(rows):
        values = {}
        for chunk_index, chunk in enumerate(row):
            # Body items retain their proven track, including a genuine singleton numeric column.
            proved = next((j for j, t in enumerate(tracks) if any(c is chunk for c in t)), None)
            if proved is None:
                # A full header is a monotone one-to-one assignment, never four
                # independent nearest-left-edge decisions. Partial headers use
                # occupied column intervals rather than numeric left edges.
                if len(row) == len(tracks) and not any(c["numeric"] for c in row):
                    proved = chunk_index
                else:
                    cx = (chunk["box"][0] + chunk["box"][2]) / 2
                    proved = max(0, min(len(tracks) - 1, bisect_right(edges, cx) - 1))
            values.setdefault(proved, []).extend(chunk["ids"])
        mapped.append(values)
    # Fold a close, non-numeric continuation into its preceding logical cell.
    # A normal-spaced sparse row is NOT merged just because its amount is empty.
    gaps = [b.baseline - a.baseline for a, b in zip(lines, lines[1:])]
    typical_gap = statistics.median(gaps) if gaps else size * 1.5
    logical = []
    for ri, values in enumerate(mapped):
        continuation = False
        if ri > 1 and len(values) == 1 and logical:
            ci = next(iter(values))
            continuation = (
                ci in logical[-1]["values"]
                and len(logical[-1]["values"]) >= 2
                and not numeric_like(text_of(values[ci], index, False))
                and lines[ri].baseline - lines[ri - 1].baseline
                < min(size * 1.45, typical_gap * 0.8)
            )
        if continuation:
            logical[-1]["values"][ci].extend(values[ci])
            logical[-1]["end"] = ri
        else:
            logical.append(dict(values={k: list(v) for k, v in values.items()}, start=ri, end=ri))
    cells = []
    logical_ys = [ys[logical[0]["start"]]]
    for item in logical:
        logical_ys.append(ys[item["end"] + 1])
    for ri, item in enumerate(logical):
        for ci in range(len(tracks)):
            cells.append(
                Cell(
                    ri,
                    ci,
                    1,
                    1,
                    (edges[ci], logical_ys[ri], edges[ci + 1], logical_ys[ri + 1]),
                    item["values"].get(ci, []),
                )
            )
    ys = logical_ys
    header = 1 if not any(c["numeric"] for c in rows[0]) else 0
    block = Block(
        f"p{page.number}-u{ordinal}",
        "table",
        (edges[0], ys[0], edges[-1], ys[-1]),
        words=[k for row in rows for c in row for k in c["ids"]],
        cells=cells,
        x_edges=edges,
        y_edges=ys,
        method="alignment",
        confidence=None,
        header_rows=header,
    )
    if any(len({c["row"] for c in t}) <= 1 for t in tracks):
        block.warnings.append(
            "Sparse column retained conservatively; check its assignment. No numeric singleton was deleted."
        )
    return block


def _paragraphs(words: list[Word], page: Page) -> list[Block]:
    index = page.index()
    lines = group_lines(words)
    groups = []
    for line in lines:
        merged = False
        if groups:
            prev = groups[-1][-1]
            gap = line.baseline - prev.baseline
            # Do not merge key/value rows or columns into a giant multi-line cell.
            one_chunk = len(split_line(line, index, 0.95, page.rules)) == 1
            previous_one = len(split_line(prev, index, 0.95, page.rules)) == 1
            separates = any(
                r["axis"] == "h"
                and prev.baseline < r["pos"] < line.baseline
                and r["start"] < line.bbox[2]
                and r["end"] > line.bbox[0]
                for r in page.rules
            )
            if (
                one_chunk
                and previous_one
                and not separates
                and 0 < gap <= max(10, line.size * 1.6)
                and abs(line.bbox[0] - prev.bbox[0]) < 4
                and abs(line.size - prev.size) < 1
            ):
                groups[-1].append(line)
                merged = True
        if not merged:
            groups.append([line])
    return [
        Block(
            f"p{page.number}-b{i + 1}",
            "paragraph",
            union([l.bbox for l in group]),
            words=[k for l in group for k in l.words],
        )
        for i, group in enumerate(groups)
    ]


def build_layout(page: Page, pdf_page, options: Options):
    if page.ocr_ran and page.words and page.rules:
        # A raster-only source has no text layer and PyMuPDF filters its cells.
        # Probe the geometry using the IR's real glyphs; retain original word IDs.
        import fitz
        from .model import Document
        from .render import reconstructed_pdf

        probe = reconstructed_pdf(Document("layout-probe", "", b"", pages=[page]))
        with fitz.open(stream=probe, filetype="pdf") as detected:
            tables = _rule_tables(page, detected[0])
    else:
        tables = _rule_tables(page, pdf_page)
    assigned = {k for t in tables for k in t.words}
    lines = group_lines([w for w in page.words if w.id not in assigned])
    if options.unruled_tables:
        index = page.index()
        runs = []
        current = []
        for line in lines:
            chunks = split_line(line, index, options.gap_factor, page.rules)
            gap = line.baseline - current[-1].baseline if current else 0
            # Existing ruled regions and large paragraph gaps break table candidates.
            boundary = (
                any(t.bbox[1] >= current[-1].bbox[1] and t.bbox[3] <= line.bbox[3] for t in tables)
                if current
                else False
            )
            if current and (gap > max(36.0, line.size * 3.1) or boundary):
                runs.append(current)
                current = []
            if len(chunks) >= 2:
                current.append(line)
            else:
                # One wrapped continuation line can remain inside an established candidate.
                neural_continuation = (
                    current
                    and all(index[k].source.startswith("paddle") for k in line.words)
                    and not numeric_like(text_of(line.words, index, False))
                )
                if (
                    len(current) >= (1 if neural_continuation else 2)
                    and line.bbox[0] >= current[0].bbox[0] - 2
                    and gap < line.size * (1.8 if neural_continuation else 1.45)
                ):
                    current.append(line)
                else:
                    if current:
                        runs.append(current)
                        current = []
        if current:
            runs.append(current)
        for run in runs:
            table = _aligned_table(run, page, options, len(tables) + 1)
            if table and not any(
                intersection(table.bbox, t.bbox) / max(1, min(area(table.bbox), area(t.bbox))) > 0.2
                for t in tables
            ):
                tables.append(table)
                assigned.update(table.words)
    paragraphs = _paragraphs([w for w in page.words if w.id not in assigned], page)
    page.blocks = sorted(tables + paragraphs, key=lambda b: (b.bbox[1], b.bbox[0]))
    audit_page(page)


def audit_page(page: Page) -> dict:
    occurrences = Counter(
        k
        for b in page.blocks
        for k in ([k for c in b.cells for k in c.words] if b.kind == "table" else b.words)
    )
    expected = {w.id for w in page.words}
    missing = expected - set(occurrences)
    duplicates = {k: v for k, v in occurrences.items() if v != 1}
    if missing or duplicates:
        raise ValueError(
            f"Layout ownership violation: {len(missing)} missing words, {len(duplicates)} repeated words."
        )
    return dict(
        words=len(expected),
        assigned=len(occurrences),
        missing=0,
        duplicates=0,
        tables=sum(b.kind == "table" for b in page.blocks),
        low_confidence=sum(w.needs_review for w in page.words),
    )


def manual_table(
    page: Page, bbox: tuple[float, float, float, float], x_edges: list[float], y_edges: list[float]
):
    """Explicit human structure correction; coordinates stay in PDF points."""
    x0, y0, x1, y1 = bbox
    xs = sorted(set([x0, x1] + [x for x in x_edges if x0 < x < x1]))
    ys = sorted(set([y0, y1] + [y for y in y_edges if y0 < y < y1]))
    if len(xs) < 3 or len(ys) < 3:
        raise ValueError("At least two rows and two columns are required.")
    ids = {w.id for w in page.words if contains(bbox, w)}
    if not ids:
        raise ValueError("The chosen region has no text.")
    # Reject cuts through existing tables. Full-table replacement is safe.
    for block in page.blocks:
        if block.kind == "table" and ids & set(block.words) and not set(block.words) <= ids:
            raise ValueError("Region cuts an existing table. Select the entire table.")
    cells = []
    assigned = set()
    for row in range(len(ys) - 1):
        for col in range(len(xs) - 1):
            box = (xs[col], ys[row], xs[col + 1], ys[row + 1])
            selected = [
                w.id
                for w in page.words
                if w.id in ids and w.id not in assigned and contains(box, w, 0)
            ]
            assigned.update(selected)
            cells.append(Cell(row, col, 1, 1, box, selected))
    if assigned != ids:
        raise ValueError("A boundary excludes text; adjust the region.")
    remaining = []
    for block in page.blocks:
        if block.kind == "table" and set(block.words) <= ids:
            continue
        if block.kind == "paragraph":
            block.words = [k for k in block.words if k not in ids]
            if not block.words:
                continue
            block.bbox = union([page.index()[k].bbox for k in block.words])
        remaining.append(block)
    remaining.append(
        Block(
            f"p{page.number}-manual-{len(remaining)}",
            "table",
            bbox,
            words=list(ids),
            cells=cells,
            x_edges=xs,
            y_edges=ys,
            method="manual",
        )
    )
    page.blocks = sorted(remaining, key=lambda b: (b.bbox[1], b.bbox[0]))
    audit_page(page)
