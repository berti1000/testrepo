from __future__ import annotations

import math
import re
import statistics
import unicodedata
from collections import defaultdict
from .model import Box, Word, Line


def clean(text: str) -> str:
    # Never change decimal separators, dates, IDs or punctuation.
    text = unicodedata.normalize("NFC", str(text))
    return re.sub(r"[\t\r\n\u00a0\u2007\u202f ]+", " ", text).strip()


def union(boxes: list[Box]) -> Box:
    if not boxes:
        return (0.0, 0.0, 0.0, 0.0)
    return (
        min(b[0] for b in boxes),
        min(b[1] for b in boxes),
        max(b[2] for b in boxes),
        max(b[3] for b in boxes),
    )


def area(b: Box) -> float:
    return max(0, b[2] - b[0]) * max(0, b[3] - b[1])


def intersection(a: Box, b: Box) -> float:
    return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))


def contains(b: Box, w: Word, pad: float = 0.5) -> bool:
    x, y = (w.bbox[0] + w.bbox[2]) / 2, (w.bbox[1] + w.bbox[3]) / 2
    return b[0] - pad <= x <= b[2] + pad and b[1] - pad <= y <= b[3] + pad


def cluster(values: list[float], tolerance: float = 2.0) -> list[float]:
    groups: list[list[float]] = []
    for v in sorted(float(x) for x in values):
        if groups and abs(v - statistics.median(groups[-1])) <= tolerance:
            groups[-1].append(v)
        else:
            groups.append([v])
    return [float(statistics.median(g)) for g in groups]


def near_index(values: list[float], v: float) -> int:
    return min(range(len(values)), key=lambda i: abs(values[i] - v))


def numeric_like(text: str) -> bool:
    # Used ONLY for alignment, never automatic value conversion.
    t = clean(text).replace("\u2212", "-")
    t = re.sub(r"(?i)(HUF|EUR|USD|GBP|CHF|Ft|%|\u20ac|\$)", "", t).strip()
    return bool(re.fullmatch(r"[+-]?\(?\d[\d ,.]*\)?", t))


def group_lines(words: list[Word]) -> list[Line]:
    """Use baselines, not top edges. Protect small superscripts and close rows."""
    groups: list[list[Word]] = []
    for word in sorted(words, key=lambda w: (w.origin[1], w.bbox[0])):
        if not word.text:
            continue
        best = None
        best_dist = math.inf
        for i in range(len(groups) - 1, max(-1, len(groups) - 20), -1):
            g = groups[i]
            by = statistics.median(w.origin[1] for w in g)
            size = statistics.median(w.size for w in g)
            tol = max(1.0, min(3.0, min(size, word.size) * 0.23))
            if word.source.startswith("paddle") and all(w.source.startswith("paddle") for w in g):
                # Independently recognized numeric cells may have slightly
                # different baseline estimates on the same printed row.
                tol = max(tol, min(3.5, min(size, word.size) * 0.4))
            dist = abs(word.origin[1] - by)
            if dist <= tol and dist < best_dist:
                # Vertical/strongly rotated runs are never mixed with normal rows.
                if abs(word.direction[1] - g[0].direction[1]) > 0.12:
                    continue
                best, best_dist = i, dist
        if best is None:
            groups.append([word])
        else:
            groups[best].append(word)
    lines = []
    for g in groups:
        g.sort(key=lambda w: w.bbox[0])
        lines.append(
            Line(
                [w.id for w in g],
                union([w.bbox for w in g]),
                statistics.median(w.origin[1] for w in g),
                statistics.median(w.size for w in g),
            )
        )
    return sorted(lines, key=lambda l: (l.baseline, l.bbox[0]))


def normalize_ocr_lines(words: list[Word]) -> None:
    """Only OCR typography is estimated. Native sizes/origins are not flattened."""
    grouped: dict[str, list[Word]] = defaultdict(list)
    for word in words:
        if word.source == "ocr":
            grouped[word.line_hint].append(word)
    for group in grouped.values():
        fs = statistics.median(w.size for w in group)
        # hOCR supplies a common baseline already, including its slope.
        for word in group:
            if 0.72 * fs <= word.size <= 1.38 * fs:
                word.size = fs


def text_of(ids: list[str], index: dict[str, Word], multiline: bool = True) -> str:
    words = [index[k] for k in ids if k in index and index[k].text]
    out = []
    for line in group_lines(words):
        out.append(" ".join(index[k].text for k in line.words))
    return ("\n" if multiline else " ").join(out)


def split_line(
    line: Line,
    index: dict[str, Word],
    factor: float = 0.95,
    vertical_rules: list[dict] | None = None,
) -> list[list[str]]:
    words = [index[k] for k in line.words if index[k].text]
    if not words:
        return []
    out: list[list[str]] = [[words[0].id]]
    threshold = max(5.5, line.size * factor)
    for a, b in zip(words, words[1:]):
        gap = b.bbox[0] - a.bbox[2]
        ruled = any(
            r["axis"] == "v"
            and a.bbox[2] <= r["pos"] <= b.bbox[0]
            and r["start"] <= line.baseline <= r["end"]
            for r in (vertical_rules or [])
        )
        # Separate neighbouring decimal fields, but not thousands groups or currency.
        decimal_pair = (
            bool(re.search(r"[.,]\d{2}$", a.text))
            and bool(re.search(r"[.,]\d{2}$", b.text))
            and gap > line.size * 0.35
        )
        if gap > threshold or ruled or decimal_pair:
            out.append([b.id])
        else:
            out[-1].append(b.id)
    return out


def deduplicate(words: list[Word]) -> list[Word]:
    """Only equal text at almost the same position; repetitions elsewhere survive."""
    buckets: dict[tuple[int, int], list[Word]] = defaultdict(list)
    result = []
    for word in words:
        bx, by = int(word.bbox[0] / 8), int(word.bbox[1] / 8)
        duplicates = [
            old
            for dx in (-1, 0, 1)
            for dy in (-1, 0, 1)
            for old in buckets[(bx + dx, by + dy)]
            if old.text == word.text
            and intersection(old.bbox, word.bbox) / max(1, min(area(old.bbox), area(word.bbox)))
            > 0.85
        ]
        if not duplicates:
            buckets[(bx, by)].append(word)
            result.append(word)
    return result
