"""Local document reconstruction with an optional, explicitly invoked Vision reviewer."""

__version__ = "4.0.0"
