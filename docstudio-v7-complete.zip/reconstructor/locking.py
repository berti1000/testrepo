"""Serialize native MuPDF and ReportLab access across web worker threads."""

import threading
from functools import wraps

LOCK = threading.RLock()


def serialized(fn):
    @wraps(fn)
    def inner(*args, **kwargs):
        with LOCK:
            return fn(*args, **kwargs)

    return inner
