# V7

- A scanek grafikai rétege az eredeti íveket, pontozást, aláírást és vonalvastagságot őrzi meg; a felismert szöveget külön, szerkeszthető betűkkel rajzolja újra. Teljes szövegsoros maszkolás a keskeny OCR-szódobozból kilógó régi betűk ellen.
- Mért szövegszélesség, szomszédos sorok ütközéskorrekciója és dokumentumszintű betűcsalád-egységesítés a bizonytalan OCR-oldalakon.
- Inline betűméret, félkövérség és betűcsalád; nagyobb szavaknál szomszédos elemek átrendezése. A nagy bevezető címblokk eltávolítva.
- Excel: tartalom alapján növekvő sormagasság és oszlopszélesség, explicit rich text színek, minden exportútról eltávolított megjegyzések. Sűrű nyugták utolsó oszlopának határkezelése javítva.
- Gyorsabb vonalkereső, választható másodlagos OCR-ellenőrzés és kiegyensúlyozott OCR-menetszám.
- Vision konfigurációs visszajelzés, dokumentumküldés nélküli kapcsolatpróba és érthető HTTP-hibák.
- Yarn APT-kulcshiba célzott, biztonsági másolatos kezelése. Új mintafájl-ellenőrző program és bővített böngészős/regressziós tesztek.

Mérések és ismert korlátok: `docs/TEST_REPORT.md`.

# V6

- PDF → XLSX: stílust és térbeli elrendezést megtartó, valóban szerkeszthető cellák; többsoros rekordok és üres fejlécmezők megőrzése.
- A tényleges XLSX-ből származó, alapértelmezett rácsos előnézet, munkalapfülek, cellacímek és formázás.
- Közvetlen vászonszerkesztés, középen lebegő jóváhagyás, SVG formátumikonok és jóváhagyáskor automatikus letöltés.
- Valós beolvasási és export-stratégiaváltások; átlátható változásdiagnosztika és visszaállítás.
- PNG-export egy vagy több oldalhoz; CLI formátumválasztó frissítése.
- Python 3.11-es Codespaces-kép, rendszerfüggőség-telepítő és kompatibilitást ellenőrző setup.
- PDF/Word rajzoló és az elsődleges OCR kódja változatlan.

Részletes bizonyítékok és korlátok: `docs/TEST_REPORT.md`.
