"""v5 regression tests: independent invariants, real files, durable review loop."""

import hashlib
import io
import json
import time
import zipfile
import fitz
import openpyxl
import pytest
from PIL import Image
from fastapi.testclient import TestClient
from studio.ir import AssetStore, IRDocument, Profile, to_runtime
from studio.pipeline import ingest, retry_page
from studio.router import Router
from studio.store import Store, Conflict
from studio.workflow import transition
from studio.output.service import OutputOptions, fallback, generate
from studio.output import excel, word
from reconstructor.model import Document, Page, Word, Block, Cell
from tests.fixtures import make_invoice


@pytest.fixture
def store(tmp_path):
    s = Store(tmp_path / "store")
    yield s
    s.executor.shutdown(wait=True)


@pytest.fixture
def sample(tmp_path):
    assets = AssetStore(tmp_path / "assets")
    ir = ingest(make_invoice(rows=3, merged=False), "native.pdf", assets, {"orientation": False})
    ir.revision = 1
    return ir, assets


@pytest.mark.parametrize(
    "kind,expected",
    [
        ("text", "native"),
        ("word", "native"),
        ("scanned", "paddle"),
        ("mixed", "paddle"),
        ("financial", "paddle"),
    ],
)
def test_profile_routes(kind, expected):
    caps = {x: {"available": True} for x in ["native", "paddle", "tesseract", "tatr", "vision"]}
    s = Router(caps).choose(Profile(kind=kind, label="", reasons=[], pages=1))
    assert s.ocr == expected
    if kind == "financial":
        assert s.table == "tatr"


@pytest.mark.parametrize("error", ["text", "columns", "table"])
def test_error_strategy_changes(error):
    caps = {x: {"available": True} for x in ["native", "paddle", "tesseract", "tatr", "vision"]}
    r = Router(caps)
    p = Profile(kind="scanned", label="", reasons=[], pages=1)
    first = r.choose(p)
    other = r.choose(p, error=error, current=first.ocr)
    assert other.id != first.id
    assert other.ocr != "vision"
    assert r.choose(p, "text", 3, "paddle", consent=True).ocr == "vision"
    with pytest.raises(ValueError):
        r.choose(p, requested="vision")


@pytest.mark.parametrize(
    "state,event",
    [
        ("input_review", "export"),
        ("exporting", "edit"),
        ("processing", "accept_input"),
        ("input_review", "accept_export"),
        ("ready", "accept_export"),
    ],
)
def test_illegal_state_transitions(state, event):
    with pytest.raises(ValueError):
        transition(state, event)


def test_ir_roundtrip_assets_and_validation(sample):
    ir, a = sample
    restored = IRDocument.model_validate_json(ir.dump())
    assert restored.model_dump(mode="json") == ir.model_dump(mode="json")
    assert to_runtime(restored, a).source_pdf.startswith(b"%PDF")
    with pytest.raises(ValueError):
        a.get("../../escape")
    key = a.put(b"asset")
    (a.root / key).write_bytes(b"corrupt")
    with pytest.raises(ValueError):
        a.get(key)
    for mutation in ["nan", "duplicate", "reference"]:
        d = ir.model_dump()
        if mutation == "nan":
            d["pages"][0]["words"][0]["bbox"] = [0, 0, float("nan"), 20]
        if mutation == "duplicate":
            d["pages"][0]["words"].append(d["pages"][0]["words"][0])
        if mutation == "reference":
            d["pages"][0]["blocks"][0]["words"].append("missing-id")
        with pytest.raises(ValueError):
            IRDocument.model_validate(d)


def done(s, id):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        j = s.get(id)
        if j["state"] not in ("queued", "profiling", "processing", "exporting"):
            return j
        time.sleep(0.025)
    pytest.fail("Worker timed out")


def loaded(s):
    j = s.create(make_invoice(rows=2, merged=False), "native.pdf", "owner", {})
    s.dispatch_import(j["id"], {"orientation": False})
    j = done(s, j["id"])
    assert j["state"] == "input_review", j
    return j


def test_revision_optimism_restore_and_restart(store):
    j = loaded(store)
    id = j["id"]
    original = store.load_ir(id).dump()
    token = store.load_ir(id).pages[0].words[0]
    changed = store.edit(id, "owner", j["version"], 1, token.id, "ÁRVÍZTŰRŐ")
    assert changed["revision"] == 2
    assert store.load_ir(id, 1).dump() == original
    with pytest.raises(Conflict):
        store.edit(id, "owner", j["version"], 1, token.id, "stale")
    with pytest.raises(KeyError):
        store.get(id, "stranger")
    back = store.restore_revision(id, "owner", changed["version"], 1)
    assert back["revision"] == 1
    new = store.edit(id, "owner", back["version"], 1, token.id, "new branch")
    assert new["revision"] == 3
    new["state"] = "processing"
    store.save(new)
    store.recover()
    assert store.get(id)["state"] == "input_review"
    reopened = Store(store.root)
    assert reopened.load_ir(id).pages[0].words[0].text == "new branch"
    reopened.executor.shutdown()


def test_page_retry_preserves_other_pages(tmp_path):
    with fitz.open(stream=make_invoice(rows=2), filetype="pdf") as p, fitz.open() as q:
        q.insert_pdf(p)
        q.insert_pdf(p)
        data = q.tobytes()
    a = AssetStore(tmp_path / "assets")
    ir = ingest(data, "two.pdf", a, {"orientation": False})
    ir.revision = 1
    second = ir.model_dump()["pages"][1]
    retried = retry_page(ir, a, 1, "columns", 0, {"engine": "native"})
    assert retried.model_dump()["pages"][1] == second
    assert retried.pages[0].words[0].id.startswith("p1-r2-")
    assert retried.provenance[-1]["error"] == "columns"


def test_word_contains_editable_text_and_page_relative_frames(sample):
    ir, a = sample
    data = word.export(to_runtime(ir, a))
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode()
        assert "w:txbxContent" in xml and "mso-position-vertical-relative:page" in xml
        assert "0pt,0pt,0pt,0pt" in xml
        assert "DEMO" in xml and "w:t" in xml


def grid_document():
    vals = [
        "Megnevezés",
        "Összeg",
        '=HYPERLINK("https://invalid")',
        "1 234,56",
        "Azonosító",
        "001234",
    ]
    words = [
        Word(str(i), t, (i * 30 + 1, 10, i * 30 + 29, 22), (i * 30 + 1, 21), 10)
        for i, t in enumerate(vals)
    ]
    cells = [Cell(i // 2, i % 2, 1, 1, w.bbox, [w.id]) for i, w in enumerate(words)]
    p = Page(
        1,
        595,
        842,
        words=words,
        blocks=[
            Block(
                "t",
                "table",
                (0, 0, 250, 100),
                [w.id for w in words],
                cells,
                method="test",
                header_rows=1,
            )
        ],
    )
    return Document("test", "", b"", pages=[p])


def test_excel_numeric_safety_and_grid():
    data = excel.export(grid_document(), numbers="hu", mode="semantic")
    wb = openpyxl.load_workbook(io.BytesIO(data))
    ws = wb.active
    assert ws.max_column == 2 and ws.max_row == 3
    assert ws["B2"].value == 1234.56 and ws["B2"].data_type == "n"
    assert ws["A2"].data_type == "s" and ws["A2"].value.startswith("=")
    assert ws["B3"].value == "001234" and ws["B3"].data_type == "s"
    assert excel.preview(data)[0]["rows"][1][1] == 1234.56


@pytest.mark.parametrize(
    "fmt,error,field,value",
    [
        ("docx", "drift", "word_mode", "precise"),
        ("docx", "flow", "word_mode", "flow"),
        ("docx", "margins", "margin", 0),
        ("xlsx", "numbers", "numbers", "hu"),
        ("xlsx", "empty", "merge", False),
        ("xlsx", "columns", "compact", True),
    ],
)
def test_export_strategy_parameters(fmt, error, field, value):
    assert getattr(fallback(OutputOptions(format=fmt), error), field) == value


def test_xlsx_import_preserves_native_cells_formulas_and_merges(tmp_path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws["A1"] = "Fejléc"
    ws.merge_cells("A1:B1")
    ws["A2"] = "00123"
    ws["B2"] = 1234.5
    ws["A3"] = "=SUM(B2:B2)"
    b = io.BytesIO()
    wb.save(b)
    ir = ingest(b.getvalue(), "table.xlsx", AssetStore(tmp_path / "a"))
    assert ir.profile.kind == "spreadsheet"
    assert ir.pages[0].blocks[0].cells[0].colspan == 2
    assert any(w.text == "00123" for w in ir.pages[0].words)
    assert any("képlet" in t for t in ir.pages[0].warnings)


def test_vision_prompt_consent_and_strict_geometry(monkeypatch):
    from studio.engines import vision
    import httpx

    monkeypatch.setenv("VISION_MODEL", "test")
    monkeypatch.setenv("VISION_BASE_URL", "http://local.invalid/v1")
    captured = []
    payload = {"words": [{"text": "Árvíztűrő", "box": [10, 10, 200, 70]}]}

    def transport(req):
        captured.append(json.loads(req.content))
        return httpx.Response(
            200, json={"choices": [{"message": {"content": json.dumps(payload)}}]}
        )

    client = httpx.Client(transport=httpx.MockTransport(transport))
    monkeypatch.setattr(vision.httpx, "Client", lambda **kw: client)
    out = vision.recognize(Image.new("RGB", (800, 800), "white"), Page(1, 595, 842), "columns")
    assert "merged columns" in captured[0]["messages"][0]["content"][0]["text"]
    assert out[0].text == "Árvíztűrő" and out[0].needs_review
    with pytest.raises(ValueError):
        vision.Result.model_validate({"words": [{"text": "x", "box": [0, 0, float("inf"), 20]}]})


@pytest.fixture
def api(store, monkeypatch):
    monkeypatch.setenv("APP_ENV", "development")
    monkeypatch.setenv("APP_SESSION_SECRET", "studio-tests-" * 5)
    from web.main import app
    from web.routes import studio_api
    import studio.store

    monkeypatch.setattr(studio_api, "STORE", store)
    monkeypatch.setattr(studio.store, "STORE", store)
    with TestClient(app) as c:
        c.get("/")
        yield c, app


def test_api_complete_review_flow(api, store):
    c, app = api
    r = c.post(
        "/api/studio/jobs",
        files={"files": ("test.pdf", make_invoice(rows=2, merged=False), "application/pdf")},
        data={"settings": '{"orientation":false}'},
    )
    assert r.status_code == 202, r.text
    j = done(store, r.json()[0]["id"])
    base = "/api/studio/jobs/" + j["id"]
    assert c.get(base + "/download").status_code == 409
    ir = c.get(base + "/ir").json()
    w = ir["pages"][0]["words"][0]
    payload = {"version": j["version"], "page": 1, "word": w["id"], "text": "ÁRVÍZTŰRŐ"}
    r = c.patch(base + "/word", json=payload)
    assert r.status_code == 200
    assert c.patch(base + "/word", json=payload).status_code == 409
    j = r.json()
    assert (
        c.post(
            base + "/accept-input",
            json={"version": j["version"]},
            headers={"Origin": "https://evil.invalid"},
        ).status_code
        == 403
    )
    j = c.post(base + "/accept-input", json={"version": j["version"]}).json()
    assert (
        c.post(
            base + "/export", json={"version": j["version"], "options": {"format": "pdf"}}
        ).status_code
        == 202
    )
    j = done(store, j["id"])
    assert j["state"] == "export_review", j
    assert c.get(base + "/download").status_code == 409
    assert c.get(base + "/output-page/1").content.startswith(b"\x89PNG")
    assert (
        c.post(base + "/accept-export", json={"version": j["version"], "sha256": "bad"}).status_code
        == 409
    )
    j = c.post(
        base + "/accept-export", json={"version": j["version"], "sha256": j["export"]["sha256"]}
    ).json()
    out = c.get(base + "/download")
    assert out.status_code == 200
    assert hashlib.sha256(out.content).hexdigest() == j["export"]["sha256"]
    with fitz.open(stream=out.content, filetype="pdf") as pdf:
        assert "ÁRVÍZTŰRŐ" in pdf[0].get_text()
    with TestClient(app) as stranger:
        stranger.get("/")
        assert stranger.get(base + "/ir").status_code == 404
        assert stranger.get(base + "/download").status_code == 404
    z = c.post("/api/studio/batch", json=[j["id"]])
    assert z.status_code == 200
    assert len(zipfile.ZipFile(io.BytesIO(z.content)).namelist()) == 1


def test_api_invalid_batch_rolls_back(api, store):
    c, _ = api
    r = c.post(
        "/api/studio/jobs",
        files=[
            ("files", ("good.pdf", make_invoice(rows=2), "application/pdf")),
            ("files", ("bad.pdf", b"bad", "application/pdf")),
        ],
    )
    assert r.status_code == 400
    with store.connection() as db:
        assert db.execute("SELECT COUNT(*) FROM jobs").fetchone()[0] == 0
    assert c.post("/api/studio/batch", content=b"x" * 270000).status_code == 413


@pytest.mark.skipif(
    not __import__("os").getenv("RUN_OFFICE_TESTS"), reason="LibreOffice integration opt-in"
)
@pytest.mark.parametrize("fmt", ["docx", "xlsx"])
def test_actual_office_preview(sample, tmp_path, fmt):
    ir, a = sample
    folder = tmp_path / "out"
    info = generate(ir, a, OutputOptions(format=fmt), folder)
    assert info["preview_kind"] == "actual-file"
    assert info["preview_pages"] >= 1 and (folder / "page-1.png").exists()
    assert hashlib.sha256((folder / info["filename"]).read_bytes()).hexdigest() == info["sha256"]
    with fitz.open(folder / "preview.pdf") as pdf:
        assert "DEMO" in "".join(p.get_text() for p in pdf)
    if fmt == "docx":
        new = ingest(
            (folder / info["filename"]).read_bytes(),
            "roundtrip.docx",
            AssetStore(tmp_path / "roundtrip"),
        )
        assert any(w.text == "DEMO" for p in new.pages for w in p.words)


def test_ctc_token_split_does_not_corrupt_amounts():
    from studio.engines.neural import align_tokens
    from reconstructor.ocr import pilfont

    tokens = [
        ("Am", 0.9, (0, 0, 20, 10)),
        ("ount", 0.9, (20, 0, 50, 10)),
        ("347", 0.95, (70, 0, 100, 10)),
        (".25", 0.95, (100, 0, 125, 10)),
    ]
    aligned = align_tokens("Amount 347.25", tokens, pilfont("sans", False))
    assert [t[0] for t in aligned] == ["Amount", "347.25"]
    assert aligned[1][2] == (70, 0, 125, 10)
    assert align_tokens("different", tokens, pilfont("sans", False)) == []


def test_xlsx_merged_cell_continues_across_pages(tmp_path):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws["A1"] = "Hosszú cella"
    ws.merge_cells("A1:B45")
    ws["C45"] = "Utolsó"
    b = io.BytesIO()
    wb.save(b)
    ir = ingest(b.getvalue(), "long.xlsx", AssetStore(tmp_path / "a"))
    assert len(ir.pages) == 2
    assert any(w.text == "Hosszú cella" for w in ir.pages[1].words)
    assert ir.pages[1].blocks[0].cells[0].rowspan == 5


@pytest.mark.skipif(
    not __import__("os").getenv("RUN_OFFICE_TESTS"), reason="LibreOffice integration opt-in"
)
def test_positioned_word_does_not_wrap_narrow_ocr_box():
    from studio.office import convert_pdf

    w = Word("1", "Végösszeg:", (20, 20, 35, 32), (20, 30), 12, render_scale=1, line_hint="one")
    data = word.export(Document("test", "", b"", pages=[Page(1, 300, 300, words=[w])]))
    with fitz.open(stream=convert_pdf(data, ".docx"), filetype="pdf") as doc:
        lines = [
            line for b in doc[0].get_text("dict")["blocks"] if "lines" in b for line in b["lines"]
        ]
        assert len(lines) == 1 and "Végösszeg:" in doc[0].get_text()


def test_secondary_ocr_disagreement_is_not_a_silent_edit(monkeypatch):
    from studio.engines import verify

    w = Word("1", "Arvíztúrő", (10, 10, 100, 30), (10, 28), 12, confidence=0.99)
    page = Page(1, 200, 200, words=[w])
    monkeypatch.setattr(
        verify.pytesseract,
        "image_to_data",
        lambda *a, **k: {
            "text": ["Arvíztűrő"],
            "conf": ["96"],
            "left": [10],
            "top": [10],
            "width": [90],
            "height": [20],
        },
    )
    verify.crosscheck(Image.new("RGB", (200, 200), "white"), page)
    assert w.text == "Arvíztúrő" and w.alternatives == ["Arvíztűrő"] and w.needs_review
    assert page.diagnostics["crosscheck"]["disagreements"] == 1


def test_receipt_ctc_stride_keeps_the_amount_at_the_line_end():
    from studio.engines.neural import normalize_ctc_boxes

    tokens = [("Végösszeg:", 0.99, (23, 10, 100, 30)), ("6000", 0.98, (140, 10, 174, 30))]
    result, changed = normalize_ctc_boxes(tokens, 23, 696)
    assert changed and [v[0] for v in result] == ["Végösszeg:", "6000"]
    assert result[0][2][0] == 23 and result[-1][2][2] == pytest.approx(696)
    assert result[-1][2][0] > 500
    unchanged, changed = normalize_ctc_boxes(result, 23, 696)
    assert not changed and unchanged == result


def test_washed_out_ocr_input_is_normalized_without_changing_source():
    from studio.engines.neural import normalize_contrast
    from PIL import ImageDraw

    source = Image.new("RGB", (200, 100), (252, 252, 252))
    ImageDraw.Draw(source).rectangle((20, 20, 100, 70), fill=(150, 150, 150))
    before = source.tobytes()
    normalized, info = normalize_contrast(source)
    assert info["applied"] and normalized.getpixel((40, 40)) == (0, 0, 0)
    assert source.tobytes() == before
    assert not normalize_contrast(normalized)[1]["applied"]


def test_image_only_pdf_can_recover_a_ruled_grid_from_ir(sample):
    import copy
    from reconstructor.layout import build_layout
    from reconstructor.model import Options

    ir, assets = sample
    p = copy.deepcopy(to_runtime(ir, assets).pages[0])
    p.ocr_ran = True
    for w in p.words:
        w.source = "paddle-ppocrv5-latin"
    with fitz.open() as empty:
        build_layout(p, empty.new_page(width=p.width, height=p.height), Options())
    assert any(b.kind == "table" and b.method == "ruled" for b in p.blocks)


def test_two_numeric_rows_with_neural_baseline_jitter_are_one_grid():
    from reconstructor.layout import build_layout
    from reconstructor.model import Options

    words = []
    for ri, values in enumerate(
        [["Product A", "2", "100.00", "200.00"], ["Product B", "3", "50.00", "150.00"]]
    ):
        for ci, value in enumerate(values):
            x, baseline = 10 + ci * 90, 30 + ri * 20 + [0, 2, -1, 1][ci]
            words.append(
                Word(
                    f"{ri}-{ci}",
                    value,
                    (x, baseline - 10, x + 55, baseline + 2),
                    (x, baseline),
                    12,
                    source="paddle-ppocrv5-latin",
                )
            )
    p = Page(1, 400, 200, words=words, ocr_ran=True)
    with fitz.open() as empty:
        build_layout(p, empty.new_page(width=400, height=200), Options())
    tables = [b for b in p.blocks if b.kind == "table"]
    assert len(tables) == 1 and len(tables[0].y_edges) == 3
    assert len(tables[0].x_edges) == 5 and len(tables[0].words) == 8


def test_partial_neural_table_cannot_discard_existing_data_rows():
    from studio.engines.tables import select_complete_tables

    old = Block("old", "table", (0, 0, 100, 100), ["a", "b", "c", "d"])
    partial = Block("new", "table", (0, 0, 100, 50), ["a", "b"], confidence=0.99)
    complete = Block("new", "table", (0, 0, 100, 100), ["a", "b", "c", "d"], confidence=0.99)
    assert select_complete_tables([partial], [old]) == ([], 1)
    assert select_complete_tables([complete], [old]) == ([complete], 0)


def test_excel_multiline_merged_cell_is_not_clipped_by_one_line_height():
    from studio.output.excel import style

    wb = openpyxl.Workbook()
    ws = wb.active
    ws["A1"] = "Szállító\nCégnév\nBudapest"
    ws.merge_cells("A1:B1")
    style(ws)
    assert ws.row_dimensions[1].height >= 46 and len(ws.merged_cells.ranges) == 1


@pytest.mark.skipif(__import__("os").environ.get("RUN_OCR_TESTS") != "1", reason="real OCR opt-in")
def test_long_scan_word_boxes_are_not_mapped_back_twice():
    from PIL import ImageDraw, ImageFont
    from studio.engines.neural import recognize
    from studio.router import capabilities

    if not capabilities()["paddle"]["available"]:
        pytest.skip("Local neural models unavailable")
    image = Image.new("RGB", (1400, 6000), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype("LiberationSans-Regular.ttf", 45)
    for y in (100, 1900, 3800, 5700):
        draw.text((100, y), "DOCUMENT TEST AMOUNT 347.25", font=font, fill="black")
    words, diagnostics, _ = recognize(image, Page(1, 336, 1440))
    hits = [w for w in words if w.text == "DOCUMENT"]
    assert len(hits) == 4
    assert all(0 <= w.bbox[1] < w.bbox[3] <= 1440 for w in hits)
    assert all(w.origin[1] >= w.bbox[1] for w in hits)
    expected = [y * 1440 / 6000 for y in (100, 1900, 3800, 5700)]
    assert all(abs(w.bbox[1] - y) < 20 for w, y in zip(hits, expected))
    assert diagnostics["coordinate_mapping"].endswith("single inverse transform")


def test_condensed_receipt_keeps_ink_height_and_separates_neighboring_lines():
    from studio.engines.typography import refine_condensed_lines
    from reconstructor.ocr import pilfont

    words = [
        Word(
            str(i),
            "PRODUCT ITEM",
            (10, 20 + i * 12, 52, 30 + i * 12),
            (10, 25 + i * 12),
            6,
            font="Liberation Mono",
            confidence=0.99,
            line_hint=f"line-{i}",
        )
        for i in range(10)
    ]
    assert refine_condensed_lines(words)["applied"]
    font = pilfont("mono", False)
    top, bottom = font.getbbox("PRODUCT ITEM", anchor="ls")[1::2]
    rendered = [
        (w.origin[1] + top / 100 * w.size, w.origin[1] + bottom / 100 * w.size) for w in words
    ]
    assert all(8 < b - a < 10.1 for a, b in rendered)
    assert all(a[1] < b[0] for a, b in zip(rendered, rendered[1:]))
    assert all(w.render_scale < 0.8 for w in words)


def test_normal_monospace_lines_are_not_condensed_by_typography_refinement():
    from studio.engines.typography import refine_condensed_lines

    words = [
        Word(
            str(i),
            "PRODUCT ITEM",
            (10, i * 20, 90, i * 20 + 9),
            (10, i * 20 + 9),
            12,
            font="Liberation Mono",
            line_hint=str(i),
        )
        for i in range(10)
    ]
    assert not refine_condensed_lines(words)["applied"]
    assert all(w.size == 12 for w in words)
