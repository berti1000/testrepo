"""Provider contract tested without sending documents to an external service."""

import io
import json
import httpx
import pytest
from PIL import Image
from reconstructor.ai import review_page
from reconstructor.model import Page, Word


def test_ai_validates_ids_flags_numeric_changes_and_never_edits(monkeypatch):
    monkeypatch.setenv("AI_ENABLED", "1")
    monkeypatch.setenv("AI_BASE_URL", "http://local-model.test/v1")
    monkeypatch.setenv("AI_MODEL", "vision-test")
    page = Page(
        1,
        500,
        700,
        words=[
            Word("w1", "szoveg", (10, 10, 50, 20), (10, 20), 10),
            Word("w2", "00123", (60, 10, 95, 20), (60, 20), 10),
        ],
    )
    real_client = httpx.Client

    def handler(request):
        body = json.loads(request.content)
        assert request.url.path == "/v1/chat/completions"
        assert body["messages"][1]["content"][1]["image_url"]["url"].startswith(
            "data:image/jpeg;base64,"
        )
        payload = {
            "corrections": [
                {"word_id": "w1", "text": "szöveg", "reason": "Ékezet"},
                {"word_id": "w2", "text": "00128", "reason": "Bizonytalan szám"},
                {"word_id": "unknown", "text": "invented", "reason": "Invalid"},
            ],
            "tables": [
                {
                    "bbox": [-10, 0, 300, 100],
                    "x_edges": [100],
                    "y_edges": [50],
                    "reason": "Out of bounds",
                }
            ],
        }
        return httpx.Response(
            200, json={"choices": [{"message": {"content": json.dumps(payload)}}]}
        )

    monkeypatch.setattr(
        "reconstructor.ai.httpx.Client",
        lambda **kw: real_client(transport=httpx.MockTransport(handler), **kw),
    )
    image = io.BytesIO()
    Image.new("RGB", (500, 700), "white").save(image, format="PNG")
    result = review_page(page, image.getvalue())
    assert len(result["corrections"]) == 2
    assert result["corrections"][1]["numeric"] is True
    assert not result["tables"]
    assert page.words[0].text == "szoveg"


def test_ai_disabled_by_default(monkeypatch):
    monkeypatch.delenv("AI_ENABLED", raising=False)
    with pytest.raises(ValueError, match="not configured"):
        review_page(Page(1, 500, 700), b"")
