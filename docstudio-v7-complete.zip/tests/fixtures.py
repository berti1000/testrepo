"""Synthetic fixtures, NOT user invoices or external benchmark data."""

import fitz
from reconstructor.render import font_path


def make_invoice(ruled=True, rows=12, merged=True):
    pdf = fitz.open()
    p = pdf.new_page(width=595, height=842)
    p.insert_font(fontname="Reg", fontfile=font_path())
    p.insert_font(fontname="Bold", fontfile=font_path(bold=True))
    p.insert_font(fontname="Italic", fontfile=font_path(italic=True))
    font = fitz.Font(fontfile=font_path())

    def text(x, y, value, size=9, bold=False, italic=False, right=False):
        if right:
            x -= font.text_length(value, fontsize=size)
        p.insert_text(
            (x, y), value, fontname="Bold" if bold else "Italic" if italic else "Reg", fontsize=size
        )

    text(36, 45, "DEMO DOCUMENT / TEST FIXTURE", 18, True)
    text(
        36,
        66,
        "Arv"
        + chr(237)
        + "zt"
        + chr(369)
        + "r"
        + chr(337)
        + " t"
        + chr(252)
        + "k"
        + chr(246)
        + "rf"
        + chr(250)
        + "r"
        + chr(243)
        + "g"
        + chr(233)
        + "p",
        10,
    )
    text(36, 96, "Supplier: Example Company", 10)
    text(355, 96, "Number: 00012345", 10)
    text(36, 112, "Customer: Test Company", 10)
    text(355, 112, "Date: 2026-09-10", 10)
    xs = [36, 300, 380, 470, 559]
    ys = [155 + i * 21 for i in range(rows + 2)]
    if ruled:
        p.draw_rect((36, ys[0], 559, ys[1]), color=None, fill=(0.9, 0.94, 0.97))
        for x in xs:
            p.draw_line((x, ys[0]), (x, ys[-1]), color=(0.15, 0.2, 0.25), width=0.6)
        for y in ys:
            p.draw_line((36, y), (559, y), color=(0.15, 0.2, 0.25), width=0.6)
    text(40, 169, "Description", 9, True)
    text(312, 169, "Quantity", 9, True)
    text(393, 169, "Credit", 9, True)
    text(482, 169, "Amount", 9, True)
    for i in range(rows):
        y = 190 + i * 21
        text(
            40,
            y,
            f"Product {i + 1:02d} - "
            + chr(337)
            + "r"
            + chr(246)
            + "lt k"
            + chr(225)
            + "v"
            + chr(233),
            9,
        )
        text(367, y, str(i + 1), 9, right=True)
        if i in (2, 5):
            text(457, y, "347.25", 9, right=True)
        text(549, y, f"{(i + 1) * 10.12:.2f}", 9, right=True)
    text(36, ys[-1] + 35, "Payment details are shown below.", 9)
    text(36, ys[-1] + 48, "This is synthetic test data, not an actual invoice.", 9, italic=True)
    text(36, ys[-1] + 75, '=HYPERLINK("https://example.invalid")', 9)
    p.draw_bezier(
        (400, ys[-1] + 70),
        (425, ys[-1] + 45),
        (480, ys[-1] + 95),
        (530, ys[-1] + 70),
        color=(0.2, 0.4, 0.7),
        width=1.2,
    )
    if merged:
        # A separate genuine 2-column, merged-header table with unrelated boundaries.
        start = ys[-1] + 102
        for y in [start, start + 20, start + 42, start + 64]:
            p.draw_line((36, y), (290, y), width=0.5)
        for x in [36, 290]:
            p.draw_line((x, start), (x, start + 64), width=0.5)
        p.draw_line((163, start + 20), (163, start + 64), width=0.5)
        text(43, start + 14, "SECOND TABLE - MERGED HEADER", 9, True)
        text(43, start + 35, "First item", 9)
        text(279, start + 35, "12.34", 9, right=True)
        text(43, start + 57, "Second item", 9)
        text(279, start + 57, "56.78", 9, right=True)
    result = pdf.tobytes()
    pdf.close()
    return result


def make_mixed_fonts():
    pdf = fitz.open()
    p = pdf.new_page()
    p.insert_font(fontname="Reg", fontfile=font_path())
    p.insert_font(fontname="Bold", fontfile=font_path(bold=True))
    p.insert_font(fontname="Italic", fontfile=font_path(italic=True))
    p.insert_text((30, 60), "SMALL", fontname="Reg", fontsize=8)
    p.insert_text((100, 60), "LARGE", fontname="Reg", fontsize=18)
    p.insert_text((210, 60), "ITALIC", fontname="Italic", fontsize=10)
    p.insert_text((285, 60), "BOLD", fontname="Bold", fontsize=10)
    p.insert_text((350, 60), "x", fontname="Reg", fontsize=10)
    p.insert_text((356, 55), "2", fontname="Reg", fontsize=6)
    return pdf.tobytes()


def make_ocr_image():
    pdf = fitz.open()
    p = pdf.new_page(width=450, height=300)
    p.insert_font(fontname="Reg", fontfile=font_path())
    lines = [
        "INVOICE TEST 2026",
        "Amount 347.25 EUR",
        "Reference 0012345678",
        "Arv"
        + chr(237)
        + "zt"
        + chr(369)
        + "r"
        + chr(337)
        + " t"
        + chr(252)
        + "k"
        + chr(246)
        + "rf"
        + chr(250)
        + "r"
        + chr(243)
        + "g"
        + chr(233)
        + "p",
    ]
    for i, t in enumerate(lines):
        p.insert_text((25, 50 + i * 48), t, fontname="Reg", fontsize=16)
    image = p.get_pixmap(dpi=300, alpha=False).tobytes("png")
    pdf.close()
    return image
