"""Integration regressions: real Tesseract, geometry and lossless source fidelity."""

import io
import os
import hashlib

import fitz
import numpy as np
import pytest
from PIL import Image, ImageDraw

from reconstructor.extract import read_document
from reconstructor.model import Options
from reconstructor.persistence import load, save
from reconstructor.preprocess import flatten, perspective
from reconstructor.render import preserved_pdf, reconstructed_pdf, searchable_pdf
from tests.fixtures import make_invoice, make_ocr_image

real_ocr = pytest.mark.skipif(
    os.getenv("RUN_OCR_TESTS") != "1", reason="Set RUN_OCR_TESTS=1 for real Tesseract"
)


def png(image):
    stream = io.BytesIO()
    image.save(stream, format="PNG", dpi=(300, 300))
    return stream.getvalue()


def test_original_pdf_bytes_and_edits_are_separate():
    source = make_invoice(rows=3, merged=False)
    doc = read_document(source, "invoice.pdf", Options(ocr="never"))
    word = doc.pages[0].words[0]
    word.original_text = word.text
    word.text = "CORRECTED"
    assert hashlib.sha256(preserved_pdf(doc)).digest() == hashlib.sha256(source).digest()
    for output in (reconstructed_pdf(doc), searchable_pdf(doc)):
        with fitz.open(stream=output, filetype="pdf") as pdf:
            assert "CORRECTED" in pdf[0].get_text()


def test_lossless_rgb_image_pixels_and_transparency():
    source = Image.new("RGBA", (120, 160), (255, 255, 255, 0))
    ImageDraw.Draw(source).rectangle((5, 9, 90, 140), fill=(13, 67, 159, 255))
    doc = read_document(png(source), "test.png", Options(ocr="never"))
    with fitz.open(stream=preserved_pdf(doc), filetype="pdf") as pdf:
        xref = pdf[0].get_images()[0][0]
        extracted = Image.open(io.BytesIO(pdf.extract_image(xref)["image"])).convert("RGB")
    assert np.array_equal(np.array(extracted), np.array(flatten(source)))


def test_snapshot_roundtrip_keeps_edit_history_and_exports(tmp_path):
    doc = read_document(make_invoice(rows=3), "sample.pdf", Options(ocr="never"))
    word = doc.pages[0].words[0]
    word.original_text, word.text, word.reviewed = word.text, "Reviewed", True
    doc.edits.append({"id": word.id, "after": word.text})
    path = tmp_path / "snapshot.json.gz"
    save(doc, path)
    restored = load(path)
    assert restored.to_json() == doc.to_json()
    assert preserved_pdf(restored) == preserved_pdf(doc)
    with fitz.open(stream=reconstructed_pdf(restored), filetype="pdf") as pdf:
        assert "Reviewed" in pdf[0].get_text()


def test_uncertain_crop_is_replaced_by_real_letters_after_review():
    from reconstructor.extract import preserve_uncertain_fragments
    from reconstructor.model import Document, Page, Word

    word = Word(
        "w1",
        "WRONG",
        (10, 10, 70, 25),
        (10, 23),
        12,
        source="ocr",
        confidence=0.92,
        alternatives=["SOURCE"],
    )
    page = Page(1, 200, 100, words=[word])
    source = Image.new("RGB", (400, 200), "white")
    ImageDraw.Draw(source).rectangle((20, 20, 140, 50), fill="black")
    preserve_uncertain_fragments(source, page)
    document = Document("test", "", b"", pages=[page])
    assert word.needs_review
    with fitz.open(stream=reconstructed_pdf(document), filetype="pdf") as pdf:
        assert "WRONG" not in pdf[0].get_text()
        assert pdf[0].get_images()
    word.original_text = word.text
    word.text = "REVIEWED"
    word.reviewed = True
    with fitz.open(stream=reconstructed_pdf(document), filetype="pdf") as pdf:
        assert "REVIEWED" in pdf[0].get_text()
        assert not pdf[0].get_images()


def test_dust_expanded_ocr_box_cannot_make_a_giant_word():
    from reconstructor.model import Word
    from reconstructor.ocr import fit_fonts
    from reconstructor.render import font_path
    from PIL import ImageFont

    image = Image.new("RGB", (1000, 240), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.truetype(font_path(), 30)
    words = []
    x = 20
    for i, text in enumerate(["Ellenőrzött", "normális", "betűméret", "szöveg"]):
        bbox = draw.textbbox((x, 100), text, font=font, anchor="ls")
        draw.text((x, 100), text, font=font, fill="black", anchor="ls")
        if i == 2:
            bbox = (bbox[0], bbox[1] - 30, bbox[2], bbox[3] + 40)
        words.append(
            Word(str(i), text, bbox, (x, 100), 30, source="ocr", confidence=0.96, line_hint="same")
        )
        x += round(font.getlength(text)) + 15
    fit_fonts(image, words, 1000, 240)
    assert max(w.size for w in words) / min(w.size for w in words) < 1.25
    assert max(w.origin[1] for w in words) - min(w.origin[1] for w in words) < 3


def test_alternative_reading_requires_review_even_with_high_confidence():
    from reconstructor.model import Word

    word = Word("a", "2790", (1, 1, 50, 20), (1, 18), 12, confidence=0.98, alternatives=["27%"])
    assert word.needs_review
    word.reviewed = True
    assert not word.needs_review


def test_dotted_rule_artifacts_are_retained_for_review_but_not_painted_as_words():
    from reconstructor.model import Word
    from reconstructor.ocr import flag_rule_artifacts

    words = [
        Word("rule", "I", (10, 30, 490, 31), (10, 31), 2, confidence=0.1, line_hint="rule"),
        Word("noise", "mm", (350, 29, 400, 34), (350, 34), 9, confidence=0.2, line_hint="rule"),
        Word(
            "number",
            "0012345678",
            (30, 50, 95, 60),
            (30, 60),
            12,
            confidence=0.95,
            line_hint="text",
        ),
    ]
    assert flag_rule_artifacts(words, 500) == 2
    assert words[0].text == "I" and words[0].needs_review
    assert not words[2].visual_artifact


def test_perspective_preserves_a_document_without_page_border():
    image = Image.new("RGB", (900, 1200), "white")
    draw = ImageDraw.Draw(image)
    draw.rectangle((70, 90, 820, 1000), outline="black", width=4)
    corrected, matrix = perspective(image)
    assert matrix is None  # A printed table border is not the edge of the paper.
    assert np.array_equal(np.array(image), np.array(corrected))


@real_ocr
@pytest.mark.parametrize("rotation", [0, 90, 180, 270])
def test_real_ocr_rotations_and_visible_unicode(rotation):
    source = Image.open(io.BytesIO(make_ocr_image())).convert("RGB")
    source = source.rotate(rotation, expand=True, fillcolor="white")
    data = png(source)
    doc = read_document(data, "scan.png", Options(quality="fast", deskew=False))
    text = " ".join(w.text for w in doc.pages[0].words)
    assert "347.25" in text and "0012345678" in text
    assert "tükörfúrógép" in text
    assert doc.pages[0].width > doc.pages[0].height
    with fitz.open(stream=reconstructed_pdf(doc), filetype="pdf") as pdf:
        assert "tükörfúrógép" in pdf[0].get_text()
        assert any(s["type"] == 0 for s in pdf[0].get_texttrace())  # Real visible glyphs.
    with fitz.open(stream=preserved_pdf(doc), filetype="pdf") as pdf:
        embedded = Image.open(
            io.BytesIO(pdf.extract_image(pdf[0].get_images()[0][0])["image"])
        ).convert("RGB")
        assert np.array_equal(np.array(source), np.array(embedded))


@real_ocr
def test_native_header_does_not_hide_image_scan():
    with fitz.open() as pdf:
        page = pdf.new_page(width=450, height=330)
        page.insert_text((20, 20), "Page 1")
        page.insert_image(fitz.Rect(0, 30, 450, 330), stream=make_ocr_image())
        data = pdf.tobytes()
    doc = read_document(
        data, "header-plus-scan.pdf", Options(quality="fast", orientation=False, deskew=False)
    )
    assert doc.pages[0].ocr_ran
    assert any("0012345678" in w.text for w in doc.pages[0].words)


def test_digital_text_with_photo_stays_native():
    with fitz.open() as pdf:
        page = pdf.new_page()
        page.insert_text((20, 30), "Digital text should stay digital. " * 4, fontsize=7)
        page.insert_image(
            fitz.Rect(20, 90, 260, 400), stream=png(Image.new("RGB", (240, 310), "#876456"))
        )
        data = pdf.tobytes()
    doc = read_document(data, "digital.pdf", Options())
    assert not doc.pages[0].ocr_ran
    assert all(w.source == "native" for w in doc.pages[0].words)


@real_ocr
def test_blank_scan_faithful_export_remains_available():
    data = png(Image.new("RGB", (650, 950), "white"))
    doc = read_document(data, "blank.png", Options(orientation=False, quality="fast"))
    assert not doc.pages[0].words
    assert any("Nem találtam olvasható" in w for w in doc.pages[0].warnings)
    assert preserved_pdf(doc).startswith(b"%PDF")


@real_ocr
def test_missing_language_has_explicit_error():
    with pytest.raises(RuntimeError, match="Hiányzó OCR nyelvi modell"):
        read_document(
            make_ocr_image(), "scan.png", Options(languages="missinglang", orientation=False)
        )
