import io
import json
import os
import zipfile
from copy import deepcopy

import fitz
import numpy as np
import openpyxl
import pytest
from PIL import Image

from reconstructor.extract import DocumentError, read_document
from reconstructor.export import (
    all_exports,
    excel,
    number_value,
    plain_text,
    table_matrix,
    word_document,
)
from reconstructor.geometry import normalize_ocr_lines
from reconstructor.layout import audit_page, manual_table, safe_merge_rare_tracks
from reconstructor.model import Options, Word
from reconstructor.render import page_png, page_svg, preserved_pdf, reconstructed_pdf
from tests.fixtures import make_invoice, make_mixed_fonts, make_ocr_image


@pytest.fixture(scope="module")
def ruled():
    return read_document(make_invoice(True), "fixture.pdf", Options(ocr="never"))


@pytest.fixture(scope="module")
def unruled():
    return read_document(make_invoice(False), "fixture.pdf", Options(ocr="never"))


def first_table(doc):
    return next(b for b in doc.pages[0].blocks if b.kind == "table")


def test_font_sizes_not_bbox_heights():
    doc = read_document(make_mixed_fonts(), "mixed.pdf", Options(ocr="never"))
    words = {w.text: w for w in doc.pages[0].words}
    assert words["SMALL"].size == 8
    assert words["LARGE"].size == 18
    assert not words["LARGE"].bold
    assert words["ITALIC"].italic
    assert words["BOLD"].bold
    assert words["SMALL"].origin[1] == words["LARGE"].origin[1] == 60
    assert words["2"].origin[1] == 55
    assert words["2"].size == 6


def test_hungarian_glyphs(ruled):
    text = plain_text(ruled).decode("utf-8")
    for ch in [chr(237), chr(369), chr(337), chr(252), chr(246), chr(250), chr(243), chr(233)]:
        assert ch in text
    line = [w for w in ruled.pages[0].words if abs(w.origin[1] - 66) < 0.01]
    assert len({w.size for w in line}) == 1


def test_normalization_protects_native():
    words = [
        Word("a", "A", (0, 0, 10, 10), (0, 10), 18),
        Word("b", "B", (11, 0, 15, 10), (11, 10), 8),
    ]
    before = deepcopy(words)
    normalize_ocr_lines(words)
    assert words == before


def test_ruled_local_tables_and_merge(ruled):
    tables = [b for b in ruled.pages[0].blocks if b.kind == "table"]
    assert [len(b.x_edges) - 1 for b in tables] == [4, 2]
    assert any(c.colspan == 2 for c in tables[1].cells)


def test_header_alignment_does_not_create_column(unruled):
    t = first_table(unruled)
    assert len(t.x_edges) - 1 == 4
    matrix = table_matrix(t, unruled.pages[0])
    assert matrix[0] == ["Description", "Quantity", "Credit", "Amount"]
    assert matrix[1][3] == "10.12"
    assert matrix[3][2] == matrix[6][2] == "347.25"


def test_sparse_two_row_numeric_track_never_merged():
    a = [
        dict(ids=["a"], box=(100, 0, 130, 10), row=1, numeric=True),
        dict(ids=["b"], box=(100, 12, 130, 22), row=2, numeric=True),
    ]
    b = [dict(ids=["c"], box=(110, 24, 140, 34), row=3, numeric=True)]
    assert len(safe_merge_rare_tracks([a, b], 30)) == 2


def test_singleton_number_never_deleted():
    tracks = [
        [dict(ids=["a"], box=(100, 0, 130, 10), row=1, numeric=True)],
        [dict(ids=["b"], box=(105, 12, 135, 22), row=2, numeric=True)],
    ]
    assert len(safe_merge_rare_tracks(tracks, 30)) == 2


def test_same_row_text_columns_not_merged():
    tracks = [
        [dict(ids=["a"], box=(100, 0, 150, 10), row=1, numeric=False)],
        [dict(ids=["b"], box=(105, 0, 140, 10), row=1, numeric=False)],
    ]
    assert len(safe_merge_rare_tracks(tracks, 30)) == 2


def test_genuine_header_duplicate_can_merge():
    tracks = [
        [dict(ids=["a"], box=(100, 0, 150, 10), row=0, numeric=False)],
        [
            dict(ids=["b"], box=(105, 12, 140, 22), row=1, numeric=True),
            dict(ids=["c"], box=(105, 24, 140, 34), row=2, numeric=True),
        ],
    ]
    assert len(safe_merge_rare_tracks(tracks, 30)) == 1


def test_all_words_exactly_one_structural_owner(ruled, unruled):
    for doc in [ruled, unruled]:
        result = audit_page(doc.pages[0])
        assert result["missing"] == result["duplicates"] == 0
        assert result["assigned"] == len(doc.pages[0].words)


def test_no_invented_borders_on_unruled_table(unruled):
    workbook = openpyxl.load_workbook(io.BytesIO(excel(unruled)))
    sheet = workbook["Tabla 1-1"]
    assert sheet.max_column == 4
    for row in sheet:
        for cell in row:
            assert all(
                getattr(cell.border, side).style is None if getattr(cell.border, side) else True
                for side in ["top", "bottom", "left", "right"]
            )


def test_compact_excel_and_merged_paragraphs(ruled):
    workbook = openpyxl.load_workbook(io.BytesIO(excel(ruled)))
    sheet = workbook["Elrendezes 1"]
    assert sheet.max_column <= 32
    assert sheet.max_column * sheet.max_row < 8000
    assert sheet.max_row < 100
    assert len(sheet.merged_cells.ranges) > 0
    assert workbook["Tabla 1-1"].max_column == 4
    assert workbook["Tabla 1-2"].max_column == 2


def test_formula_injection_is_literal(ruled):
    workbook = openpyxl.load_workbook(io.BytesIO(excel(ruled)), data_only=False)
    found = []
    for sheet in workbook:
        for row in sheet:
            for cell in row:
                assert cell.data_type != "f"
                if isinstance(cell.value, str) and cell.value.startswith("=HYPERLINK"):
                    found.append(cell)
    assert found
    assert all(c.data_type == "s" for c in found)


def test_zeros_and_dates_stay_text(ruled):
    workbook = openpyxl.load_workbook(io.BytesIO(excel(ruled)))
    values = [str(c.value) for row in workbook["Elrendezes 1"] for c in row if c.value is not None]
    assert any("00012345" in s for s in values)
    assert any("2026-09-10" in s for s in values)
    assert workbook["Tabla 1-1"]["D2"].value == "10.12"


@pytest.mark.parametrize(
    "text,locale,expected",
    [
        ("347.25", "en", 347.25),
        ("1 234,50", "hu", 1234.5),
        ("1,234.50", "en", 1234.5),
        ("00123.45", "en", None),
        ("2026-09-10", "en", None),
        ("1234,50", "en", None),
        ("1234567890123456.78", "en", None),
        ("347.25", "text", None),
    ],
)
def test_explicit_numeric_conversion(text, locale, expected):
    assert number_value(text, locale) == expected


def test_xlsx_numeric_opt_in(ruled):
    workbook = openpyxl.load_workbook(io.BytesIO(excel(ruled, "en")))
    assert workbook["Tabla 1-1"]["D2"].value == 10.12
    assert workbook["Tabla 1-1"]["D2"].data_type == "n"


def test_vector_curve_and_searchable_text(ruled):
    with fitz.open(stream=reconstructed_pdf(ruled), filetype="pdf") as pdf:
        assert len(pdf) == 1
        assert "347.25" in pdf[0].get_text()
        assert any(item[0] == "c" for path in pdf[0].get_drawings() for item in path["items"])


def test_svg_does_not_require_external_fonts(ruled):
    svg = page_svg(ruled)
    assert "<path" in svg
    assert "font-family=" not in svg


def test_original_appearance_unchanged_without_ocr(ruled):
    a = Image.open(io.BytesIO(page_png(ruled, original=True)))
    with fitz.open(stream=preserved_pdf(ruled), filetype="pdf") as p:
        b = Image.open(io.BytesIO(p[0].get_pixmap(dpi=120, alpha=False).tobytes("png")))
    assert np.array_equal(np.array(a), np.array(b))


def test_reconstructed_fixture_visual_error_small(ruled):
    a = np.array(Image.open(io.BytesIO(page_png(ruled, original=True)))).astype(float)
    b = np.array(Image.open(io.BytesIO(page_png(ruled)))).astype(float)
    assert np.mean(np.abs(a - b)) < 2


@pytest.mark.parametrize("rotation", [90, 180, 270])
def test_rotation_uses_one_coordinate_frame(rotation):
    raw = make_invoice(merged=False, rows=4)
    with fitz.open(stream=raw, filetype="pdf") as d:
        d[0].set_rotation(rotation)
        changed = d.tobytes()
    doc = read_document(changed, "rotated.pdf", Options(ocr="never"))
    assert "347.25" in plain_text(doc).decode()
    assert doc.pages[0].width == (842 if rotation in [90, 270] else 595)
    assert reconstructed_pdf(doc).startswith(b"%PDF")


def test_cropbox_is_respected():
    with fitz.open(stream=make_invoice(rows=4, merged=False), filetype="pdf") as d:
        d[0].set_cropbox(fitz.Rect(20, 20, 580, 800))
        raw = d.tobytes()
    doc = read_document(raw, "cropped.pdf", Options(ocr="never"))
    assert doc.pages[0].width == 560
    original = np.array(Image.open(io.BytesIO(page_png(doc, original=True)))).astype(float)
    rebuilt = np.array(Image.open(io.BytesIO(page_png(doc)))).astype(float)
    assert np.mean(np.abs(original - rebuilt)) < 2


def test_empty_page_does_not_crash():
    pdf = fitz.open()
    pdf.new_page()
    raw = pdf.tobytes()
    pdf.close()
    doc = read_document(raw, "empty.pdf", Options(ocr="never"))
    assert not doc.pages[0].words
    assert reconstructed_pdf(doc).startswith(b"%PDF")
    assert excel(doc).startswith(b"PK")
    assert word_document(doc).startswith(b"PK")


def test_invalid_input_fails_clearly():
    with pytest.raises(DocumentError):
        read_document(b"not a document", "fake.pdf", Options(ocr="never"))


def test_file_limit_is_not_silent_truncation():
    with pytest.raises(DocumentError):
        read_document(b"a" * 200, "fake.pdf", Options(ocr="never", max_bytes=100))


def test_manual_table_validation_and_coverage(ruled):
    page = deepcopy(ruled.pages[0])
    t = first_table(ruled)
    with pytest.raises(ValueError):
        manual_table(page, (t.bbox[0], t.bbox[1], 400, t.bbox[3]), [200], [200, 250])
    manual_table(page, t.bbox, t.x_edges[1:-1], t.y_edges[1:-1])
    assert audit_page(page)["missing"] == 0


def test_docx_has_real_tables_and_merged_header(ruled):
    from docx import Document

    doc = Document(io.BytesIO(word_document(ruled)))
    assert len(doc.tables) == 2
    assert len(doc.tables[0].columns) == 4
    assert len(doc.tables[1].columns) == 2
    assert "gridSpan" in doc.tables[1]._tbl.xml


def test_json_is_serializable_and_contains_provenance(ruled):
    model = json.loads(ruled.to_json())
    assert model["source_sha256"] == ruled.sha256
    assert model["pages"][0]["words"][0]["source"] == "native"
    assert "source_pdf" not in model


def test_full_export_bundle(ruled):
    with zipfile.ZipFile(io.BytesIO(all_exports(ruled))) as z:
        assert len(z.namelist()) == 10
        assert z.read("02_reconstructed.pdf").startswith(b"%PDF")
        assert z.read("03_editable.xlsx").startswith(b"PK")
        assert z.read("04_editable.docx").startswith(b"PK")
        assert z.read("08_tables_csv.zip").startswith(b"PK")


@pytest.mark.skipif(
    os.environ.get("RUN_OCR_TESTS") != "1",
    reason="Opt-in real OCR smoke test; run with RUN_OCR_TESTS=1.",
)
def test_real_ocr_hungarian_english():
    doc = read_document(
        make_ocr_image(), "scan.png", Options(languages="hun+eng", psm=6, deskew=False)
    )
    text = plain_text(doc).decode("utf-8")
    assert doc.pages[0].ocr_ran
    assert "347.25" in text and "0012345678" in text
    assert chr(337) in text and chr(369) in text
    from reconstructor.render import searchable_pdf

    with fitz.open(stream=searchable_pdf(doc), filetype="pdf") as pdf:
        assert "347.25" in pdf[0].get_text()


def test_svg_ids_are_namespaced_for_multipage_html(ruled):
    from reconstructor.render import standalone_html

    doc = deepcopy(ruled)
    second = deepcopy(doc.pages[0])
    second.number = 2
    doc.pages.append(second)
    output = standalone_html(doc).decode()
    assert 'id="p1_' in output and 'id="p2_' in output


def test_scan_graphic_layer_not_over_editable_cells(ruled):
    from reconstructor.extract import scan_graphics_layer

    doc = deepcopy(ruled)
    source = Image.open(io.BytesIO(page_png(doc, original=True)))
    scan_graphics_layer(source, doc.pages[0])
    assert any(im.get("background") and im.get("data") for im in doc.pages[0].images)
    assert reconstructed_pdf(doc).startswith(b"%PDF")
    book = openpyxl.load_workbook(io.BytesIO(excel(doc)))
    assert not book["Elrendezes 1"]._images


def test_native_image_separated_from_overlapping_text():
    from reconstructor.render import font_path

    im = Image.new("RGB", (80, 60), (220, 230, 240))
    stream = io.BytesIO()
    im.save(stream, format="PNG")
    p = fitz.open()
    page = p.new_page(width=300, height=400)
    page.insert_image((30, 40, 110, 100), stream=stream.getvalue())
    page.insert_font(fontname="Reg", fontfile=font_path())
    page.insert_text((40, 70), "OVER", fontname="Reg", fontsize=10)
    doc = read_document(p.tobytes(), "image.pdf", Options(ocr="never"))
    assert len(doc.pages[0].images) == 1
    patch = Image.open(io.BytesIO(doc.pages[0].images[0]["data"])).convert("RGB")
    assert np.min(np.array(patch)) >= 215  # black text was not baked into the image crop
    assert reconstructed_pdf(doc).startswith(b"%PDF")


def test_wrapped_table_description_joins_logical_cell():
    from reconstructor.render import font_path

    p = fitz.open()
    page = p.new_page()
    page.insert_font(fontname="Reg", fontfile=font_path())
    for x, y, t in [
        (35, 40, "Description"),
        (300, 40, "Amount"),
        (35, 65, "First product"),
        (300, 65, "10.12"),
        (35, 74, "continued text"),
        (35, 100, "Second product"),
        (300, 100, "20.24"),
        (35, 125, "Third product"),
        (300, 125, "30.36"),
    ]:
        page.insert_text((x, y), t, fontname="Reg", fontsize=9)
    doc = read_document(p.tobytes(), "wrapped.pdf", Options(ocr="never"))
    table = first_table(doc)
    assert len(table.y_edges) - 1 == 4
    matrix = table_matrix(table, doc.pages[0])
    assert "continued text" in matrix[1][0]
    assert "10.12" in matrix[1][1]


def test_unruled_title_merge_encloses_actual_width(unruled):
    from reconstructor.export import _page_edges

    wb = openpyxl.load_workbook(io.BytesIO(excel(unruled)))
    ws = wb["Elrendezes 1"]
    edges = _page_edges(unruled.pages[0])
    title = unruled.pages[0].blocks[0]
    found = next(c for row in ws for c in row if c.value and "DEMO DOCUMENT" in str(c.value))
    merged = next(m for m in ws.merged_cells.ranges if found.coordinate in m)
    assert edges[merged.max_col] >= title.bbox[2] - 0.1


def test_xlsx_preserves_mixed_runs(ruled):
    wb = openpyxl.load_workbook(io.BytesIO(excel(ruled)), rich_text=True)
    from openpyxl.cell.rich_text import CellRichText, TextBlock

    rich = [c.value for row in wb["Elrendezes 1"] for c in row if isinstance(c.value, CellRichText)]
    assert rich
    assert any(
        len({bool(r.font.i) for r in value if isinstance(r, TextBlock)}) == 2 for value in rich
    )


def test_searchable_scan_graphics_survive_without_new_ocr():
    from reconstructor.render import font_path

    image = Image.new("RGB", (300, 400), (230, 235, 240))
    data = io.BytesIO()
    image.save(data, format="PNG")
    pdf = fitz.open()
    p = pdf.new_page(width=300, height=400)
    p.insert_image(p.rect, stream=data.getvalue())
    p.insert_font(fontname="Reg", fontfile=font_path())
    p.insert_text((25, 45), "Already searchable native text layer", fontname="Reg", fontsize=10)
    doc = read_document(pdf.tobytes(), "searchable_scan.pdf", Options(ocr="never"))
    assert not doc.pages[0].ocr_ran
    assert any(im.get("background") and im.get("data") for im in doc.pages[0].images)
