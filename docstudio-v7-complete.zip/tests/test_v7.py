"""Regressions from source curves, MS Excel clipping, and inline font editing."""

import io
import zipfile
import numpy as np
import openpyxl
import pytest
from PIL import Image, ImageDraw
from pydantic import ValidationError
from reconstructor.model import Page, Word, Document
from reconstructor.graphics import preserve_graphics
from reconstructor.render import word_scale, font_for
from studio.output import excel
from studio.output.sheet_geometry import bands
from tests.test_v6 import synthetic_page
from tests.test_studio import loaded
from studio.store import Store
from web.routes.studio_api import Edit


def test_graphics_keeps_curves_dots_signature_pixels_and_removes_text():
    image = Image.new("RGB", (800, 500), "white")
    d = ImageDraw.Draw(image)
    d.rounded_rectangle((40, 30, 750, 120), radius=20, outline="black", width=1)
    for x in range(40, 730, 9):
        d.ellipse((x, 180, x + 1, 181), fill="black")
    d.line(
        [(450, 400), (452, 330), (460, 405), (520, 398), (540, 350), (540, 400), (650, 403)],
        fill="blue",
        width=2,
    )
    d.text((70, 70), "EDITABLE", fill="black")
    p = Page(
        1,
        800,
        500,
        words=[Word("w", "EDITABLE", (68, 68, 130, 84), (68, 82), 12, confidence=0.99)],
        paths=[dict(source="raster", items=[]), dict(source="native", items=[])],
    )
    preserve_graphics(image, p)
    result = np.asarray(Image.open(io.BytesIO(p.images[0]["data"])))
    original = np.asarray(image)
    assert np.array_equal(result[150:210], original[150:210])
    assert np.array_equal(result[300:450], original[300:450])
    assert np.array_equal(result[25:65], original[25:65])
    assert np.mean(result[68:84, 68:130]) > np.mean(original[68:84, 68:130])
    assert [v["source"] for v in p.paths] == ["native"]


def test_neural_shared_scale_cannot_overflow_its_word_box():
    from reportlab.pdfbase import pdfmetrics

    w = Word("w", "Sorszám:", (10, 10, 40, 25), (10, 24), 14, render_scale=1.8)
    width = pdfmetrics.stringWidth(w.text, font_for(w), w.size) * word_scale(w, font_for(w))
    assert width <= 30.001


def test_detector_line_mask_removes_trailing_source_glyph_without_touching_signature():
    image = Image.new("RGB", (220, 100), "white")
    d = ImageDraw.Draw(image)
    d.text((10, 15), "ORIGINAL", fill="black")
    d.line([(120, 70), (125, 55), (140, 75), (180, 65)], fill="blue", width=2)
    p = Page(
        1, 220, 100,
        words=[Word("w", "ORIGINAL", (10, 15, 32, 30), (10, 28), 12, line_hint="n1")],
        diagnostics={"text_line_regions": [{"line_hint": "n1", "bbox": [10, 15, 65, 30]}]},
    )
    preserve_graphics(image, p)
    result = np.asarray(Image.open(io.BytesIO(p.images[0]["data"])))
    assert result[14:32, 9:66].min() == 255
    assert np.array_equal(result[50:90], np.asarray(image)[50:90])


def test_adjacent_baselines_are_not_collapsed_by_font_ascenders():
    assert len(bands([{"box": (0, 20, 100, 39)}, {"box": (180, 38, 290, 60)}])) == 2


def test_crowded_receipt_fragments_cannot_escape_last_spreadsheet_column():
    from studio.output.sheet_geometry import ranges, grow

    items = [
        dict(box=(x, 0, x + 10, 20), raw=str(x), words=[], table=False)
        for x in (70, 73, 76, 79, 82, 85, 88, 91, 94)
    ]
    xs = [0, 40, 80, 110]
    ranges(items, xs, [[0, 20]])
    widths = [40, 40, 30]
    grow(items, widths, [20])
    assert all(0 <= p["cols"][0] < p["cols"][1] <= len(widths) for p in items)


@pytest.mark.parametrize("mode", ["layout", "semantic"])
@pytest.mark.parametrize("compact", [True, False])
def test_no_comments_or_shrink_to_fit_anywhere(mode, compact):
    data = excel.export(
        Document("test", "", b"", pages=[synthetic_page()]), mode=mode, compact=compact
    )
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        assert not any("comment" in n.lower() or n.endswith(".vml") for n in z.namelist())
    wb = openpyxl.load_workbook(io.BytesIO(data), rich_text=True)
    for ws in wb:
        assert all(d.height >= 18 for d in ws.row_dimensions.values())
        assert all(c.comment is None and not c.alignment.shrinkToFit for row in ws for c in row)
        assert ws.page_setup.fitToHeight == 0


def test_long_number_column_expands_without_hashes():
    p = synthetic_page()
    p.words[-1].text = "123,456,789.99"
    p.words[-1].size = 18
    data = excel.export(Document("number", "", b"", pages=[p]))
    ws = openpyxl.load_workbook(io.BytesIO(data)).active
    assert any(c.value == 123456789.99 for row in ws for c in row)
    assert max(d.width for d in ws.column_dimensions.values()) > 20


@pytest.mark.parametrize(
    "bad", [{"size": 0}, {"size": float("nan")}, {"size": 121}, {"font": "<script>"}]
)
def test_style_api_rejects_invalid_values(bad):
    with pytest.raises(ValidationError):
        Edit(version=1, page=1, word="w", text="x", **bad)


def test_style_revision_roundtrip_and_real_font_width(tmp_path):
    store = Store(tmp_path / "jobs")
    try:
        job = loaded(store)
        before = store.load_ir(job["id"]).dump()
        w = store.load_ir(job["id"]).pages[0].words[0]
        new = store.edit(
            job["id"],
            "owner",
            job["version"],
            1,
            w.id,
            "Árvíztűrő",
            size=18,
            bold=True,
            font="Times New Roman",
        )
        actual = store.load_ir(job["id"]).pages[0].words[0]
        assert (actual.size, actual.bold, actual.font) == (18, True, "Times New Roman")
        assert actual.render_scale == 1 and actual.bbox[2] > actual.bbox[0] + 40
        assert store.load_ir(job["id"], 1).dump() == before and new["revision"] == 2
    finally:
        store.executor.shutdown(wait=True)


@pytest.mark.parametrize("code", [200, 401, 403, 404, 500])
def test_vision_connection_reports_real_status_without_uploading_documents(monkeypatch, code):
    import httpx
    from studio.engines import vision_status as v

    monkeypatch.setenv("VISION_BASE_URL", "http://test.invalid/v1")
    monkeypatch.setenv("VISION_MODEL", "vision-test")
    requests = []

    def handle(r):
        requests.append(r)
        return httpx.Response(code, json={"data": [{"id": "vision-test"}]})

    client = httpx.Client(transport=httpx.MockTransport(handle))
    monkeypatch.setattr(v.httpx, "Client", lambda **k: client)
    result = v.connection_test()
    assert result["ok"] == (code == 200)
    assert requests[0].method == "GET" and not requests[0].content


def test_vision_missing_model_is_explained(monkeypatch):
    from studio.engines.vision_status import configuration

    monkeypatch.setenv("VISION_MODEL", "")
    assert "VISION_MODEL" in configuration()["setup"]


def test_yarn_fix_preserves_other_repositories_and_is_idempotent():
    from scripts.repair_yarn_repo import repair

    text = "deb https://dl.yarnpkg.com/debian stable main\ndeb https://deb.debian.org/debian bookworm main\n"
    updated = repair(text)
    assert "\ndeb https://deb.debian.org/debian bookworm main\n" in updated
    assert not updated.startswith("deb https://dl.yarnpkg") and repair(updated) == updated
    deb822 = "Types: deb\nURIs: https://dl.yarnpkg.com/debian\nSuites: stable\nComponents: main\n\nTypes: deb\nURIs: https://deb.debian.org/debian\nSuites: bookworm\n"
    updated = repair(deb822, True)
    assert "Enabled: no" in updated.split("\n\n")[0]
    assert updated.split("\n\n")[1] == deb822.split("\n\n")[1]


def test_enlarged_word_moves_neighbors_and_fits_inside_page():
    from reconstructor.typography import reflow_edited_word

    a = Word("a", "EDITED", (10, 10, 140, 35), (10, 30), 22, line_hint="row")
    b = Word("b", "DOCUMENT", (60, 10, 150, 30), (60, 30), 14, line_hint="row")
    p = Page(1, 210, 300, words=[a, b])
    assert reflow_edited_word(p, a) == 1
    assert a.bbox[2] < b.bbox[0] and b.bbox[2] <= p.width


@pytest.mark.parametrize("margin,expected", [(0.02, "Liberation Sans"), (0.3, "Liberation Serif")])
def test_document_font_normalizes_only_ambiguous_scan_pages(margin, expected):
    from reconstructor.typography import unify_document_fonts

    a = Page(
        1,
        500,
        500,
        ocr_ran=True,
        words=[
            Word("a", "LONG DOMINANT TEXT", (10, 10, 200, 30), (10, 25), 12, font="Liberation Sans")
        ],
    )
    b = Page(
        2,
        500,
        500,
        ocr_ran=True,
        words=[Word("b", "Short", (10, 10, 60, 30), (10, 25), 12, font="Liberation Serif")],
        diagnostics={
            "typography": {"font_family_approximation": "serif", "font_family_margin": margin}
        },
    )
    unify_document_fonts(Document("d", "", b"", pages=[a, b]))
    assert b.words[0].font == expected
