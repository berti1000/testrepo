"""End-to-end ASGI: ownership, upload rollback, exports, edits, persistence."""

import io
import time
import zipfile

import fitz
import pytest
from fastapi.testclient import TestClient

from tests.fixtures import make_invoice


@pytest.fixture
def web(tmp_path, monkeypatch):
    monkeypatch.setenv("APP_ENV", "development")
    monkeypatch.setenv("APP_SESSION_SECRET", "test-session-secret-" * 4)
    monkeypatch.setenv("JOB_DIR", str(tmp_path))
    monkeypatch.delenv("APP_ACCESS_PASSWORD", raising=False)
    monkeypatch.delenv("COOKIE_SECURE", raising=False)
    from web import jobs
    from web.main import app
    from web.routes.api import router as api_router

    if not any(getattr(r, "path", "") == "/api/jobs" for r in app.routes):
        app.include_router(api_router)

    monkeypatch.setattr(jobs, "ROOT", tmp_path)
    jobs.JOBS.clear()
    with TestClient(app) as client:
        client.get("/")
        yield client, jobs, app
    for job in list(jobs.JOBS.values()):
        deadline = time.monotonic() + 15
        while job.state in ("queued", "running") and time.monotonic() < deadline:
            time.sleep(0.02)
    jobs.JOBS.clear()


def upload_done(client):
    response = client.post(
        "/api/jobs",
        data={"ocr": "never"},
        files={"files": ("sample.pdf", make_invoice(rows=3, merged=False), "application/pdf")},
    )
    assert response.status_code == 200, response.text
    job = response.json()["jobs"][0]
    for _ in range(300):
        job = client.get("/api/jobs/" + job["id"]).json()
        if job["state"] not in ("queued", "running"):
            break
        time.sleep(0.03)
    assert job["state"] == "done", job
    return "/api/jobs/" + job["id"]


def test_web_edit_export_ownership_and_persistence(web):
    client, jobs, app = web
    base = upload_done(client)
    assert client.get("/api/jobs").json()["jobs"][0]["state"] == "done"
    page = client.get(base + "/pages").json()["pages"][0]
    assert page["words"] > 25
    for kind in ("source", "original", "reconstructed"):
        response = client.get(base + "/pages/1/preview/" + kind)
        assert response.status_code == 200 and response.content.startswith(b"\x89PNG")
    source_bytes = client.get(base + "/export/source-file").content
    original = client.get(base + "/export/original-pdf").content
    assert original == source_bytes
    word = client.get(base + "/pages/1/words").json()["words"][0]
    patch = base + "/pages/1/words/" + word["id"]
    assert (
        client.patch(
            patch, json={"text": "ÁRVÍZTŰRŐ", "expected_text": word["text"], "reviewed": True}
        ).status_code
        == 200
    )
    assert (
        client.patch(patch, json={"text": "STALE", "expected_text": word["text"]}).status_code
        == 409
    )
    for kind in jobs.FORMATS:
        response = client.get(base + "/export/" + kind)
        assert response.status_code == 200, (kind, response.text[:500])
        assert response.content
        if kind in ("reconstructed-pdf", "searchable-pdf"):
            with fitz.open(stream=response.content, filetype="pdf") as pdf:
                assert "ÁRVÍZTŰRŐ" in pdf[0].get_text()
        if kind == "all":
            with zipfile.ZipFile(io.BytesIO(response.content)) as z:
                assert z.testzip() is None and len(z.namelist()) == 10
    assert client.get(base + "/export/original-pdf").content == source_bytes
    with TestClient(app) as stranger:
        stranger.get("/")
        assert stranger.get(base).status_code == 404
        assert stranger.get(base + "/export/json").status_code == 404
    job_id = base.rsplit("/", 1)[-1]
    jobs.JOBS.clear()
    jobs.restore()
    assert client.get(base + "/pages/1/words").json()["words"][0]["text"] == "ÁRVÍZTŰRŐ"
    assert client.get(base).json()["revision"] == 1
    batch = client.post("/api/batch/download?numbers=text", json=[job_id])
    assert batch.status_code == 200
    with zipfile.ZipFile(io.BytesIO(batch.content)) as z:
        assert len(z.namelist()) == 1
    assert client.delete(base).status_code == 200
    assert client.get(base).status_code == 404


def test_batch_upload_rolls_back_if_one_file_is_invalid(web):
    client, jobs, _ = web
    response = client.post(
        "/api/jobs",
        files=[
            ("files", ("good.pdf", make_invoice(rows=2), "application/pdf")),
            ("files", ("bad.pdf", b"not a PDF", "application/pdf")),
        ],
    )
    assert response.status_code == 400
    assert not jobs.JOBS
    assert not list(jobs.ROOT.glob("*/input.*"))


def test_reject_foreign_origin_oversize_body_and_invalid_coordinates(web):
    client, _, _ = web
    assert (
        client.post(
            "/api/batch/download", json=[], headers={"Origin": "https://evil.invalid"}
        ).status_code
        == 403
    )
    assert client.post("/api/batch/download", content=b"x" * 270000).status_code == 413
    base = upload_done(client)
    result = client.post(
        base + "/pages/1/tables",
        json={"bbox": [20, 20, 200, 200], "x_edges": [220], "y_edges": [120]},
    )
    assert result.status_code == 422
    assert client.get(base).json()["revision"] == 0
    assert client.post(base + "/pages/1/ai-review", json={"consent": False}).status_code == 422


def test_restart_marks_interrupted_jobs_explicitly(web):
    _, jobs, _ = web
    folder = jobs.ROOT / ("a" * 32)
    folder.mkdir()
    source = folder / "input.pdf"
    source.write_bytes(make_invoice(rows=2))
    job = jobs.Job("a" * 32, "owner", "sample.pdf", source, state="running")
    jobs.persist(job)
    jobs.restore()
    assert jobs.JOBS[job.id].state == "failed"
    assert "újraindult" in jobs.JOBS[job.id].message


def test_public_pages_are_server_rendered_and_have_canonical_urls(web):
    client, _, _ = web
    for url in (
        "/",
        "/eszkozok/dokumentum-rekonstrukcio",
        "/eszkozok/pdf-excel",
        "/eszkozok/ocr-szoveg",
    ):
        response = client.get(url)
        assert response.status_code == 200
        assert "<h1>" in response.text and 'rel="canonical"' in response.text
        assert "Content-Security-Policy" in response.headers
    assert "Disallow: /api/" in client.get("/robots.txt").text
    assert "<urlset" in client.get("/sitemap.xml").text
