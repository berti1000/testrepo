"""Layout, artifact identity and financial-record regressions for v6.

Set DOCSTUDIO_SAMPLE_PDF to the supplied remittance PDF for the private fixture.
That document is deliberately not distributed with the source package.
"""

import io
import json
import os
import zipfile
from collections import Counter
from decimal import Decimal
from pathlib import Path

import openpyxl
import pytest

from reconstructor.model import Document, Page, Word
from reconstructor.geometry import text_of
from studio.ir import AssetStore, to_runtime
from studio.layout_grid import detect_tables
from studio.pipeline import ingest, retry_page
from studio.output import excel
from studio.output.excel_layout import decimal
from studio.output.service import OutputOptions, fallback, generate
from studio.router import Router
from tests.fixtures import make_invoice


def synthetic_page():
    words = []

    def add(text, x, y, bold=False):
        for i, line in enumerate(text.split("\n")):
            words.append(
                Word(
                    f"w{len(words)}",
                    line,
                    (x, y + i * 10, x + len(line) * 4, y + i * 10 + 10),
                    (x, y + i * 10 + 8),
                    8,
                    bold=bold,
                )
            )

    xs = [20, 110, 190, 280, 380]
    for x, v in zip(xs, ["Record\nID", "Empty\nfield", "Guest\nname", "Arrival", "Amount"]):
        add(v, x, 20, True)
    for i in range(4):
        for x, v in zip(
            xs, [f"00100{i}", "", f"Guest {i}\nFamily", "Jun 09,\n2026", f"{i + 1}.25"]
        ):
            if v:
                add(v, x, 60 + i * 34)
    return Page(1, 460, 250, words=words)


def test_wrapped_records_and_header_only_column():
    p = synthetic_page()
    (t,) = detect_tables(p)
    assert len(t.x_edges) == 6 and len(t.y_edges) == 6
    rows = [[text_of(c.words, p.index()) for c in t.cells if c.row == r] for r in range(5)]
    assert rows[1] == ["001000", "", "Guest 0\nFamily", "Jun 09,\n2026", "1.25"]
    assert rows[4][0] == "001003"
    assert Counter(k for c in t.cells for k in c.words) == Counter(w.id for w in p.words)


@pytest.mark.parametrize("mode", ["layout", "semantic"])
def test_export_respects_approved_model_grid_and_cell_override(mode):
    p = synthetic_page()
    (table,) = detect_tables(p)
    table.method = "tatr"
    table.cells[0].override = "APPROVED HEADER"
    p.blocks = [table]
    data = excel.export(Document("model-grid", "", b"", pages=[p]), mode=mode)
    workbook = openpyxl.load_workbook(io.BytesIO(data))
    assert workbook.active.max_column == 5
    assert workbook.active["A1"].value == "APPROVED HEADER"


@pytest.mark.parametrize("mode", ["layout", "semantic"])
def test_layout_values_and_preview_share_workbook(mode):
    data = excel.export(Document("synth", "", b"", pages=[synthetic_page()]), mode=mode)
    wb = openpyxl.load_workbook(io.BytesIO(data), rich_text=True)
    sheets = excel.preview(data)
    json.dumps(sheets)
    for ws, sh in zip(wb, sheets):
        assert len(sh["widths"]) == ws.max_column
        assert len(sh["heights"]) == ws.max_row
        assert sh["merges"] == [str(m) for m in ws.merged_cells.ranges]
        assert sh["rows"] == [
            [str(c.value) if isinstance(c.value, list) else c.value for c in row] for row in ws
        ]
    vals = [c.value for ws in wb for row in ws for c in row if c.value is not None]
    assert 1.25 in vals and any(str(v) == "001000" for v in vals)


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("7,601.49", 7601.49),
        ("7 601,49", 7601.49),
        ("7.601,49", 7601.49),
        (".00", 0),
        (",00", 0),
        ("-12.50", -12.5),
        ("00123", None),
        ("001.23", None),
        ("1,234", None),
        ("2026-06-09", None),
        ("1234567890123456.12", None),
        ("=SUM(A1:A3)", None),
    ],
)
def test_conservative_numbers_independent_of_output_locale(raw, expected):
    for locale in ["auto", "hu", "en"]:
        assert decimal(raw, locale) == expected
    assert decimal(raw, "text") is None


def test_three_column_retries_actually_change_geometry():
    p = synthetic_page()
    signatures = [tuple(detect_tables(p, i)[0].x_edges) for i in range(3)]
    assert len(set(signatures)) == 3
    opts = OutputOptions(format="xlsx")
    for expected in (1, 2, 0):
        opts = fallback(opts, "columns")
        assert opts.grid_sensitivity == expected
    assert fallback(opts, "empty").excel_mode == "semantic"
    assert fallback(fallback(opts, "empty"), "empty").excel_mode == "layout"


def test_scan_column_error_switches_engine_even_if_current_was_selected():
    from studio.ir import Profile

    r = Router({n: {"available": True} for n in ("native", "paddle", "tesseract", "tatr")})
    strategy = r.choose(
        Profile(kind="scanned", label="", reasons=[], pages=1),
        error="columns",
        current="paddle",
        requested="paddle",
    )
    assert strategy.ocr == "tesseract" and strategy.psm == 4
    assert strategy.table == "columns-0"


@pytest.mark.parametrize("pages", [1, 2])
def test_png_is_actual_preview_bytes_and_multipage_is_zip(tmp_path, pages):
    import fitz

    data = make_invoice(rows=2, merged=False)
    if pages == 2:
        with fitz.open(stream=data, filetype="pdf") as src, fitz.open() as out:
            out.insert_pdf(src)
            out.insert_pdf(src)
            data = out.tobytes()
    a = AssetStore(tmp_path / "assets")
    ir = ingest(data, "native.pdf", a, {"engine": "native", "orientation": False})
    target = tmp_path / "png"
    meta = generate(ir, a, OutputOptions(format="png"), target)
    assert meta["preview_pages"] == pages
    data = (target / meta["filename"]).read_bytes()
    if pages == 1:
        assert meta["filename"] == "document.png" and data == (target / "page-1.png").read_bytes()
    else:
        assert meta["filename"] == "document.zip"
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            assert z.namelist() == ["page-001.png", "page-002.png"]
            assert z.read("page-002.png") == (target / "page-2.png").read_bytes()


@pytest.fixture(scope="module")
def supplied(tmp_path_factory):
    filename = os.getenv("DOCSTUDIO_SAMPLE_PDF")
    if not filename:
        pytest.skip("Private PDF fixture: set DOCSTUDIO_SAMPLE_PDF")
    a = AssetStore(tmp_path_factory.mktemp("private") / "assets")
    ir = ingest(
        Path(filename).read_bytes(),
        Path(filename).name,
        a,
        {"engine": "native", "orientation": False, "verify_ocr": False},
    )
    ir.revision = 1
    return ir, a


def test_supplied_80_records_10_fields_and_correct_total(supplied):
    ir, a = supplied
    count, total, identities = 0, Decimal(0), []
    for page in ir.pages[1:]:
        for t in detect_tables(page):
            assert len(t.x_edges) == 11
            for c in t.cells:
                if c.row and c.col == 9:
                    total += Decimal(text_of(c.words, page.index()).replace(",", ""))
                    count += 1
                if c.row and c.col == 0:
                    identities.append(text_of(c.words, page.index()))
    assert count == 80 and len(set(identities)) == 80 and total == Decimal("7601.49")
    data = excel.export(to_runtime(ir, a))
    wb = openpyxl.load_workbook(io.BytesIO(data), rich_text=True)
    assert len(wb.sheetnames) == 5  # The sixth source page is genuinely empty.
    assert all(s.max_column == 10 for s in list(wb)[1:])
    assert len(wb.worksheets[0]._images) == 1
    exported_ids = [
        str(c.value) for s in list(wb)[1:] for c in s["A"] if str(c.value) in identities
    ]
    assert Counter(exported_ids) == Counter(identities)
    amount_sum = sum(
        Decimal(str(s.cell(r, 10).value))
        for s in list(wb)[1:]
        for r in range(1, s.max_row + 1)
        if str(s.cell(r, 1).value) in identities
    )
    assert amount_sum == total
    assert not any(c.comment and "ütközés" in c.comment.text for s in wb for row in s for c in row)


@pytest.mark.parametrize("sensitivity", [0, 1, 2])
def test_supplied_all_words_survive_without_bitmap_substitution(supplied, sensitivity):
    ir, a = supplied
    data = excel.export(to_runtime(ir, a), numbers="text", sensitivity=sensitivity)
    wb = openpyxl.load_workbook(io.BytesIO(data), rich_text=True)
    for p, s in zip(ir.pages, wb):
        source = Counter(token for w in p.words for token in w.text.split())
        result = Counter(
            token for row in s for c in row if c.value is not None for token in str(c.value).split()
        )
        assert result == source
        assert all(c.data_type != "f" for row in s for c in row)


def test_supplied_retry_rebuilds_bad_table_and_preserves_other_pages(supplied):
    ir, a = supplied
    other = retry_page(ir, a, 2, "columns", 0, {"engine": "native", "verify_ocr": False})
    (table,) = [b for b in other.pages[1].blocks if b.kind == "table"]
    assert len(table.x_edges) == 11 and len(table.y_edges) == 22
    assert other.pages[1].diagnostics["retry_changes"] == dict(
        text_or_position=False, structure=True, tables=1
    )
    for i in (0, 2, 3, 4, 5):
        assert other.model_dump()["pages"][i] == ir.model_dump()["pages"][i]
