# DocStudio 7

PDF, szkennelt kép, DOCX és XLSX beolvasása, vizuális ellenőrzése és újraalkotása. FastAPI + Jinja2 + saját CSS/Vanilla JS; nincs Streamlit és külön frontend-szerver.

A munkafolyamat alapja egy verziózott **IR JSON**. A vászon, a szövegjavítás, a hibagombos újrafelismerés és az export ugyanazt az adatmodellt használja. Az exportelőnézet a **ténylegesen elkészített fájlból** készül. A letölthető fájl SHA256-azonosságát a rendszer ellenőrzi.

## V7: grafika, betűszerkesztés és olvasható Excel

- A szkennelt lapok **lekerekített, pontozott, szaggatott és kézírásos grafikai részei** a forrás képpontjaiból maradnak meg. A felismert szöveget eltávolítjuk ebből a rétegből, és szerkeszthető betűként rajzoljuk. A vonalkeresés a táblázatfelismerést segíti; a megtartott vonalakat nem rajzoljuk még egyszer vastagon a forrásra. Ez nem teszi az aláírást szerkeszthető vektorobjektummá.
- Az OCR szavainak vízszintes kiosztását soronként illesztjük, külön megtartva a nagy oszlopközöket. A túlméretezett sorszámok és az egymásra érő sorok külön korrekciót kapnak. A betűcsaládot oldalanként kevés mintából becsüljük; nincs szavankénti fontkeresés.
- A vásznon szöveg, **betűméret, betűtípus és félkövérség** szerkeszthető. A betűtípusok: Arial, Times New Roman, Courier New, a helyi rajzolásban metrikailag megfelelő Liberation betűkkel. Minden mentés visszaállítható IR-verzió.
- Az Excel vízszintes tartalmi sávokat használ a sok apró PDF-koordinátasor helyett. A sorok és oszlopok a betűk tényleges mérete alapján **csak nőnek**; nincs cellazsugorítás vagy egy oldal magasságára szorítás. Nincsenek cellamegjegyzések, megjegyzésdobozok vagy piros megjegyzésjelölők egyik XLSX-exportban sem.
- A nagy bevezető szöveg eltűnt, a munkafelület feljebb került.
- Az automatikus OCR jó első olvasatnál nem ismétli meg feleslegesen a meneteket. A teljes ellenőrzés és a külön második OCR-motor választható. A vonalkereső egyszer készít képtömböt, nem minden vonalhoz újra. A beolvasás gyorsulása dokumentumfüggő.
- A Vision panel megmondja, mely beállítás hiányzik. A **kapcsolatteszt** csak a szolgáltató modell-listáját kérdezi le, dokumentumot nem továbbít. Élő képfeldolgozáshoz külön engedély és képet fogadó modell kell.
- A Codespaces telepítő a Yarn hiányzó aláírókulcsa esetén csak a Yarn APT-bejegyzéseit kapcsolja ki, biztonsági másolat mellett; más tárolókat és az aláírás-ellenőrzést megtartja.

A részletes mérési feltételek és korlátok: [tesztjelentés](docs/TEST_REPORT.md). A korábbi változatok mérései történeti adatok.

## V6: Excel és közvetlen vászonszerkesztés

- Az Excel alapértelmezése **a dokumentum elrendezésének megőrzése**: egy kitöltött PDF-oldal egy munkalap, szerkeszthető cellák, többsoros mezők, eredeti betűméret/szín, címsorok, kitöltések és logók. A valóban üres oldalak nem hoznak létre üres munkalapot.
- Az Excel-előnézet alapból **rácsos munkafüzet**, A–B–C oszlopokkal, sorszámokkal, munkalapfülekkel és a kijelölt cella teljes értékével. Ugyanabból a kész XLSX-ből olvassa a tartalmat, méreteket, összevonásokat és képeket, amelyet letöltesz. A nyomtatási nézet külön kapcsolható.
- Kattints egy szóra a beolvasási vásznon: **helyben javíthatod**. Enter: mentés; Escape: a még nem mentett javítás elvetése. A korábbi változatok visszaállíthatók.
- A vászon feletti, középre igazított gomb után **ikonos formátumválasztó** jelenik meg. A kiválasztás elkészíti az előnézetet. A **Jóváhagyás és export** gomb automatikusan letölti a megjelenített, hash-ellenőrzött fájlt.
- Az oszlophibás újrapróba a meglévő táblázatokat is újraszegmentálja; scan esetén más elérhető OCR-motort és PSM-et választ. Három oszlophatár-stratégia váltakozik. A napló külön jelzi, ha csak a szerkezet változott, vagy ugyanaz az eredmény született.
- Excel-hibagombok: eltérő oszlophatárok; adatrács/elrendezés módváltás; konzervatív számmá alakítás. A kezdő nullás azonosítók és a képletnek látszó szövegek nem válnak képletté.
- Új PNG-export: egy oldal PNG, több oldal PNG-ket tartalmazó ZIP. A PDF/Word-export ugyanazt a jóváhagyott IR-t és grafikai réteget használja.

### Frissítés a már működő /workspaces/DOC Codespace-ben

Állítsd le a terminálban futó szervert **Ctrl+C**-vel, és töltsd fel ide az új `docstudio-v7-complete.zip` fájlt. Ezután a **Bash terminálba** másold:

```bash
bash <<'BASH'
set -euo pipefail
cd /workspaces/DOC
bash scripts/stop.sh
python3 -m zipfile -e docstudio-v7-complete.zip .
bash scripts/setup_system.sh
bash scripts/setup.sh
bash scripts/start.sh
BASH
```

A csomag nem tartalmaz `.env` fájlt, környezetet, saját dokumentumokat vagy modellsúlyokat; a meglévő `.env` és modellek megmaradnak. A módosított forrásfájlokat felülírja, ezért saját kódmódosításaidat előtte commitold. A `stop.sh` leállítja az ehhez a projekthez tartozó, korábban `start_background.sh`-val indított szervert. A másik terminálban kézzel elindított szervert ott állítsd le **Ctrl+C**-vel. A böngészőben használj **Ctrl+Shift+R** frissítést.

Ha a setup Python 3.14-et jelez: **Command Palette → Codespaces: Rebuild Container**. A mellékelt konfiguráció Python 3.11-es devcontainer-képet használ. A telepítő 3.11/3.12-t fogad el, és egy korábbi, inkompatibilis `.venv` mappát átnevezett biztonsági másolatban őriz meg.

## Gyors indítás GitHub Codespaces-ben

1. Csomagold ki a forrás ZIP-et. A tartalmát töltsd egy **privát GitHub repository gyökerébe**: itt legyen a `README.md`, `requirements.txt`, `studio/`, `web/`, `.devcontainer/` és `.github/`. A ZIP feltöltése önmagában nem telepítés. A ponttal kezdődő konfigurációs mappákat is másold át. A saját számláidat ne tedd a kód-repositoryba.
2. GitHub: **Code → Codespaces → Create codespace on main**. A mellékelt devcontainer Python 3.11-et, Tesseract hun+eng+osd modelleket, LibreOffice Writer/Calc programot és Unicode betűkészleteket készít elő.
3. A `postCreateCommand` először a `bash scripts/setup_system.sh`, majd a `INSTALL_TATR=1 bash scripts/setup.sh` parancsot futtatja. Ez telepíti a PP-OCRv5 Latin ONNX motorját és a Microsoft Table Transformer CPU-változatát is. Az első telepítés internetet és több percet igényel. A modellek letöltése a telepítés része; a feldolgozás helyben fut.
4. Az alkalmazás a **8080-as porton** automatikusan indul. A Codespaces **Ports** fülén válaszd az **Open in Browser** lehetőséget. A port maradjon **Private**.
5. Töltsd fel a dokumentumaidat. Válts a **Forrás**, **Újraalkotott**, **Rávetítés** nézetek között. Kapcsold be a **Felismert szerkezet** réteget a táblázatrácsok ellenőrzéséhez.
6. Ha hibás a vászon: válassz hibagombot, majd **Újraalkotás a hiba alapján**. Az új változat mellett a régi is megmarad. Egy szóra kattintva kézzel is javíthatsz.
7. **Jóváhagyás → formátumikon → előnézet → Jóváhagyás és export**. Az elfogadott exportokat együtt ZIP-ben is letöltheted.

Ha a Codespace már korábban létrejött más konfigurációval: parancspaletta → **Codespaces: Rebuild Container**. Ha az automatikus indítás nem futott le:

```bash
bash scripts/setup_system.sh
INSTALL_TATR=1 bash scripts/setup.sh
bash scripts/start.sh
```

A `setup.sh` első futáskor létrehozza a `.env` fájlt, és véletlen munkamenet-titkot generál. Meglévő `.env` tartalmát nem írja felül. Indítási napló: `.local/server.log`. Legalább 2 CPU és 8 GB memória ajánlott a teljes csomaghoz. Több fájl feltölthető egyszerre; egy CPU-feldolgozó halad a sorban.

## A feldolgozómotorok

| Feladat | Implementáció | Működés |
|---|---|---|
| Natív PDF | PyMuPDF | Szöveg, koordináták, vonalak és képek kinyerése |
| Szkennelt szöveg | PP-OCRv5 Latin + RapidOCR 3.4.2 + ONNX Runtime | Helyi neurális detektálás és karakterfelismerés, CTC-alapú szódobozok |
| Második olvasat | Tesseract LSTM hun+eng | A neurális olvasattal való eltérések jelölése; nem írja át csendben a szöveget |
| Szöveghibás újrapróba | Router | Másik OCR, kontraszt és szegmentálás; külön IR-verzió |
| Képi táblázat | Microsoft Table Transformer | Tábla-, sor-, oszlop- és összevontcella-felismerés; sikertelen találatnál jelzett geometriai tartalék |
| Oszlop- és vonalelemzés | OpenCV + koordináta-geometria | Perspektíva, dőlés, tájolás, vonalak, térközök és blokkhatárok |
| DOCX bemenet | LibreOffice → natív PDF → IR | Az Office-renderer által értelmezett tördelésből |
| XLSX bemenet | openpyxl → IR | Eredeti cellatartalom és összevonások; lapozott szemantikai rács |
| Opcionális Vision | OpenAI-kompatibilis HTTP API | Hiba-tudatos prompt, explicit oldalküldési engedély, szigorú JSON-validáció |

A képfeldolgozás a PP-OCRv5 előtt történik. A nyugták körüli nagy üres laprészt az OCR következtetéséhez kivágjuk, majd minden koordinátát visszavetítünk a teljes oldalra. Az eredeti feltöltés külön, változatlan bájtokkal megmarad.

A hosszú nyugtáknál külön korrekció védi a szódobozokat a kétszeres visszaméretezéstől. A keskeny nyomtatóbetűk magasságát és vízszintes skáláját külön illesztjük, a szomszédos sorok távolságát figyelembe véve. Ettől a szöveg valódi, szerkeszthető betű marad; az ismeretlen eredeti fontot ez is csak közelíti.

**A motorpontszám nem mért felismerési pontosság.** A két OCR eltérő olvasata sárga ellenőrzési jelzést ad. Ettől a rendszer még nem tudja bizonyítani, melyik szó helyes. A számlák számai és a nevek emberi ellenőrzést igényelhetnek.

## Exportok és valós korlátok

- **PDF:** az IR-ből rajzolt, látható és kijelölhető betűk, külön grafikai elemek. A szöveg nem a teljes scan képe. Bizonytalan szavak helyére nem kerül automatikusan képkivágás.
- **Word DOCX:** oldalhoz rögzített, szerkeszthető szövegdobozok. Alapból soronként, a „Szétcsúszott elemek” javításnál szavanként. A „Folyószöveg” mód külön szerkesztési célra való, és megváltoztatja a lapképet. A felület LibreOffice-val rendereli a tényleges DOCX-et; a Microsoft Word eltérően tördelhet.
- **Excel XLSX:** alapból oldalelrendezést követő, szerkeszthető cellák. A fejléc nélküli térközös táblázatokat geometriai módszer becsüli; a többsoros adatmezők ugyanazon rekordhoz kerülnek. Az üres, de fejléccel azonosítható oszlopok megmaradnak. „Adattáblák külön lapokon” módban a táblázatok külön adatlapokra kerülnek. A számfelismerés csak egyértelmű decimális értékeket alakít át, a dátumok és hosszú/kezdő nullás azonosítók szövegek maradnak. A magyar/angol választás az előnézet megjelenítését szabályozza; a munkafüzet numerikus celláit az Excel saját területi beállítása szerint formázza. A rács a kész XLSX-ből származik; a böngésző, LibreOffice és Microsoft Excel betűtördelése kis mértékben eltérhet.
- **PNG:** az IR-ből újraalkotott oldal 144 dpi felbontású képe; több oldalnál egy ZIP tartalmazza az összes PNG-t. Az előnézet pontosan a letölthető képbájtokat jeleníti meg.
- **JSON:** a teljes validált IR; a bináris képek/forrásfájlok SHA256 assethivatkozások. A puszta JSON nem önhordozó archiválási csomag. A CLI ZIP az asseteket is tartalmazza.
- **HTML / TXT:** IR-ből generált szöveges export. A HTML-előnézet a kódot mutatja, nem futtat dokumentumból származó HTML-t.
- **Eredeti fájl:** külön letölthető, pontosan a feltöltött bájtokkal. Ez biztosítja az eredeti kinézet megőrzését.

**Szerkeszthető Word-exportnál és OCR-rel újraalkotott oldalaknál nem garantálható 100% pixelazonosság.** Ismeretlen betűkészlet, sérült nyomat, bélyegző, aláírás, ferde szöveg vagy hibás OCR esetén marad eltérés. A bélyegzők átfedő szövegének újraalkotása a mellékelt mintákon is korlát. A rendszer ezeket megmutatja és visszaállítható javításokat ad, nem állítja róluk, hogy hibátlanok.

A célformátumok nem egyenértékűek: az Excel cellákra képezi az oldal elrendezését, ezért tetszőleges grafikánál vagy bonyolult átfedésnél nem garantálható pixelazonosság. A logó külön kép marad, a felismert szöveg valódi cellatartalom. A DOCX/XLSX régi `.doc`/`.xls` változata, makrófájlok, kézírás megbízható átírása és tetszőleges fájltípus automatikus értelmezése nincs támogatva.

## Helyi Linux telepítés

Python 3.11 vagy 3.12 szükséges. Debian/Ubuntu rendszerfüggőségek:

```bash
sudo apt-get update
sudo apt-get install -y python3-venv tesseract-ocr tesseract-ocr-hun tesseract-ocr-eng tesseract-ocr-osd libreoffice-writer libreoffice-calc fonts-liberation2 fonts-dejavu-core libgl1 libglib2.0-0 libgomp1
INSTALL_TATR=1 bash scripts/setup.sh
bash scripts/start.sh
```

A `libgl1` a jelenlegi Debian csomagnév; a régi `libgl1-mesa-glx` nem szükséges. Egyetlen OpenCV Python-disztribúciót telepítünk, a RapidOCR függőségével egyező `opencv-python` csomagot. Nincs egyszerre headless és GUI OpenCV a követelménylistában.

Kisebb telepítés TATR nélkül: `bash scripts/setup.sh`. Utólag: `bash scripts/setup_tatr.sh`. Klasszikus OCR-hez a felületen válaszd a Tesseract motort. TATR és Vision nélkül is használható az alkalmazás; a hiányzó motorokat a panel kiírja.

## Docker

A `.env` alapját másold a `.env.example` fájlból, és állíts be egy véletlen `APP_SESSION_SECRET` értéket. A helyi modellek útvonalát a Compose automatikusan a konténerre igazítja.

```bash
docker compose build --build-arg INSTALL_TATR=1
docker compose up -d
docker compose logs -f
```

Megnyitás: `http://localhost:8080`. A Compose alapból a helyi gép 127.0.0.1 címéhez köt. Docker alapbuild TATR nélkül is működik: `docker compose build`. A PP-OCRv5 és a LibreOffice mindkét build része. A modellek a build során töltődnek le. A `PORT` környezeti változó módosíthatja az Uvicorn portját; a porttovábbítást hozzá kell igazítani.

## Opcionális Vision / Ollama

Példa `.env` beállításra, már működő, képeket fogadó OpenAI-kompatibilis szolgáltatás esetén:

```dotenv
VISION_BASE_URL=http://localhost:11434/v1
VISION_MODEL=a-sajat-telepitett-vision-modelled
VISION_API_KEY=
```

**A `localhost` mindig az alkalmazást futtató gépet jelenti.** Codespaces esetén ez a Codespace, nem a saját asztali géped. Helyi gépen futó Ollama csak megfelelően elérhető kiszolgálócím megadásával használható.

A kapcsolat ellenőrzésére a felületen külön gomb van; a teszt modell-listát kér le, dokumentumot nem küld. A sikeres lista még nem bizonyítja, hogy a modell képeket is fogad.

A modellnév helyőrző: a saját kiszolgálódon telepített modell pontos nevét add meg. Indítsd újra az alkalmazást, engedélyezd az oldalküldést a felületen, és válaszd a Vision motort. Az oldal képe a beállított kiszolgálóra kerül. A modell válasza **nem ellenőrzött javaslat**; a rendszer koordinátát és JSON-szerkezetet validál, tényszerű helyességet nem. A prompt tartalmazza az aktuális hibajelzést. Élő külső Vision-szolgáltatás nem volt része a kiadási tesztnek; a szerződést mock HTTP-válaszokkal teszteljük.

## Parancssori teljes export

```bash
.venv/bin/python cli.py sajat-scan.pdf --output eredmeny.zip --engine paddle --numbers hu
```

A ZIP tartalma: IR, SHA256-névvel tárolt assetek, PDF, DOCX, XLSX, HTML, TXT és valódi exportelőnézetek. Csak néhány formátumhoz: `--formats pdf json`. A meglévő kimenetet csak `--overwrite` kapcsolóval írja felül. A CLI nem végzi el helyetted az emberi ellenőrzést.

## Tesztek

```bash
.venv/bin/python -m ruff check .
RUN_OCR_TESTS=1 RUN_OFFICE_TESTS=1 .venv/bin/python -m pytest tests -q
.venv/bin/python scripts/benchmark_v5.py
```

Böngészős teszt:

```bash
.venv/bin/python -m pip install playwright==1.51.0
.venv/bin/python -m playwright install --with-deps chromium-headless-shell
.venv/bin/python scripts/browser_v7.py
# Az ehhez a kiadáshoz adott remittance PDF célzott tesztje:
DOCSTUDIO_SAMPLE_PDF=/teljes/utvonal/remittanceDetails_expedia0717.pdf .venv/bin/python -m pytest tests/test_v6.py -q
.venv/bin/python scripts/browser_v7.py --sample /teljes/utvonal/remittanceDetails_expedia0717.pdf
# Külön neurális OCR böngészőteszt (telepített modellekkel):
.venv/bin/python scripts/studio_browser_smoke.py
```

A benchmark ismert szövegű, tiszta, zajos, életlen, kontrasztszegény, ferde és elforgatott tesztoldalakat készít. WER/CER hibaarányt mér; a puszta szószám nem pontosság. A böngészős teszt saját ideiglenes szervert indít, végigjárja a javítás–elfogadás–export–letöltés folyamatot, és 390 pixeles mobilnézetet is vizsgál. A saját minták nem részei a GitHubra szánt forráscsomagnak.

Részletes eredmények: [tesztjelentés](docs/TEST_REPORT.md). Felépítés és állapotgép: [architektúra](docs/ARCHITECTURE.md). Formális IR: [JSON Schema](schemas/document-ir.schema.json); példa: [IR JSON](examples/ir-example.json).

## Üzemeltetés

Ez a kiadás **egy Uvicorn-folyamatot, egy helyi feldolgozószálat és SQLite WAL adatbázist** használ. Tartós háttértár mellett a kész állapotok és IR-változatok újraindítás után is megmaradnak; megszakadt műveletet explicit hibaként jelöl. Nem elosztott, többgépes feladatsor. A Strategy és Store határok lehetővé teszik későbbi Celery/RQ/PostgreSQL adapter bevezetését, de ilyen adapter nincs a csomagban. Ne indíts több Uvicorn-workert ugyanarra az állapottárra.

Korlátok: 50 MB/fájl, 100 MB/feltöltés, legfeljebb 10 fájl/feltöltés, 60 oldal/dokumentum, alapból 20 tárolt feladat és 100 IR-változat/dokumentum. A kész, inaktív feladatok alapértelmezett megőrzése 24 óra (`JOB_TTL_SECONDS=86400`). A böngészős munkamenet külön tulajdonos: más böngésző nem ugyanazokat a dokumentumokat látja. Ez nem többfelhasználós vállalati fiókkezelés.

Nyilvános üzemeltetéshez `APP_ENV=production`, legalább 32 karakteres `APP_SESSION_SECRET`, legalább 16 karakteres `APP_ACCESS_PASSWORD`, `COOKIE_SECURE=1`, HTTPS és tartós `JOB_DIR` szükséges. A produkciós indítás ezeket ellenőrzi. Az alkalmazásjelszó helyett szervezeti SSO később külön integrálható.

A régi v4 `/api/jobs` végpontok alapból le vannak tiltva. Csak átmeneti kompatibilitáshoz kapcsolhatók vissza `ENABLE_LEGACY_API=1` beállítással; ezek nem az új IR-munkafolyamatot használják. Az új felület és CLI a közös IR-alapú utat használja. A `studio-v5` belső adatkönyvtárnév megmaradt a meglévő munkák kompatibilitásához.

A használt motorok dokumentációja és licenchivatkozásai: [SOURCES.md](docs/SOURCES.md). A PyMuPDF AGPL/commercial feltételeit külön ellenőrizd a tervezett terjesztési módhoz.

### Saját minták ellenőrzése a V7-tel

```bash
.venv/bin/python scripts/verify_v7.py /teljes/utvonal/minta.pdf --with-office
.venv/bin/python scripts/verify_v7.py /teljes/utvonal/scan.png --engine paddle
```

A `test-results/v7-samples/` mappába kerül a verziózott IR, az újraalkotott PDF, a képi ellenőrzés, a cellás XLSX és a gépi jelentés. `--with-office` esetén a Word-fájl és a tényleges Office-renderek is elkészülnek. A tesztadatokat ne töltsd fel a forráskód-repositoryba.
