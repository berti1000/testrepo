"""IR-first batch CLI. Review outputs before relying on recognized content."""

import argparse
import os
from pathlib import Path
import tempfile
import zipfile
from dotenv import load_dotenv
from studio.ir import AssetStore
from studio.pipeline import ingest
from studio.output.service import OutputOptions, generate


def main():
    load_dotenv()
    p = argparse.ArgumentParser(description="PDF/kép/DOCX/XLSX → IR → exportcsomag")
    p.add_argument("input", type=Path)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--engine", choices=["auto", "native", "paddle", "tesseract"], default="auto")
    p.add_argument(
        "--formats",
        nargs="+",
        choices=["pdf", "docx", "xlsx", "png", "json", "html", "txt"],
        default=["pdf", "docx", "xlsx", "json", "html", "txt"],
    )
    p.add_argument("--numbers", choices=["auto", "text", "hu", "en"], default="auto")
    p.add_argument("--excel-mode", choices=["layout", "semantic"], default="layout")
    p.add_argument("--word-mode", choices=["positioned", "precise", "flow"], default="positioned")
    p.add_argument("--no-orientation", action="store_true")
    p.add_argument("--no-deskew", action="store_true")
    p.add_argument("--perspective", action="store_true")
    p.add_argument("--dpi", type=int, default=300)
    p.add_argument("--overwrite", action="store_true")
    args = p.parse_args()
    if args.output.exists() and not args.overwrite:
        p.error("A kimenet létezik; --overwrite szükséges")
    if args.input.resolve() == args.output.resolve():
        p.error("A bemenet nem írható felül")
    if args.input.stat().st_size > 50 * 1024 * 1024:
        p.error("50 MB bemeneti korlát")
    with tempfile.TemporaryDirectory(prefix="docstudio-cli-") as temp:
        root = Path(temp)
        a = AssetStore(root / "assets")
        ir = ingest(
            args.input.read_bytes(),
            args.input.name,
            a,
            {
                "engine": args.engine,
                "orientation": not args.no_orientation,
                "deskew": not args.no_deskew,
                "perspective": args.perspective,
                "dpi": args.dpi,
                "password": os.getenv("DOCUMENT_PDF_PASSWORD", ""),
            },
            lambda n, t: print(f"{n:.0%} {t}", flush=True),
        )
        ir.revision = 1
        (root / "ir.json").write_bytes(ir.dump())
        for fmt in dict.fromkeys(args.formats):
            print("Export:", fmt, flush=True)
            generate(
                ir,
                a,
                OutputOptions(
                    format=fmt,
                    numbers=args.numbers,
                    word_mode=args.word_mode,
                    excel_mode=args.excel_mode,
                ),
                root / fmt,
            )
        args.output.parent.mkdir(parents=True, exist_ok=True)
        temp_output = args.output.with_suffix(args.output.suffix + ".tmp")
        with zipfile.ZipFile(temp_output, "w", zipfile.ZIP_DEFLATED) as z:
            for file in root.rglob("*"):
                if file.is_file():
                    z.write(file, file.relative_to(root))
        temp_output.replace(args.output)
        for page in ir.pages:
            for warning in page.warnings:
                print(f"{page.number}. oldal: {warning}")
    print("Kész:", args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
