"""Reproduce local PDF scan processing, actual exports, and feedback strategies."""

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
import fitz
from studio.ir import AssetStore, to_runtime
from studio.pipeline import ingest, retry_page
from studio.output.service import generate, OutputOptions
from reconstructor.render import reconstructed_pdf


def main():
    load_dotenv(ROOT / ".env")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", type=Path, nargs="+")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--engine", choices=["auto", "paddle", "tesseract"], default="paddle")
    parser.add_argument("--no-orientation", action="store_true")
    args = parser.parse_args()
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("Üres kimeneti mappa szükséges; korábbi tesztet nem írunk felül.")
    args.output.mkdir(parents=True, exist_ok=True)
    report = []
    for ordinal, source in enumerate(args.files, 1):
        if source.suffix.lower() != ".pdf":
            parser.error("A mintateszt PDF-eket vár.")
        folder = args.output / f"{ordinal:02d}-{source.stem}"
        folder.mkdir()
        assets = AssetStore(folder / "assets")
        started = time.monotonic()
        data = source.read_bytes()
        ir = ingest(
            data,
            source.name,
            assets,
            {"engine": args.engine, "orientation": not args.no_orientation},
        )
        ir.revision = 1
        (folder / "ir.json").write_bytes(ir.dump())
        pdf = reconstructed_pdf(to_runtime(ir, assets))
        (folder / "reconstructed.pdf").write_bytes(pdf)
        with fitz.open(stream=pdf, filetype="pdf") as rendered:
            for i, page in enumerate(rendered, 1):
                page.get_pixmap(matrix=fitz.Matrix(2, 2)).save(folder / f"reconstructed-{i}.png")
        result = {
            "file": source.name,
            "source_sha256": hashlib.sha256(data).hexdigest(),
            "words": sum(len(p.words) for p in ir.pages),
            "seconds": round(time.monotonic() - started, 2),
            "diagnostics": [p.diagnostics for p in ir.pages],
            "exports": {},
            "retries": [],
        }
        print(source.name, "OCR kész", result["seconds"], flush=True)
        for fmt in ["docx", "xlsx"]:
            info = generate(ir, assets, OutputOptions(format=fmt), folder / fmt)
            result["exports"][fmt] = {k: info[k] for k in ["sha256", "preview_pages"]}
        for page in ir.pages:
            for error in ["text", "columns", "table"]:
                started = time.monotonic()
                changed = retry_page(ir, assets, page.number, error, 0)
                changed.revision = 2
                dest = folder / f"page-{page.number}-retry-{error}"
                dest.mkdir()
                (dest / "ir.json").write_bytes(changed.dump())
                (dest / "reconstructed.pdf").write_bytes(
                    reconstructed_pdf(to_runtime(changed, assets))
                )
                result["retries"].append(
                    {
                        "page": page.number,
                        "error": error,
                        "seconds": round(time.monotonic() - started, 2),
                        "diagnostics": changed.pages[page.number - 1].diagnostics,
                    }
                )
        report.append(result)
        (args.output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
        print(source.name, "kész", flush=True)


if __name__ == "__main__":
    main()
