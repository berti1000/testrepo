"""Install pinned official tessdata_best models, verifying SHA256 before use."""

import argparse
import hashlib
import json
import shutil
import urllib.request
from pathlib import Path

HASHES = {
    "hun": "08786ad5fe25d502d1cfcdf606ba215f320409a1630109582fa1a38d93b3e32d",
    "eng": "8280aed0782fe27257a68ea10fe7ef324ca0f8d85bd2fd145d1c2b560bcb66ba",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--destination", type=Path, default=Path("models/tessdata"))
    args = parser.parse_args()
    dest = args.destination
    dest.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for lang in ("hun", "eng", "osd"):
        path = dest / (lang + ".traineddata")
        expected = HASHES.get(lang)
        if (
            not path.exists()
            or expected
            and hashlib.sha256(path.read_bytes()).hexdigest() != expected
        ):
            local = next(
                (
                    p
                    for p in [
                        Path("/usr/share/tesseract-ocr/5/tessdata/osd.traineddata"),
                        Path("/usr/share/tesseract-ocr/4.00/tessdata/osd.traineddata"),
                    ]
                    if p.exists()
                ),
                None,
            )
            if lang == "osd" and local:
                shutil.copyfile(local, path)
            else:
                repo = "tessdata" if lang == "osd" else "tessdata_best"
                url = f"https://raw.githubusercontent.com/tesseract-ocr/{repo}/4.1.0/{lang}.traineddata"
                tmp = path.with_suffix(".part")
                try:
                    with urllib.request.urlopen(url, timeout=120) as r, tmp.open("wb") as f:
                        shutil.copyfileobj(r, f)
                    if tmp.stat().st_size < 100000:
                        raise RuntimeError("Invalid model file")
                    if expected and hashlib.sha256(tmp.read_bytes()).hexdigest() != expected:
                        raise RuntimeError("SHA256 mismatch: " + lang)
                    tmp.replace(path)
                finally:
                    tmp.unlink(missing_ok=True)
        manifest[lang] = {
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "bytes": path.stat().st_size,
        }
        print("Verified:", lang, flush=True)
    (dest / "manifest.json").write_text(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
