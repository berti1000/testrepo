"""Optional real Chromium smoke test: python scripts/browser_smoke.py.

Install once: pip install playwright==1.51.0
              python -m playwright install chromium-headless-shell
Starts its own Uvicorn server and removes its temporary jobs on exit.
"""

import argparse
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, expect
from tests.fixtures import make_invoice, make_ocr_image


def main():
    load_dotenv(ROOT / ".env")
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "test-results/browser")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="docstudio-e2e-") as folder:
        temp = Path(folder)
        native = make_invoice(rows=3, merged=False)
        (temp / "e2e-invoice.pdf").write_bytes(native)
        (temp / "e2e-scan.png").write_bytes(make_ocr_image())
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(
            os.environ,
            JOB_DIR=str(temp / "jobs"),
            APP_ENV="development",
            APP_ACCESS_PASSWORD="",
            COOKIE_SECURE="0",
            APP_SESSION_SECRET="browser-test-" * 6,
            AI_ENABLED="0",
            TESSDATA_PREFIX=str(Path(os.environ["TESSDATA_PREFIX"]).resolve()),
        )
        url = f"http://127.0.0.1:{port}"
        with (args.output / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "web.main:app",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(port),
                ],
                cwd=ROOT,
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                for _ in range(100):
                    try:
                        urllib.request.urlopen(url + "/health", timeout=1).close()
                        break
                    except OSError:
                        if server.poll() is not None:
                            raise RuntimeError("Uvicorn startup failed; see server.log")
                        time.sleep(0.1)
                with sync_playwright() as playwright:
                    browser = playwright.chromium.launch(headless=True, args=["--no-sandbox"])
                    page = browser.new_page(
                        viewport={"width": 1440, "height": 1050}, accept_downloads=True
                    )
                    errors = []
                    page.on("pageerror", lambda error: errors.append(str(error)))
                    page.goto(url + "/eszkozok/dokumentum-rekonstrukcio", wait_until="networkidle")
                    assert page.locator("link[rel=canonical]").count() == 1
                    page.locator("#files").set_input_files(
                        [temp / "e2e-invoice.pdf", temp / "e2e-scan.png"]
                    )
                    page.locator("form#upload details summary").click()
                    page.select_option("select[name=quality]", "fast")
                    page.locator("#submit").click()
                    expect(page.locator(".item .done")).to_have_count(2, timeout=120000)
                    page.locator(".item").first.get_by_role(
                        "button", name="Megnyitás és javítás"
                    ).click()
                    expect(page.locator("#img-original")).not_to_have_js_property("naturalWidth", 0)
                    assert page.locator("#img-reconstructed").is_hidden()
                    assert page.locator("#blend").is_disabled()
                    page.select_option("#preview-mode", "reconstructed")
                    expect(page.locator("#img-reconstructed")).not_to_have_js_property(
                        "naturalWidth", 0
                    )
                    assert page.locator("#img-reconstructed").is_visible()
                    assert (
                        page.locator("#img-reconstructed").evaluate(
                            "(el) => getComputedStyle(el).opacity"
                        )
                        == "1"
                    )
                    page.locator("#workspace").screenshot(path=str(args.output / "desktop.png"))
                    page.select_option("#preview-mode", "compare")
                    assert page.locator("#blend").is_enabled()
                    page.locator("[data-tab=words]").click()
                    first = page.locator("#word-rows tr").first
                    first.locator("input[type=text]").fill("JAVÍTOTT")
                    first.get_by_role("button", name="Mentés", exact=True).click()
                    expect(page.locator("#workspace-notice")).to_contain_text("Javítás mentve")
                    jobs = page.request.get(url + "/api/jobs").json()["jobs"]
                    native_job = next(job for job in jobs if job["name"] == "e2e-invoice.pdf")
                    prefix = url + "/api/jobs/" + native_job["id"]
                    assert "JAVÍTOTT" in page.request.get(prefix + "/export/txt").text()
                    assert page.request.get(prefix + "/export/original-pdf").body() == native
                    scan_job = next(job for job in jobs if job["name"] == "e2e-scan.png")
                    words = page.request.get(
                        url + "/api/jobs/" + scan_job["id"] + "/pages/1/words"
                    ).json()["words"]
                    assert any(word["text"] == "0012345678" for word in words)
                    page.locator(".item").nth(1).get_by_role(
                        "button", name="Megnyitás és javítás"
                    ).click()
                    page.locator("[data-tab=preview]").click()
                    page.select_option("#preview-mode", "reconstructed")
                    expect(page.locator("#img-reconstructed")).to_have_js_property("complete", True)
                    expect(page.locator("#img-reconstructed")).not_to_have_js_property(
                        "naturalWidth", 0
                    )
                    page.locator("#workspace").screenshot(
                        path=str(args.output / "scan-desktop.png")
                    )
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.screenshot(path=str(args.output / "mobile.png"), full_page=True)
                    assert page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
                    page.reload(wait_until="networkidle")
                    expect(page.locator(".item .done")).to_have_count(2)
                    with page.expect_download(timeout=30000) as download:
                        page.locator("#batch").click()
                    archive = args.output / "batch.zip"
                    download.value.save_as(str(archive))
                    with zipfile.ZipFile(archive) as z:
                        assert len(z.namelist()) == 2 and z.testzip() is None
                    assert not errors, errors
                    browser.close()
                (args.output / "result.json").write_text(
                    json.dumps(
                        {
                            "passed": True,
                            "checks": [
                                "two-file upload",
                                "real scan OCR",
                                "three preview modes",
                                "visible characters",
                                "word edit",
                                "source unchanged",
                                "session reload",
                                "batch ZIP",
                                "mobile width",
                                "no JavaScript errors",
                            ],
                        },
                        indent=2,
                    )
                )
                print("Browser smoke: PASS", flush=True)
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()


if __name__ == "__main__":
    main()
