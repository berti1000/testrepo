"""Fail early if the OCR models, system executable or Unicode fonts are missing."""

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[1] / ".env")
from reconstructor.ocr import installed_languages
from reconstructor.render import font_path
import pytesseract

print("Python:", sys.version.split()[0])
print("Tesseract:", pytesseract.get_tesseract_version())
languages = installed_languages()
print("OCR modellek:", ", ".join(sorted(languages)))
missing = {"hun", "eng", "osd"} - languages
if missing:
    raise SystemExit("Hiányzó modell: " + ", ".join(sorted(missing)))
for family in ("sans", "serif", "mono"):
    for bold, italic in ((False, False), (True, False), (False, True), (True, True)):
        font_path(family, bold, italic)
print("Unicode betűkészletek: OK")
print("Tároló:", os.getenv("JOB_DIR", "/tmp/reconstructor-jobs"))
from studio.router import capabilities

engines = capabilities()
for key, info in engines.items():
    print(key, "OK" if info["available"] else "nincs előkészítve")
if not engines["paddle"]["available"] or not engines["office"]["available"]:
    raise SystemExit("A v5 alaptelepítéshez PP-OCRv5 modellek és LibreOffice is szükséges.")
print("Minden alapfüggőség elérhető.")
