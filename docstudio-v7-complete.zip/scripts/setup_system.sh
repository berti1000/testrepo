#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_SUDO=()
if [[ "$(id -u)" != "0" ]]; then DOCSTUDIO_SUDO=(sudo); fi
DOCSTUDIO_APT_LOG="$(mktemp)"
trap 'rm -f "$DOCSTUDIO_APT_LOG"' EXIT
if ! "${DOCSTUDIO_SUDO[@]}" apt-get update >"$DOCSTUDIO_APT_LOG" 2>&1; then
  cat "$DOCSTUDIO_APT_LOG"
  if grep -q 'dl.yarnpkg.com' "$DOCSTUDIO_APT_LOG" && grep -q 'NO_PUBKEY' "$DOCSTUDIO_APT_LOG"; then
    "${DOCSTUDIO_SUDO[@]}" python3 "$(dirname "$0")/repair_yarn_repo.py"
    "${DOCSTUDIO_SUDO[@]}" apt-get update
  else
    exit 1
  fi
else
  cat "$DOCSTUDIO_APT_LOG"
fi
"${DOCSTUDIO_SUDO[@]}" apt-get install -y --no-install-recommends \
  python3-venv libgl1 libglib2.0-0 libgomp1 \
  tesseract-ocr tesseract-ocr-hun tesseract-ocr-eng tesseract-ocr-osd \
  libreoffice-writer libreoffice-calc fonts-liberation2 fonts-dejavu-core ca-certificates
