"""Chromium regression of the v7 canvas -> review -> exact-file download workflow.

Use --sample PDF for a private real document. Screenshots remain in the local
output directory and are not included in the distributed source/test reports.
"""

import argparse
import hashlib
import re
import fitz
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from playwright.sync_api import sync_playwright, expect
from tests.fixtures import make_invoice


def main():
    expect.set_options(timeout=90000)
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", type=Path)
    parser.add_argument("--output", type=Path, default=ROOT / "test-results/browser-v7")
    a = parser.parse_args()
    a.output = a.output.resolve()
    a.output.mkdir(parents=True, exist_ok=True)
    checks, errors = [], []
    with tempfile.TemporaryDirectory(prefix="docstudio-v7-") as td:
        td = Path(td)
        sample = a.sample.resolve() if a.sample else td / "native.pdf"
        if not a.sample:
            sample.write_bytes(make_invoice(rows=4, merged=False))
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        base = f"http://127.0.0.1:{port}"
        env = dict(
            os.environ,
            JOB_DIR=str(td / "jobs"),
            APP_ENV="development",
            APP_ACCESS_PASSWORD="",
            APP_SESSION_SECRET="v7-browser-test-secret-" * 4,
            COOKIE_SECURE="0",
            VISION_MODEL="",
        )
        with (a.output / "server.log").open("w") as log:
            process = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "web.main:app",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(port),
                ],
                cwd=ROOT,
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                for _ in range(100):
                    try:
                        urllib.request.urlopen(base + "/health", timeout=1).close()
                        break
                    except OSError:
                        if process.poll() is not None:
                            raise RuntimeError("Server startup failed")
                        time.sleep(0.1)
                with sync_playwright() as pw:
                    browser = pw.chromium.launch(
                        headless=True,
                        args=[
                            "--no-sandbox",
                            "--disable-dev-shm-usage",
                            "--disable-gpu",
                            "--disable-software-rasterizer",
                        ],
                    )
                    ctx = browser.new_context(
                        viewport={"width": 1600, "height": 1050}, accept_downloads=True
                    )
                    page = ctx.new_page()
                    page.set_default_timeout(90000)
                    page.on("pageerror", lambda e: errors.append(str(e)))
                    page.goto(base)
                    page.locator("#engine").select_option("native")
                    page.locator("#upload").set_input_files(str(sample))
                    expect(page.locator("#accept-input")).to_be_enabled()
                    first = page.locator("#word-layer rect").evaluate_all(
                        '(nodes) => nodes.sort((a,b) => Number(a.getAttribute("y"))-Number(b.getAttribute("y")))[0].dataset.word'
                    )
                    node = page.locator(f'#word-layer rect[data-word="{first}"]')
                    node.click()
                    expect(page.locator("#stage #editor")).to_be_visible()
                    expect(page.locator("#accept-input")).to_be_disabled()
                    assert page.locator(".intro").count() == 0
                    page.locator("#edit-text").fill("ELLENŐRZÖTT")
                    page.locator("#edit-size").fill("18")
                    page.locator("#edit-font").select_option("Times New Roman")
                    page.locator("#edit-bold").check()
                    # Polling must not erase an in-progress draft.
                    page.wait_for_timeout(1800)
                    expect(page.locator("#edit-text")).to_have_value("ELLENŐRZÖTT")
                    page.locator("#edit-text").press("Enter")
                    expect(page.locator("#editor")).to_be_hidden()
                    expect(page.locator("#revision-select option")).to_have_count(2)
                    expect(
                        page.locator("#word-layer title").filter(has_text="ELLENŐRZÖTT")
                    ).to_have_count(1)
                    checks.append(
                        "Inline canvas edit, Enter save, version change and draft retained while polling"
                    )
                    page.locator(f'#word-layer rect[data-word="{first}"]').click()
                    expect(page.locator("#edit-size")).to_have_value("18")
                    expect(page.locator("#edit-font")).to_have_value("Times New Roman")
                    expect(page.locator("#edit-bold")).to_be_checked()
                    checks.append("Inline size/bold/family persist; oversized hero removed")
                    page.locator("#edit-text").fill("UNSAVED")
                    page.locator("#edit-text").press("Escape")
                    expect(page.locator("#editor")).to_be_hidden()
                    expect(
                        page.locator("#word-layer title").filter(has_text="UNSAVED")
                    ).to_have_count(0)
                    page.locator("#revision-select").select_option("1")
                    page.locator("#restore").click()
                    expect(page.locator("#accept-input")).to_be_enabled()
                    checks.append("Escape discards only draft; revision restore preserves original")
                    if a.sample:
                        page.locator("#page-select").select_option("2")
                    page.locator("#input-errors button").filter(has_text="Összefolyt").click()
                    page.locator("#retry").click()
                    expect(page.locator("#revision-select option")).to_have_count(3)
                    expect(page.locator("#accept-input")).to_be_enabled()
                    expect(page.locator("#grid")).to_be_checked()
                    expect(page.locator("#diagnostics")).to_contain_text("persistent-whitespace")
                    checks.append(
                        "Column retry uses a different segmentation and displays its structure"
                    )
                    page.locator("#accept-input").click()
                    expect(page.locator("#format-picker")).to_be_visible()
                    expect(page.locator("#format-picker svg")).to_have_count(7)
                    page.locator('[data-format="xlsx"]').click()
                    expect(page.locator("#output-view")).to_be_visible()
                    expect(page.locator("#accept-export")).to_be_enabled()
                    expect(page.locator("#sheet-preview")).to_be_visible()
                    expect(page.locator("#output-image")).to_be_hidden()
                    expect(page.locator(".sheet-heading").first).to_have_text("A")
                    assert page.locator(".sheet-cell").count() > 10
                    checks.append(
                        "Format icon picker automatically builds XLSX; default preview is a styled grid"
                    )
                    button_box = page.locator("#accept-export").bounding_box()
                    bar_box = page.locator("#output-view .approval-bar").bounding_box()
                    assert (
                        abs(
                            button_box["x"]
                            + button_box["width"] / 2
                            - bar_box["x"]
                            - bar_box["width"] / 2
                        )
                        < 2
                    )
                    checks.append("Approval button centered above canvas")
                    if a.sample:
                        page.locator(".sheet-tabs button").nth(1).click()
                        with fitz.open(sample) as source:
                            tokens = [w[4] for w in source[1].get_text("words")]
                        record = next(t for t in tokens if re.fullmatch(r"\d{10}", t))
                        confirmation = next(
                            t for t in tokens if re.fullmatch(r"(?=.*[A-Z])(?=.*\d)[A-Z0-9]{6}", t)
                        )
                        expect(page.locator(".sheet-grid")).to_contain_text(record)
                        expect(page.locator(".sheet-grid")).to_contain_text(confirmation)
                        cell = page.locator(".sheet-cell").filter(has_text=confirmation)
                        cell.click()
                        expect(page.locator(".sheet-formula")).to_contain_text(confirmation)
                        checks.append(
                            "Actual sample cells, tab selection and full-value formula bar"
                        )
                    overflows = page.locator(".sheet-cell").evaluate_all("""cells => cells.filter(c => c.textContent.trim()).map(c => {
                      const t=c.querySelector('.cell-content');return {cell:c.dataset.cell,text:c.textContent,
                        height:t.getBoundingClientRect().height,available:c.clientHeight-2};
                    }).filter(x => x.height > x.available + 2)""")
                    for sheet_index in range(page.locator(".sheet-tabs button").count()):
                        page.locator(".sheet-tabs button").nth(sheet_index).click()
                        extra = page.locator(".sheet-cell").evaluate_all("""cells => cells.filter(c => c.textContent.trim()).map(c => {
                            const t=c.querySelector('.cell-content');return {cell:c.dataset.cell,text:c.textContent,height:t.getBoundingClientRect().height,available:c.clientHeight-2};
                            }).filter(x => x.height > x.available + 2)""")
                        overflows.extend(extra)
                    assert not overflows, overflows[:3]
                    page.locator(".sheet-tabs button").first.click()
                    checks.append("All worksheet tabs contain zero vertically clipped text cells")
                    (a.output / "grid-overflows.json").write_text(
                        json.dumps(overflows, ensure_ascii=False, indent=2)
                    )
                    page.screenshot(path=str(a.output / "grid-desktop.png"), full_page=True)
                    page.locator("#sheet-toggle").click()
                    expect(page.locator("#output-image")).to_be_visible()
                    expect(page.locator("#sheet-preview")).to_be_hidden()
                    page.locator("#sheet-toggle").click()
                    expect(page.locator("#sheet-preview")).to_be_visible()
                    checks.append("Grid and actual-file print preview switch both ways")
                    # Configuration change must invalidate approval until regenerated.
                    page.locator("#numbers").select_option("text")
                    expect(page.locator("#accept-export")).to_be_disabled()
                    page.locator("#numbers").select_option("auto")
                    expect(page.locator("#accept-export")).to_be_enabled()
                    checks.append("Changed output options cannot approve the stale preview")
                    jobs = ctx.request.get(base + "/api/studio/jobs").json()
                    job = jobs[0]
                    assert (
                        ctx.request.get(base + f"/api/studio/jobs/{job['id']}/download").status
                        == 409
                    )
                    before = job["export"]["options"]["grid_sensitivity"]
                    page.locator("#output-errors button").filter(has_text="Oszlopok").click()
                    page.locator("#retry-export").click()
                    expect(page.locator("#output-notes")).to_contain_text(
                        f"rács {(before + 1) % 3 + 1}"
                    )
                    expect(page.locator("#accept-export")).to_be_enabled()
                    with page.expect_download() as event:
                        page.locator("#accept-export").click()
                    path = a.output / "downloaded.xlsx"
                    event.value.save_as(path)
                    job = ctx.request.get(base + "/api/studio/jobs").json()[0]
                    assert hashlib.sha256(path.read_bytes()).hexdigest() == job["export"]["sha256"]
                    checks.append(
                        "Export retry changes geometry; approval automatically downloads exact SHA256 artifact"
                    )
                    page.locator("#choose-format").click()
                    page.locator('[data-format="png"]').click()
                    expect(page.locator("#accept-export")).to_be_enabled()
                    expect(page.locator("#output-image")).to_be_visible()
                    with page.expect_download() as event:
                        page.locator("#accept-export").click()
                    pngname = event.value.suggested_filename
                    assert pngname == ("document.zip" if a.sample else "document.png")
                    checks.append(
                        "PNG format has actual image preview and correct PNG / multi-page ZIP filename"
                    )
                    with page.expect_download() as event:
                        page.locator("#batch").click()
                    event.value.save_as(a.output / "batch.zip")
                    checks.append("Accepted batch download")
                    page.reload()
                    expect(page.locator("#jobs .job")).to_have_count(1)
                    expect(page.locator("#accept-input")).to_be_enabled()
                    page.set_viewport_size({"width": 390, "height": 844})
                    assert page.evaluate(
                        "document.documentElement.scrollWidth <= window.innerWidth + 1"
                    )
                    page.locator("#accept-input").click()
                    expect(page.locator("#format-picker")).to_be_visible()
                    assert page.evaluate(
                        'document.querySelector("#format-picker").getBoundingClientRect().right <= innerWidth'
                    )
                    page.screenshot(path=str(a.output / "mobile.png"), full_page=True)
                    checks.append("Reload persistence, 390px responsive page and format picker")
                    assert not errors, errors
                    (a.output / "report.json").write_text(
                        json.dumps(
                            {"checks": checks, "javascript_errors": errors},
                            ensure_ascii=False,
                            indent=2,
                        )
                    )
                    print(json.dumps({"checks_passed": len(checks), "javascript_errors": errors}))
                    browser.close()
            finally:
                process.terminate()
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


if __name__ == "__main__":
    main()
