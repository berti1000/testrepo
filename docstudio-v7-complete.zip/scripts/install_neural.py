"""Pinned official-converted PaddleOCR models; verified offline runtime assets."""

import hashlib
import json
import os
import urllib.request
from pathlib import Path

BASE = "https://www.modelscope.cn/models/RapidAI/RapidOCR/resolve/v3.4.0/"
MODELS = {
    "det.onnx": (
        BASE + "onnx/PP-OCRv5/det/ch_PP-OCRv5_mobile_det.onnx",
        "4d97c44a20d30a81aad087d6a396b08f786c4635742afc391f6621f5c6ae78ae",
    ),
    "rec.onnx": (
        BASE + "onnx/PP-OCRv5/rec/latin_PP-OCRv5_rec_mobile_infer.onnx",
        "b20bd37c168a570f583afbc8cd7925603890efbcdc000a59e22c269d160b5f5a",
    ),
}


def install():
    root = Path(os.getenv("NEURAL_MODEL_DIR", "models/neural"))
    root.mkdir(parents=True, exist_ok=True)
    for name, (url, digest) in MODELS.items():
        path = root / name
        if path.exists() and hashlib.sha256(path.read_bytes()).hexdigest() == digest:
            continue
        with urllib.request.urlopen(url, timeout=120) as response:
            data = response.read(150_000_000)
        if hashlib.sha256(data).hexdigest() != digest:
            raise ValueError("SHA256 mismatch: " + name)
        path.write_bytes(data)
        print("Verified", name, len(data), flush=True)
    import onnxruntime as ort

    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1
    session = ort.InferenceSession(str(root / "rec.onnx"), opts, providers=["CPUExecutionProvider"])
    chars = session.get_modelmeta().custom_metadata_map.get("character")
    if not chars:
        raise ValueError("Missing embedded character dictionary")
    (root / "latin.txt").write_text(chars, encoding="utf-8")
    (root / "manifest.json").write_text(
        json.dumps({n: {"url": u, "sha256": h} for n, (u, h) in MODELS.items()}, indent=2)
    )


if __name__ == "__main__":
    install()
