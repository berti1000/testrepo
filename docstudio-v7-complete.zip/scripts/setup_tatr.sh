#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DOCSTUDIO_ROOT"
source .venv/bin/activate
python -m pip install torch==2.7.1 torchvision==0.22.1 --index-url https://download.pytorch.org/whl/cpu
python -m pip install transformers==4.57.3 timm==1.0.22 safetensors==0.7.0
python scripts/install_tatr.py
