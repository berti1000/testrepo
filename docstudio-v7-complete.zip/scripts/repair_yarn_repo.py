"""Disable only Yarn APT entries after its missing-key error, keeping a backup."""

from pathlib import Path
import re
import sys


def repair(text, deb822=False):
    if not deb822:
        return "".join(
            "# DocStudio: Yarn kulcshiba miatt kikapcsolva\n# " + line
            if re.match(r"^\s*deb(?:-src)?\s", line)
            and re.search(r"https?://dl\.yarnpkg\.com(?:/|\s)", line)
            else line
            for line in text.splitlines(keepends=True)
        )
    blocks = re.split(r"(\n\s*\n)", text)
    for i, block in enumerate(blocks):
        match = re.search(r"(?im)^URIs:[^\n]*(?:\n[ \t]+[^\n]*)*", block)
        if not match:
            continue
        uris = match.group().split(":", 1)[1].split()
        kept = [v for v in uris if not re.match(r"https?://dl\.yarnpkg\.com(?:/|$)", v)]
        if len(kept) == len(uris):
            continue
        if kept:
            block = block[: match.start()] + "URIs: " + " ".join(kept) + block[match.end() :]
        elif re.search(r"(?im)^Enabled:", block):
            block = re.sub(r"(?im)^Enabled:.*$", "Enabled: no", block)
        else:
            block += "\nEnabled: no"
        blocks[i] = block
    return "".join(blocks)


def main(root=Path("/etc/apt")):
    changed = []
    files = (
        [root / "sources.list"]
        + sorted((root / "sources.list.d").glob("*.list"))
        + sorted((root / "sources.list.d").glob("*.sources"))
    )
    for path in files:
        if not path.is_file():
            continue
        old = path.read_text()
        new = repair(old, path.suffix == ".sources")
        if old == new:
            continue
        backup = path.with_name(path.name + ".docstudio-backup")
        if not backup.exists():
            backup.write_text(old)
        path.write_text(new)
        changed.append(str(path))
    print(
        "Csak a Yarn tároló bejegyzései módosultak; biztonsági másolat: *.docstudio-backup"
        if changed
        else "Nem találtam aktív Yarn-bejegyzést."
    )
    return 0 if changed else 1


if __name__ == "__main__":
    sys.exit(main())
