"""Reproducible real-OCR stress suite. Generated text is the ground truth.

This is a regression suite, not a claim of accuracy on arbitrary user documents.
Outputs include metrics, visible glyph PDFs and source-preserving pixel checks.
"""

import argparse
import io
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2
import fitz
import numpy as np
from PIL import Image, ImageFilter
from dotenv import load_dotenv
from reconstructor.extract import read_document
from reconstructor.model import Options
from reconstructor.render import font_path, preserved_pdf, reconstructed_pdf, page_png
from reconstructor.export import plain_text

LINES = [
    "DOKUMENTUMFELISMERÉSI TESZT",
    "Árvíztűrő tükörfúrógép és szerkeszthető magyar szöveg.",
    "A jó minőségű szkennelés segíti a pontos betűfelismerést.",
    "Az eredeti képet változatlanul őrizzük meg a PDF fájlban.",
    "A felismert szavak külön is javíthatók és exportálhatók.",
    "Sorszám: 0012345678    Év: 2026    Összeg: 347.25 EUR",
    "A könyvelési azonosító elején lévő nullák megmaradnak.",
    "Különböző tájolás, enyhe ferdeség, árnyék és tömörítés.",
    "The reconstructed document contains real visible letters.",
    "Every original pixel remains available in the faithful copy.",
    "Tesztdokumentum, nem valódi számla és nem üzleti adat.",
]


def tokens(text):
    return re.findall(r"\w+(?:[.,]\d+)?", text.lower())


def distance(a, b):
    row = list(range(len(b) + 1))
    for i, left in enumerate(a, 1):
        nxt = [i]
        for j, right in enumerate(b, 1):
            nxt.append(min(nxt[-1] + 1, row[j] + 1, row[j - 1] + (left != right)))
        row = nxt
    return row[-1]


def sample():
    with fitz.open() as doc:
        page = doc.new_page(width=595, height=842)
        page.insert_font(fontname="Sample", fontfile=font_path())
        for i, line in enumerate(LINES):
            page.insert_text((40, 65 + i * 36), line, fontname="Sample", fontsize=12)
        pix = page.get_pixmap(dpi=200, alpha=False)
        return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def variants(image):
    yield "clean", image, False
    for angle in (90, 180, 270):
        yield f"rotate_{angle}", image.rotate(angle, expand=True, fillcolor="white"), False
    yield "skew_4", image.rotate(4, expand=True, fillcolor="white"), False
    stream = io.BytesIO()
    image.save(stream, format="JPEG", quality=55)
    yield "jpeg_55", Image.open(io.BytesIO(stream.getvalue())).convert("RGB"), False
    yield "blur_1", image.filter(ImageFilter.GaussianBlur(1)), False
    arr = np.array(image)
    gradient = np.linspace(0.54, 1.0, image.width)[None, :, None]
    yield "shadow", Image.fromarray((arr * gradient).astype("uint8")), False
    w, h = image.size
    points = np.float32([[100, 150], [w - 30, 40], [w + 80, h + 20], [30, h + 160]])
    transform = cv2.getPerspectiveTransform(
        np.float32([[0, 0], [w - 1, 0], [w - 1, h - 1], [0, h - 1]]), points
    )
    photo = cv2.warpPerspective(arr, transform, (w + 190, h + 240), borderValue=(65, 65, 65))
    yield "perspective", Image.fromarray(photo), True


def main():
    load_dotenv()
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=Path("test-results/scan-benchmark"))
    parser.add_argument("--cases", nargs="*")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    expected = tokens(" ".join(LINES))
    results = []
    for name, image, rectify in variants(sample()):
        if args.cases and name not in args.cases:
            continue
        folder = args.output / name
        folder.mkdir(exist_ok=True)
        source = folder / "source.png"
        image.save(source, dpi=(200, 200))
        started = time.monotonic()
        document = read_document(
            source.read_bytes(), source.name, Options(dpi=200, perspective=rectify)
        )
        extracted = plain_text(document).decode("utf-8")
        # Plain-text export includes a page separator, which is not OCR content.
        recognized = " ".join(w.text for w in document.pages[0].words)
        errors = distance(expected, tokens(recognized))
        faithful = preserved_pdf(document)
        rebuilt = reconstructed_pdf(document)
        with fitz.open(stream=faithful, filetype="pdf") as pdf:
            embedded = Image.open(
                io.BytesIO(pdf.extract_image(pdf[0].get_images()[0][0])["image"])
            ).convert("RGB")
            identical = bool(np.array_equal(np.array(embedded), np.array(image)))
        with fitz.open(stream=rebuilt, filetype="pdf") as pdf:
            visible = sum(
                len(span["chars"]) for span in pdf[0].get_texttrace() if span["type"] == 0
            )
        item = dict(
            case=name,
            words=len(document.pages[0].words),
            reference_tokens=len(expected),
            word_errors=errors,
            word_error_rate=round(errors / len(expected), 4),
            source_pixels_equal=identical,
            visible_rebuilt_glyphs=visible,
            seconds=round(time.monotonic() - started, 2),
            diagnostics=document.pages[0].diagnostics,
        )
        results.append(item)
        (folder / "faithful.pdf").write_bytes(faithful)
        (folder / "reconstructed.pdf").write_bytes(rebuilt)
        (folder / "reconstructed.png").write_bytes(page_png(document, dpi=120))
        (folder / "recognized.txt").write_text(extracted)
        (args.output / "metrics.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
        print(
            json.dumps({k: v for k, v in item.items() if k != "diagnostics"}, ensure_ascii=False),
            flush=True,
        )
    failures = [
        r
        for r in results
        if not r["source_pixels_equal"]
        or r["word_error_rate"] > 0.12
        or r["visible_rebuilt_glyphs"] < 100
    ]
    if failures:
        raise SystemExit("Regression gate failed: " + ", ".join(r["case"] for r in failures))


if __name__ == "__main__":
    main()
