"""Real Chromium + Uvicorn review-loop test. Optional --sample private scan; screenshots stay local."""

import argparse
import hashlib
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv
from playwright.sync_api import sync_playwright, expect
from tests.fixtures import make_invoice, make_ocr_image


def main():
    load_dotenv(ROOT / ".env")
    p = argparse.ArgumentParser()
    p.add_argument("--sample", type=Path)
    p.add_argument("--output", type=Path, default=ROOT / "test-results/studio-browser")
    a = p.parse_args()
    a.output = a.output.resolve()
    a.output.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="studio-e2e-") as tmp:
        tmp = Path(tmp)
        scan = a.sample.resolve() if a.sample else tmp / "scan.png"
        if not a.sample:
            scan.write_bytes(make_ocr_image())
        native = tmp / "native.pdf"
        native.write_bytes(make_invoice(rows=3, merged=False))
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        env = dict(
            os.environ,
            JOB_DIR=str(tmp / "jobs"),
            APP_ENV="development",
            APP_ACCESS_PASSWORD="",
            APP_SESSION_SECRET="test-browser-secret-" * 4,
            COOKIE_SECURE="0",
            VISION_MODEL="",
        )
        for key in ["TESSDATA_PREFIX", "NEURAL_MODEL_DIR", "TATR_MODEL_DIR"]:
            if env.get(key):
                env[key] = str(Path(env[key]).resolve())
        base = f"http://127.0.0.1:{port}"
        errors = []
        checks = []
        with (a.output / "server.log").open("w") as log:
            server = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "web.main:app",
                    "--host",
                    "127.0.0.1",
                    "--port",
                    str(port),
                ],
                cwd=ROOT,
                env=env,
                stdout=log,
                stderr=log,
            )
            try:
                for _ in range(100):
                    try:
                        urllib.request.urlopen(base + "/health", timeout=1).close()
                        break
                    except OSError:
                        if server.poll() is not None:
                            raise RuntimeError("Server startup failed")
                        time.sleep(0.1)
                with sync_playwright() as pw:
                    browser = pw.chromium.launch(headless=True, args=["--no-sandbox"])
                    ctx = browser.new_context(viewport={"width": 1560, "height": 1050})
                    page = ctx.new_page()
                    page.on("pageerror", lambda e: errors.append(str(e)))
                    page.goto(base)
                    page.set_default_timeout(120000)
                    expect(page.locator('#engine option[value="paddle"]')).to_be_enabled()
                    page.locator(".files details summary").click()
                    page.locator("#orientation").uncheck()
                    page.locator("#upload").set_input_files([str(scan), str(native)])
                    expect(page.locator("#accept-input")).to_be_enabled(timeout=180000)
                    expect(page.locator("#word-layer rect").first).to_be_visible()
                    checks.append("multi-upload and neural scan canvas")
                    page.locator('[data-view="overlay"]').click()
                    page.locator("#opacity").fill("35")
                    page.locator('[data-view="reconstructed"]').click()
                    page.locator("#word-layer rect").first.click(force=True)
                    page.locator("#edit-text").fill("ELLENŐRZÖTT")
                    page.locator("#save-word").click()
                    expect(page.locator("#revision-select option")).to_have_count(2)
                    page.locator("#revision-select").select_option("1")
                    page.locator("#restore").click()
                    expect(page.locator("#revision-select")).to_have_value("1")
                    expect(page.locator("#accept-input")).to_be_enabled()
                    checks.append("word edit and revision restore")
                    page.locator("#input-errors button").filter(has_text="Összefolyt").click()
                    page.locator("#retry").click()
                    expect(page.locator("#revision-select option")).to_have_count(3, timeout=180000)
                    expect(page.locator("#accept-input")).to_be_enabled()
                    checks.append("input error strategy rerun")
                    page.screenshot(path=str(a.output / "input-canvas.png"), full_page=True)
                    page.locator("#accept-input").click()
                    expect(page.locator("#format-picker")).to_be_visible()
                    page.locator('[data-format="docx"]').click()
                    expect(page.locator("#output-view")).to_be_visible()
                    expect(page.locator("#accept-export")).to_be_enabled(timeout=180000)
                    expect(page.locator("#output-image")).to_be_visible()
                    expect(page.locator("#download")).to_be_hidden()
                    page.locator("#output-errors button").filter(has_text="Szétcsúszott").click()
                    page.locator("#retry-export").click()
                    expect(page.locator("#word-mode")).to_have_value("precise", timeout=180000)
                    expect(page.locator("#accept-export")).to_be_enabled()
                    page.locator("#accept-export").click()
                    expect(page.locator("#download")).to_be_visible()
                    with page.expect_download() as dl:
                        page.locator("#download").click()
                    downloaded = dl.value
                    target = a.output / "downloaded.docx"
                    downloaded.save_as(target)
                    jobs = ctx.request.get(base + "/api/studio/jobs").json()
                    j = next(j for j in jobs if j["name"] == scan.name)
                    assert hashlib.sha256(target.read_bytes()).hexdigest() == j["export"]["sha256"]
                    checks.append(
                        "actual DOCX preview, export retry, acceptance and exact download"
                    )
                    page.locator("#format").select_option("xlsx")
                    page.locator("#generate").click()
                    expect(page.locator("#accept-export")).to_be_enabled(timeout=180000)
                    page.locator("#output-errors button").filter(has_text="Számok").click()
                    page.locator("#retry-export").click()
                    expect(page.locator("#numbers")).to_have_value("hu", timeout=180000)
                    expect(page.locator("#accept-export")).to_be_enabled()
                    expect(page.locator("#sheet-preview .sheet-grid")).to_be_visible()
                    page.locator("#accept-export").click()
                    checks.append("actual XLSX preview and numeric fallback")
                    with page.expect_download() as dl:
                        page.locator("#batch").click()
                    dl.value.save_as(a.output / "batch.zip")
                    checks.append("accepted export batch ZIP")
                    page.reload()
                    expect(page.locator("#jobs .job")).to_have_count(2)
                    checks.append("reload persistence")
                    page.set_viewport_size({"width": 390, "height": 844})
                    page.screenshot(path=str(a.output / "mobile.png"), full_page=True)
                    assert page.evaluate(
                        "document.documentElement.scrollWidth<=window.innerWidth+1"
                    )
                    checks.append("390px responsive viewport")
                    assert not errors, errors
                    (a.output / "report.json").write_text(
                        json.dumps(
                            {"checks": checks, "javascript_errors": errors, "sample": scan.name},
                            indent=2,
                        )
                    )
                    print(json.dumps(checks), flush=True)
                    browser.close()
            finally:
                server.terminate()
                try:
                    server.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    server.kill()
                    server.wait()


if __name__ == "__main__":
    main()
