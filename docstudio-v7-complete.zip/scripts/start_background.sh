#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DOCSTUDIO_ROOT"
mkdir -p .local
if [[ -f .local/server.pid ]] && kill -0 "$(cat .local/server.pid)" 2>/dev/null; then
  exit 0
fi
nohup bash scripts/start.sh > .local/server.log 2>&1 < /dev/null &
echo "$!" > .local/server.pid
