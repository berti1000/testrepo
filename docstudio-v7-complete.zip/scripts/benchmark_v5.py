"""Measured OCR benchmark. Synthetic reference text is known; real scans are not ground truth."""

import argparse
import io
import json
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from dotenv import load_dotenv

load_dotenv(ROOT / ".env")
import fitz
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
from tests.fixtures import make_ocr_image
from studio.ir import AssetStore
from studio.pipeline import ingest
from studio.output.service import generate, OutputOptions
from studio.ir import to_runtime
from reconstructor.export import plain_text


def edit_distance(a, b):
    row = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        nxt = [i]
        for j, y in enumerate(b, 1):
            nxt.append(min(nxt[-1] + 1, row[j] + 1, row[j - 1] + (x != y)))
        row = nxt
    return row[-1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "test-results/v5-benchmark")
    parser.add_argument("--engine", default="paddle", choices=["paddle", "tesseract"])
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    reference = "INVOICE TEST 2026 Amount 347.25 EUR Reference 0012345678 Arvíztűrő tükörfúrógép"
    source = Image.open(io.BytesIO(make_ocr_image())).convert("RGB")
    rng = np.random.default_rng(42)
    noisy = np.clip(
        np.asarray(source).astype(float) + rng.normal(0, 7, np.asarray(source).shape), 0, 255
    ).astype("uint8")
    cases = {
        "clean": source,
        "low-contrast": ImageEnhance.Contrast(source).enhance(0.4),
        "noise": Image.fromarray(noisy),
        "blur": source.filter(ImageFilter.GaussianBlur(0.7)),
        "skew": source.rotate(2, expand=True, fillcolor="white"),
    }
    cases.update(
        {f"rotation-{n}": source.rotate(n, expand=True, fillcolor="white") for n in [90, 180, 270]}
    )
    report = []
    for name, im in cases.items():
        folder = args.output / name
        folder.mkdir(exist_ok=True)
        b = io.BytesIO()
        im.save(b, format="PNG", dpi=(300, 300))
        (folder / "source.png").write_bytes(b.getvalue())
        assets = AssetStore(folder / "assets")
        started = time.monotonic()
        ir = ingest(
            b.getvalue(),
            name + ".png",
            assets,
            {"engine": args.engine, "orientation": True, "deskew": True},
        )
        ir.revision = 1
        (folder / "ir.json").write_bytes(ir.dump())
        hyp = " ".join(plain_text(to_runtime(ir, assets)).decode().split())
        ref_tokens = reference.casefold().split()
        hyp_tokens = hyp.casefold().split()
        rec = {
            "case": name,
            "engine": args.engine,
            "seconds": round(time.monotonic() - started, 2),
            "reference": reference,
            "recognized": hyp,
            "wer": edit_distance(ref_tokens, hyp_tokens) / len(ref_tokens),
            "cer": edit_distance(reference.casefold(), hyp.casefold()) / len(reference),
            "exact_amount": "347.25" in hyp,
            "exact_id": "0012345678" in hyp,
            "words": len(hyp_tokens),
            "review_disagreements": sum(
                len(w.alternatives) > 0 for pg in ir.pages for w in pg.words
            ),
        }
        generate(ir, assets, OutputOptions(format="pdf"), folder / "pdf")
        with fitz.open(folder / "pdf/document.pdf") as p:
            rec["visible_glyph_runs"] = sum(t["type"] == 0 for t in p[0].get_texttrace())
        report.append(rec)
        print(json.dumps(rec, ensure_ascii=False), flush=True)
        (args.output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    if not all(r["visible_glyph_runs"] > 0 for r in report):
        raise SystemExit("Missing visible reconstructed text")
    if not all(r["exact_amount"] and r["exact_id"] for r in report):
        raise SystemExit("Regression: known amount or leading-zero ID was not preserved")
    if any(r["wer"] > 0.2 or r["cer"] > 0.06 for r in report):
        raise SystemExit("Regression: WER/CER exceeded this fixture's error budget")


if __name__ == "__main__":
    main()
