"""Exercise supplied files locally. Private inputs/results are never uploaded."""

import argparse
from collections import Counter
import io
import json
from pathlib import Path
import sys
import time
import zipfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import fitz  # noqa: E402
import openpyxl  # noqa: E402
from studio.ir import AssetStore, to_runtime  # noqa: E402
from studio.pipeline import ingest  # noqa: E402
from studio.output import excel, word  # noqa: E402
from studio.office import convert_pdf  # noqa: E402
from reconstructor.render import reconstructed_pdf  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("files", type=Path, nargs="+")
    parser.add_argument("--output", type=Path, default=Path("test-results/v7-samples"))
    parser.add_argument(
        "--engine", choices=["auto", "native", "paddle", "tesseract"], default="auto"
    )
    parser.add_argument("--with-office", action="store_true")
    args = parser.parse_args()
    reports = []
    for number, src in enumerate(args.files, 1):
        folder = args.output / f"{number:02}-{src.stem}"
        folder.mkdir(parents=True, exist_ok=True)
        assets = AssetStore(folder / "assets")
        start = time.monotonic()
        ir = ingest(src.read_bytes(), src.name, assets, {"engine": args.engine})
        seconds = round(time.monotonic() - start, 2)
        doc = to_runtime(ir, assets)
        (folder / "ir.json").write_bytes(ir.dump())
        pdf = reconstructed_pdf(doc)
        (folder / "reconstructed.pdf").write_bytes(pdf)
        with fitz.open(stream=pdf, filetype="pdf") as rendered:
            for i, page in enumerate(rendered):
                page.get_pixmap(matrix=fitz.Matrix(1.3, 1.3)).save(
                    str(folder / f"page-{i + 1:03}.png")
                )
        data = excel.export(doc)
        (folder / "document.xlsx").write_bytes(data)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            assert not any("comment" in n.lower() for n in z.namelist())
        wb = openpyxl.load_workbook(io.BytesIO(data), rich_text=True)
        assert all(
            c.comment is None and not c.alignment.shrinkToFit
            for ws in wb
            for row in ws
            for c in row
        )
        assert all(d.height >= 18 for ws in wb for d in ws.row_dimensions.values())
        result = dict(
            file=src.name,
            seconds=seconds,
            pages=len(ir.pages),
            words=sum(len(p.words) for p in ir.pages),
            sheets=[dict(rows=s.max_row, columns=s.max_column) for s in wb],
            comments=0,
            diagnostics=[p.diagnostics for p in ir.pages],
        )
        if args.with_office:
            xpdf = convert_pdf(data, ".xlsx")
            (folder / "excel-preview.pdf").write_bytes(xpdf)
            with fitz.open(stream=xpdf, filetype="pdf") as rendered:
                result["excel_print_pages"] = len(rendered)
                for i, page in enumerate(rendered):
                    page.get_pixmap(matrix=fitz.Matrix(1.3, 1.3)).save(
                        str(folder / f"excel-{i + 1:03}.png")
                    )
            data = word.export(doc)
            (folder / "document.docx").write_bytes(data)
            wpdf = convert_pdf(data, ".docx")
            (folder / "word-preview.pdf").write_bytes(wpdf)
            with fitz.open(stream=wpdf, filetype="pdf") as rendered:
                source = Counter(
                    c
                    for p in doc.pages
                    for w in p.words
                    if not w.visual_artifact or w.reviewed
                    for c in w.text
                    if not c.isspace()
                )
                actual = Counter(c for p in rendered for c in p.get_text() if not c.isspace())
                result["word_character_difference"] = dict(
                    missing=dict(source - actual), extra=dict(actual - source)
                )
                result["word_pages"] = len(rendered)
        reports.append(result)
        (folder / "report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2))
        args.output.mkdir(parents=True, exist_ok=True)
        (args.output / "report.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2))
        print(
            json.dumps({k: v for k, v in result.items() if k != "diagnostics"}, ensure_ascii=False),
            flush=True,
        )


if __name__ == "__main__":
    main()
