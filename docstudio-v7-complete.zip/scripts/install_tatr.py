"""Pinned official Microsoft weights; safetensors only, no remote Python code."""

import os
import urllib.request
from pathlib import Path

REVISIONS = {
    "detection": "2357cbe2b5a5d1c03e54f32764f06058933b65ab",
    "structure": "f4d4bdc85c3fe4b1fa49658882a5d38bbdd0f343",
}


def install():
    for kind, rev in REVISIONS.items():
        root = Path(os.getenv("TATR_MODEL_DIR", "models/tatr")) / kind
        root.mkdir(parents=True, exist_ok=True)
        repo = "microsoft/table-transformer-" + (
            "detection" if kind == "detection" else "structure-recognition"
        )
        for name in ("config.json", "preprocessor_config.json", "model.safetensors"):
            target = root / name
            if target.is_file() and target.stat().st_size > 100:
                continue
            temp = target.with_suffix(".part")
            with (
                urllib.request.urlopen(
                    f"https://huggingface.co/{repo}/resolve/{rev}/{name}", timeout=180
                ) as src,
                temp.open("wb") as dst,
            ):
                while chunk := src.read(1024 * 1024):
                    dst.write(chunk)
            temp.replace(target)
            print(kind, name, target.stat().st_size, flush=True)


if __name__ == "__main__":
    install()
