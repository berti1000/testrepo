#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DOCSTUDIO_ROOT"
DOCSTUDIO_PYTHON="${DOCSTUDIO_PYTHON:-python3}"
if command -v python3.11 >/dev/null 2>&1 && [[ "$DOCSTUDIO_PYTHON" == "python3" ]]; then
  DOCSTUDIO_PYTHON=python3.11
fi
if ! "$DOCSTUDIO_PYTHON" -c 'import sys; assert (3,11) <= sys.version_info[:2] <= (3,12)'; then
  printf 'Python 3.11 vagy 3.12 szükséges. Codespaces: Command Palette → Codespaces: Rebuild Container (a csomag .devcontainer beállításával).\n' >&2
  exit 1
fi
if [[ -x .venv/bin/python ]] && ! .venv/bin/python -c 'import sys; assert (3,11) <= sys.version_info[:2] <= (3,12)'; then
  DOCSTUDIO_BACKUP=".venv.previous-$(date +%Y%m%d-%H%M%S)"
  mv -- .venv "$DOCSTUDIO_BACKUP"
  printf 'A nem kompatibilis környezet megőrizve: %s\n' "$DOCSTUDIO_BACKUP"
fi
"$DOCSTUDIO_PYTHON" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.txt -r requirements-dev.txt
.venv/bin/python scripts/install_models.py --destination models/tessdata
.venv/bin/python scripts/install_neural.py
.venv/bin/python - <<'PY'
from pathlib import Path
import secrets
path = Path('.env')
if not path.exists():
    path.write_text(Path('.env.example').read_text(), encoding='utf-8')
text = path.read_text()
text = text.replace('APP_SESSION_SECRET=\n', 'APP_SESSION_SECRET=' + secrets.token_hex(32) + '\n')
path.write_text(text, encoding='utf-8')
path.chmod(0o600)
Path('.local').mkdir(exist_ok=True)
PY
if [[ "${INSTALL_TATR:-0}" == "1" ]]; then bash scripts/setup_tatr.sh; fi
.venv/bin/python scripts/doctor.py
printf 'Kész. Indítás: bash scripts/start.sh\n'
