#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$DOCSTUDIO_ROOT"
if [[ ! -x .venv/bin/python ]]; then
  printf 'Előbb futtasd: bash scripts/setup.sh\n' >&2
  exit 1
fi
exec .venv/bin/python -m uvicorn web.main:app --env-file .env --host 0.0.0.0 --port "${PORT:-8080}" --workers 1
