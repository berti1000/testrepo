#!/usr/bin/env bash
set -euo pipefail
DOCSTUDIO_ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
DOCSTUDIO_PID_FILE="$DOCSTUDIO_ROOT/.local/server.pid"
[[ -f "$DOCSTUDIO_PID_FILE" ]] || exit 0
DOCSTUDIO_PID="$(cat "$DOCSTUDIO_PID_FILE")"
[[ "$DOCSTUDIO_PID" =~ ^[0-9]+$ ]] || exit 1
if kill -0 "$DOCSTUDIO_PID" 2>/dev/null; then
  # A reused PID must not stop another project or application.
  if [[ "$(readlink "/proc/$DOCSTUDIO_PID/cwd")" != "$DOCSTUDIO_ROOT" ]] || \
     ! tr '\0' ' ' < "/proc/$DOCSTUDIO_PID/cmdline" | grep -q 'uvicorn web.main:app'; then
    printf 'A PID már nem ehhez a DocStudio szerverhez tartozik; nem állítottam le.\n' >&2
    exit 1
  fi
  kill "$DOCSTUDIO_PID"
  for ((DOCSTUDIO_WAIT=0; DOCSTUDIO_WAIT<20; DOCSTUDIO_WAIT++)); do
    kill -0 "$DOCSTUDIO_PID" 2>/dev/null || break
    sleep .25
  done
fi
rm -f -- "$DOCSTUDIO_PID_FILE"
