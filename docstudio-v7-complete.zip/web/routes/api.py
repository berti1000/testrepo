"""Session-owned jobs, inspection, correction, optional Vision and exports."""

from copy import deepcopy
from pathlib import Path
import io
import math
import os
import tempfile
import zipfile
from fastapi import APIRouter, File, Form, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, JSONResponse, Response
from pydantic import BaseModel, Field
from starlette.background import BackgroundTask
from reconstructor.geometry import clean
from reconstructor.layout import audit_page, manual_table
from reconstructor.export import table_matrix
from reconstructor.render import page_png
from .. import jobs
from ..security import check_origin, require_access

router = APIRouter()


class WordChange(BaseModel):
    text: str = Field(max_length=1000)
    reviewed: bool = False
    expected_text: str | None = Field(default=None, max_length=1000)


class ManualTableChange(BaseModel):
    bbox: list[float] = Field(min_length=4, max_length=4)
    x_edges: list[float] = Field(max_length=100)
    y_edges: list[float] = Field(max_length=1000)


def owned_job(request: Request, job_id: str) -> jobs.Job:
    owner = require_access(request)
    job = jobs.get(job_id, owner)
    if job is None:
        raise HTTPException(404, "Nem talalhato vagy nem a tied a feldolgozas.")
    return job


def ready_doc(job: jobs.Job):
    if job.state != "done" or job.document is None:
        raise HTTPException(409, "A feldolgozas meg nem keszult el.")
    return job.document


def require_page(doc, page_number: int):
    if not 1 <= page_number <= len(doc.pages):
        raise HTTPException(404, "Az oldal nem talalhato.")
    return doc.pages[page_number - 1]


@router.post("/api/jobs")
async def upload(
    request: Request,
    files: list[UploadFile] = File(...),
    ocr: str = Form("auto"),
    languages: str = Form("hun+eng"),
    dpi: int = Form(300),
    psm: int = Form(3),
    deskew: bool = Form(True),
    enhance: bool = Form(False),
    quality: str = Form("accurate"),
    orientation: bool = Form(True),
    rotation: int = Form(0),
    perspective: bool = Form(False),
    raster_lines: bool = Form(True),
    scan_graphics: bool = Form(True),
    visual_fallback: bool = Form(False),
    unruled_tables: bool = Form(True),
    gap_factor: float = Form(0.95),
    max_pages: int = Form(30),
    numbers: str = Form("text"),
    password: str = Form(""),
):
    check_origin(request)
    owner = require_access(request)
    if not 1 <= len(files) <= 10:
        raise HTTPException(400, "Egyszerre 1-10 fajl engedelyezett.")
    if (
        quality not in ("fast", "accurate")
        or rotation not in (0, 90, 180, 270)
        or ocr not in ("auto", "always", "never")
        or numbers not in ("text", "hu", "en")
        or dpi not in (150, 200, 250, 300, 350, 400, 450)
        or psm not in (3, 4, 6, 11)
        or not 1 <= max_pages <= 60
        or not 0.45 <= gap_factor <= 2.0
        or not languages
        or len(languages) > 40
        or not all(part.isalnum() and part.isascii() for part in languages.split("+"))
        or len(password) > 500
    ):
        raise HTTPException(422, "Ervenytelen feldolgozasi beallitas.")
    if len(files) > jobs.free_slots():
        raise HTTPException(429, "A feldolgozasi sor jelenleg megtelt.")
    settings = dict(
        quality=quality,
        orientation=orientation,
        rotation=rotation,
        perspective=perspective,
        ocr=ocr,
        languages=languages,
        dpi=dpi,
        psm=psm,
        deskew=deskew,
        enhance=enhance,
        max_pages=max_pages,
        numbers=numbers,
        raster_lines=raster_lines,
        scan_graphics=scan_graphics,
        visual_fallback=visual_fallback,
        unruled_tables=unruled_tables,
        gap_factor=gap_factor,
        password=password,
    )
    created = []
    try:
        for file in files:
            created.append(await jobs.create(file, owner))
    except (ValueError, OverflowError) as exc:
        for job in created:
            jobs.discard_unsubmitted(job)
        raise HTTPException(400, str(exc)) from exc
    for job in created:
        jobs.submit(job, settings)
    return JSONResponse(
        {"jobs": [j.public() for j in created]}, headers={"Cache-Control": "no-store"}
    )


@router.get("/api/jobs/{job_id}")
def status(request: Request, job_id: str):
    job = owned_job(request, job_id)
    with job.lock:
        return JSONResponse(job.public(), headers={"Cache-Control": "no-store"})


@router.get("/api/jobs/{job_id}/pages")
def pages(request: Request, job_id: str):
    job = owned_job(request, job_id)
    with job.lock:
        doc = ready_doc(job)
        return JSONResponse(
            {
                "revision": job.revision,
                "filename": doc.filename,
                "pages": [
                    {
                        "number": p.number,
                        "width": p.width,
                        "height": p.height,
                        "words": len(p.words),
                        "tables": sum(b.kind == "table" for b in p.blocks),
                        "mode": p.mode,
                        "warnings": p.warnings[:12],
                        "diagnostics": p.diagnostics,
                        "low_confidence": sum(w.needs_review for w in p.words),
                    }
                    for p in doc.pages
                ],
            },
            headers={"Cache-Control": "no-store"},
        )


@router.get("/api/jobs/{job_id}/pages/{page_number}/preview/{kind}")
def preview(request: Request, job_id: str, page_number: int, kind: str):
    job = owned_job(request, job_id)
    if kind not in ("original", "reconstructed", "source"):
        raise HTTPException(404, "Nincs ilyen elonezet.")
    with job.lock:
        doc = ready_doc(job)
        page = require_page(doc, page_number)
        dpi = max(120, math.ceil(72 * 1400 / page.width))
        try:
            data = page_png(
                doc, page_number, dpi=dpi, original=(kind == "original"), source=(kind == "source")
            )
        except Exception as exc:
            raise HTTPException(422, f"Elonezet hiba: {exc}") from exc
    return Response(
        data,
        media_type="image/png",
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


@router.get("/api/jobs/{job_id}/pages/{page_number}/words")
def words(
    request: Request,
    job_id: str,
    page_number: int,
    only_low: bool = False,
    offset: int = Query(0, ge=0),
    limit: int = Query(80, ge=1, le=200),
):
    job = owned_job(request, job_id)
    with job.lock:
        page = require_page(ready_doc(job), page_number)
        selected = [w for w in page.words if not only_low or (w.needs_review)]
        return JSONResponse(
            {
                "total": len(selected),
                "offset": offset,
                "limit": limit,
                "revision": job.revision,
                "words": [
                    {
                        "id": w.id,
                        "text": w.text,
                        "bbox": w.bbox,
                        "confidence": w.confidence,
                        "source": w.source,
                        "size": round(w.size, 2),
                        "reviewed": w.reviewed,
                        "needs_review": w.needs_review,
                        "alternatives": w.alternatives,
                    }
                    for w in selected[offset : offset + limit]
                ],
            },
            headers={"Cache-Control": "no-store"},
        )


@router.get("/api/jobs/{job_id}/pages/{page_number}/words/{word_id}/crop")
def word_crop(request: Request, job_id: str, page_number: int, word_id: str):
    from PIL import Image

    job = owned_job(request, job_id)
    with job.lock:
        doc = ready_doc(job)
        page = require_page(doc, page_number)
        word = page.index().get(word_id)
        if word is None:
            raise HTTPException(404, "A szovegmezo nem talalhato.")
        dpi = max(150, math.ceil(72 * 1600 / page.width))
        source = Image.open(io.BytesIO(page_png(doc, page_number, dpi=dpi, original=True)))
        sx, sy = source.width / page.width, source.height / page.height
        x0, y0, x1, y1 = word.bbox
        coords = (
            max(0, int((x0 - 14) * sx)),
            max(0, int((y0 - 12) * sy)),
            min(source.width, int((x1 + 14) * sx)),
            min(source.height, int((y1 + 12) * sy)),
        )
        if coords[2] <= coords[0] or coords[3] <= coords[1]:
            raise HTTPException(422, "Nem keszitheto kepkivagas.")
        fragment = source.crop(coords)
        buf = io.BytesIO()
        fragment.save(buf, format="PNG")
    return Response(
        buf.getvalue(),
        media_type="image/png",
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


@router.patch("/api/jobs/{job_id}/pages/{page_number}/words/{word_id}")
def patch_word(request: Request, job_id: str, page_number: int, word_id: str, change: WordChange):
    check_origin(request)
    job = owned_job(request, job_id)
    with job.lock:
        doc = ready_doc(job)
        page = require_page(doc, page_number)
        word = page.index().get(word_id)
        if word is None:
            raise HTTPException(404, "A szovegmezo nem talalhato.")
        if change.expected_text is not None and change.expected_text != word.text:
            raise HTTPException(409, "A szó megváltozott; frissítsd a javaslatot.")
        new_text = clean(change.text)
        if len(new_text) > 1000:
            raise HTTPException(422, "Tul hosszu szoveg.")
        if new_text != word.text or change.reviewed != word.reviewed:
            doc.edits.append(
                {
                    "page": page_number,
                    "id": word_id,
                    "before": word.text,
                    "after": new_text,
                    "reviewed": change.reviewed,
                }
            )
            if word.original_text is None:
                word.original_text = word.text
            word.text = new_text
            word.reviewed = change.reviewed
            jobs.invalidate(job)
        return {
            "saved": True,
            "revision": job.revision,
            "word": {"id": word.id, "text": word.text, "reviewed": word.reviewed},
        }


@router.get("/api/jobs/{job_id}/pages/{page_number}/tables")
def tables(request: Request, job_id: str, page_number: int):
    job = owned_job(request, job_id)
    with job.lock:
        page = require_page(ready_doc(job), page_number)
        return {
            "audit": audit_page(page),
            "warnings": page.warnings,
            "tables": [
                {
                    "id": block.id,
                    "method": block.method,
                    "bbox": block.bbox,
                    "rows": len(block.y_edges) - 1,
                    "columns": len(block.x_edges) - 1,
                    "warnings": block.warnings,
                    "matrix": table_matrix(block, page)[:150],
                    "truncated": len(block.y_edges) - 1 > 150,
                }
                for block in page.blocks
                if block.kind == "table"
            ],
        }


@router.post("/api/jobs/{job_id}/pages/{page_number}/tables")
def patch_table(request: Request, job_id: str, page_number: int, change: ManualTableChange):
    check_origin(request)
    job = owned_job(request, job_id)
    with job.lock:
        doc = ready_doc(job)
        page = require_page(doc, page_number)
        if not all(math.isfinite(x) for x in [*change.bbox, *change.x_edges, *change.y_edges]):
            raise HTTPException(422, "A koordinataknak veges szamoknak kell lenniuk.")
        x0, y0, x1, y1 = change.bbox
        if (len(change.x_edges) + 1) * (len(change.y_edges) + 1) > 10000:
            raise HTTPException(422, "Tul sok kezi cella.")
        if not (0 <= x0 < x1 <= page.width and 0 <= y0 < y1 <= page.height):
            raise HTTPException(422, "A terulet kivul esik az oldalon.")
        if any(not x0 < x < x1 for x in change.x_edges) or any(
            not y0 < y < y1 for y in change.y_edges
        ):
            raise HTTPException(422, "Az elválasztók a kijelölt területen belül legyenek.")
        backup = deepcopy(page)
        try:
            manual_table(page, tuple(change.bbox), change.x_edges, change.y_edges)
        except ValueError as exc:
            doc.pages[page_number - 1] = backup
            raise HTTPException(422, str(exc)) from exc
        doc.edits.append(
            {
                "page": page_number,
                "action": "manual_table",
                "bbox": change.bbox,
                "x_edges": change.x_edges,
                "y_edges": change.y_edges,
            }
        )
        jobs.invalidate(job)
        return {"saved": True, "revision": job.revision, "audit": audit_page(page)}


@router.get("/api/jobs/{job_id}/export/{kind}")
def download_export(request: Request, job_id: str, kind: str, numbers: str = Query("text")):
    job = owned_job(request, job_id)
    if kind == "source-file":
        ready_doc(job)
        return FileResponse(
            job.path,
            filename=job.name,
            media_type="application/octet-stream",
            headers={"Cache-Control": "no-store"},
        )
    if kind not in jobs.FORMATS or numbers not in ("text", "hu", "en"):
        raise HTTPException(404, "Az exportformatum nem elerheto.")
    try:
        path = jobs.export(job, kind, numbers)
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(422, f"Exporthiba: {exc}") from exc
    ext, mime = jobs.FORMATS[kind]
    stem = Path(job.name).stem[:55]
    safe_stem = "".join(c if c.isalnum() or c in "-_" else "_" for c in stem)[:55]
    filename = f"{safe_stem}_{kind}.{ext}"
    return FileResponse(
        path,
        media_type=mime,
        filename=filename,
        headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
    )


@router.get("/api/jobs/{job_id}/download")
def download_all(request: Request, job_id: str, numbers: str = "text"):
    return download_export(request, job_id, "all", numbers)


@router.post("/api/batch/download")
def batch_download(request: Request, ids: list[str], numbers: str = Query("text")):
    check_origin(request)
    require_access(request)
    if numbers not in ("text", "hu", "en"):
        raise HTTPException(422, "Érvénytelen számkezelés.")
    if not ids or len(ids) > 10 or len(set(ids)) != len(ids):
        raise HTTPException(400, "1-10 kulonbozo feladat kell.")
    selected = [owned_job(request, job_id) for job_id in ids]
    for job in selected:
        with job.lock:
            ready_doc(job)
    fd, filename = tempfile.mkstemp(prefix="docstudio-batch-", suffix=".zip")
    os.close(fd)
    tmp = Path(filename)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as outer:
            for job in selected:
                exported = jobs.export(job, "all", numbers)
                label = "".join(c if c.isalnum() or c in "-_" else "_" for c in Path(job.name).stem)
                outer.write(exported, arcname=f"{label[:45]}_{job.id[:8]}.zip")
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    return FileResponse(
        tmp,
        media_type="application/zip",
        filename="docstudio_batch.zip",
        headers={"Cache-Control": "no-store"},
        background=BackgroundTask(lambda: tmp.unlink(missing_ok=True)),
    )


@router.delete("/api/jobs/{job_id}")
def delete_job(request: Request, job_id: str):
    check_origin(request)
    job = owned_job(request, job_id)
    try:
        jobs.remove(job)
    except RuntimeError as exc:
        raise HTTPException(409, str(exc)) from exc
    return {"removed": True}


@router.get("/api/jobs")
def list_jobs(request: Request):
    owner = require_access(request)
    with jobs.LOCK:
        selected = [j for j in jobs.JOBS.values() if j.owner == owner]
    return {"jobs": [j.public() for j in selected]}


@router.get("/api/capabilities")
def capabilities(request: Request):
    require_access(request)
    from reconstructor.ocr import installed_languages
    from reconstructor.ai import available

    try:
        langs = sorted(installed_languages())
    except Exception:
        langs = []
    return {"ocr_languages": langs, "ai_enabled": available(), "version": "4.0.0"}


class AIRequest(BaseModel):
    consent: bool = False


@router.post("/api/jobs/{job_id}/pages/{page_number}/ai-review")
def ai_review(request: Request, job_id: str, page_number: int, body: AIRequest):
    check_origin(request)
    if not body.consent:
        raise HTTPException(422, "Az oldal AI-továbbításához engedély szükséges.")
    job = owned_job(request, job_id)
    with job.lock:
        doc = ready_doc(job)
        page = deepcopy(require_page(doc, page_number))
        revision = job.revision
        image = page_png(doc, page_number, dpi=144, original=True)
    from reconstructor.ai import review_page

    try:
        result = review_page(page, image)
    except Exception:
        raise HTTPException(
            502, "Az AI ellenőrzés nem sikerült. Ellenőrizd a beállított Vision szolgáltatást."
        )
    with job.lock:
        if revision != job.revision:
            raise HTTPException(409, "A dokumentum megváltozott. Indítsd újra az ellenőrzést.")
    return {"revision": revision, **result}
