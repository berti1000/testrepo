"""Server-rendered indexable pages, sessions and sitemap."""

import os
from pathlib import Path
from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, RedirectResponse, Response
from fastapi.templating import Jinja2Templates
from ..security import check_origin, is_authenticated, session_id, verify_password

router = APIRouter()
templates = Jinja2Templates(directory=str(Path(__file__).resolve().parents[1] / "templates"))


def public_url(request: Request, path: str = "/") -> str:
    base = (os.getenv("APP_PUBLIC_URL") or str(request.base_url)).rstrip("/")
    return base + path


def page_context(request: Request, title: str, description: str, path: str, **kwargs) -> dict:
    session_id(request)
    return {
        "title": title,
        "description": description,
        "canonical": public_url(request, path),
        "authenticated": is_authenticated(request),
        "login_required": bool(os.getenv("APP_ACCESS_PASSWORD")),
        **kwargs,
    }


@router.get("/health")
def health():
    return {"status": "ok"}


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    context = page_context(
        request,
        "DocStudio | PDF és OCR dokumentumfeldolgozás",
        "Dokumentum-rekonstrukcio, OCR, PDF-bol szerkesztheto Excel es Word; helyi szerveroldali feldolgozassal.",
        "/",
    )
    return templates.TemplateResponse(request, "studio.html", context)


ROUTES = {
    "/eszkozok/dokumentum-rekonstrukcio": (
        "Dokumentum-rekonstrukció | DocStudio",
        "PDF-ek és képek újraalkotása, vizuális ellenőrzése, javítható szöveg és szerkeszthető exportok.",
        "Dokumentum-rekonstrukció",
        "A dokumentum szerkezete is számít.",
        "auto",
    ),
    "/eszkozok/pdf-excel": (
        "PDF Excel konvertálás | DocStudio",
        "PDF táblázatok feldolgozása, ellenőrizhető cellakiosztással, szerkeszthető XLSX exporttal.",
        "PDF-ből Excel",
        "Szerkeszthető táblázatok. Nem pixeles raszter.",
        "auto",
    ),
    "/eszkozok/ocr-szoveg": (
        "OCR szövegfelismerés | DocStudio",
        "Szkennelt PDF-ek és képek magyar-angol OCR felismerése, javítással és TXT, Word, Excel exporttal.",
        "OCR szövegfelismerés",
        "Szkennelt képből ellenőrizhető szöveg.",
        "auto",
    ),
}


@router.get("/eszkozok/dokumentum-rekonstrukcio", response_class=HTMLResponse)
@router.get("/eszkozok/pdf-excel", response_class=HTMLResponse)
@router.get("/eszkozok/ocr-szoveg", response_class=HTMLResponse)
def tool(request: Request):
    title, description, heading, tagline, mode = ROUTES[request.url.path]
    ctx = page_context(
        request,
        title,
        description,
        request.url.path,
        heading=heading,
        tagline=tagline,
        default_ocr=mode,
    )
    return templates.TemplateResponse(request, "studio.html", ctx)


@router.get("/login", response_class=HTMLResponse)
def login(request: Request):
    session_id(request)
    if not os.getenv("APP_ACCESS_PASSWORD") or is_authenticated(request):
        return RedirectResponse("/eszkozok/dokumentum-rekonstrukcio", status_code=303)
    return templates.TemplateResponse(
        request,
        "login.html",
        {
            **page_context(request, "Bejelentkezes | DocStudio", "Bejelentkezes", "/login"),
            "error": "",
            "robots": "noindex,nofollow",
        },
    )


@router.post("/login", response_class=HTMLResponse)
def login_post(request: Request, password: str = Form(...)):
    check_origin(request)
    session_id(request)
    if verify_password(password):
        request.session["authorized"] = True
        return RedirectResponse("/eszkozok/dokumentum-rekonstrukcio", status_code=303)
    return templates.TemplateResponse(
        request,
        "login.html",
        {
            **page_context(request, "Bejelentkezes | DocStudio", "Bejelentkezes", "/login"),
            "error": "Hibas jelszo.",
            "robots": "noindex,nofollow",
        },
        status_code=401,
    )


@router.post("/logout")
def logout(request: Request):
    check_origin(request)
    request.session.clear()
    return RedirectResponse("/", status_code=303)


@router.get("/robots.txt", response_class=PlainTextResponse)
def robots(request: Request):
    content = (
        "User-agent: *\nDisallow: /api/\nDisallow: /login\n"
        "Disallow: /health\nSitemap: " + public_url(request, "/sitemap.xml") + "\n"
    )
    return PlainTextResponse(content)


@router.get("/sitemap.xml")
def sitemap(request: Request):
    from xml.sax.saxutils import escape

    paths = ["/", *ROUTES]
    xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        + "".join("<url><loc>" + escape(public_url(request, p)) + "</loc></url>" for p in paths)
        + "</urlset>"
    )
    return Response(xml, media_type="application/xml")
