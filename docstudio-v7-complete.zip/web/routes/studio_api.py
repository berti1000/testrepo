import hashlib
import io
import zipfile
from typing import Literal
import fitz
from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field, ConfigDict
from web.security import require_access, check_origin
from studio.store import STORE, Conflict
from studio.ir import to_runtime
from studio.router import capabilities
from studio.output.service import OutputOptions
from studio.workflow import INPUT_ERRORS, OUTPUT_ERRORS
from reconstructor.locking import serialized

router = APIRouter(prefix="/api/studio")


class Version(BaseModel):
    model_config = ConfigDict(extra="forbid")
    version: int = Field(ge=0)


class Settings(BaseModel):
    model_config = ConfigDict(extra="forbid")
    engine: Literal["auto", "native", "paddle", "tesseract", "vision"] = "auto"
    contrast: float = Field(default=1, ge=0.5, le=2.5)
    gap_factor: float = Field(default=0.95, ge=0.45, le=2)
    consent: bool = False
    verify_ocr: bool = False
    quality: Literal["fast", "balanced", "accurate"] = "balanced"
    orientation: bool = True
    deskew: bool = True
    perspective: bool = False
    rotation: Literal[0, 90, 180, 270] = 0
    dpi: int = Field(default=300, ge=150, le=450)
    password: str = Field(default="", max_length=256)


class Retry(Version):
    page: int = Field(ge=1)
    error: Literal["text", "columns", "table"]
    settings: Settings = Field(default_factory=Settings)


class Edit(Version):
    page: int = Field(ge=1)
    word: str = Field(max_length=120)
    text: str = Field(max_length=1000)
    size: float | None = Field(default=None, ge=4, le=120, allow_inf_nan=False)
    bold: bool | None = None
    font: Literal["Arial", "Times New Roman", "Courier New"] | None = None


class Restore(Version):
    revision: int = Field(ge=1)


class Export(Version):
    options: OutputOptions
    error: str | None = None


class Accept(Version):
    sha256: str


def owner(request, write=False):
    if write:
        check_origin(request)
    return require_access(request)


def invoke(call):
    try:
        return call()
    except KeyError as e:
        raise HTTPException(404, str(e)) from e
    except Conflict as e:
        raise HTTPException(409, str(e)) from e
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e)) from e


@router.post("/vision-test")
def test_vision_connection(request: Request):
    owner(request, True)
    from studio.engines.vision_status import connection_test

    return connection_test()


@router.get("/capabilities")
def engines(request: Request):
    owner(request)
    return {"engines": capabilities(), "input_errors": INPUT_ERRORS, "output_errors": OUTPUT_ERRORS}


@router.get("/jobs")
def jobs(request: Request):
    return STORE.list(owner(request))


@router.post("/jobs", status_code=202)
async def upload(request: Request, files: list[UploadFile] = File(...), settings: str = Form("{}")):
    sid = owner(request, True)
    try:
        config = Settings.model_validate_json(settings)
    except ValueError as e:
        raise HTTPException(422, str(e)) from e
    if not 1 <= len(files) <= 10:
        raise HTTPException(400, "1–10 fájl tölthető fel egyszerre")
    created = []
    total = 0
    try:
        for file in files:
            data = bytearray()
            while chunk := await file.read(1024 * 1024):
                data.extend(chunk)
                total += len(chunk)
                if len(data) > 50 * 1024 * 1024 or total > 100 * 1024 * 1024:
                    raise ValueError("Feltöltési korlát: 50 MB/fájl, 100 MB/kérés")
            created.append(
                STORE.create(bytes(data), file.filename or "document.pdf", sid, config.model_dump())
            )
        for item in created:
            STORE.dispatch_import(item["id"], config.model_dump())
        return created
    except (ValueError, zipfile.BadZipFile) as e:
        for item in created:
            with STORE.lock:
                job = STORE.get(item["id"])
                job["state"] = "failed"
                STORE.save(job)
                STORE.delete(item["id"], sid)
        raise HTTPException(400, str(e)) from e
    finally:
        for file in files:
            await file.close()


@router.get("/jobs/{id}")
def job(request: Request, id: str):
    return invoke(lambda: STORE.get(id, owner(request)))


@router.get("/jobs/{id}/ir")
def ir(request: Request, id: str, revision: int | None = None):
    invoke(lambda: STORE.get(id, owner(request)))
    return invoke(lambda: STORE.load_ir(id, revision).model_dump())


@router.post("/jobs/{id}/retry", status_code=202)
def retry(request: Request, id: str, body: Retry):
    return invoke(
        lambda: STORE.retry(
            id,
            owner(request, True),
            body.version,
            body.page,
            body.error,
            body.settings.model_dump(),
        )
    )


@router.patch("/jobs/{id}/word")
def edit(request: Request, id: str, body: Edit):
    return invoke(
        lambda: STORE.edit(
            id,
            owner(request, True),
            body.version,
            body.page,
            body.word,
            body.text,
            size=body.size,
            bold=body.bold,
            font=body.font,
        )
    )


@router.post("/jobs/{id}/restore")
def restore(request: Request, id: str, body: Restore):
    return invoke(
        lambda: STORE.restore_revision(id, owner(request, True), body.version, body.revision)
    )


@router.post("/jobs/{id}/accept-input")
def accept_input(request: Request, id: str, body: Version):
    return invoke(lambda: STORE.accept_input(id, owner(request, True), body.version))


@router.post("/jobs/{id}/export", status_code=202)
def export(request: Request, id: str, body: Export):
    return invoke(
        lambda: STORE.export(id, owner(request, True), body.version, body.options, body.error)
    )


@router.post("/jobs/{id}/accept-export")
def accept_export(request: Request, id: str, body: Accept):
    return invoke(lambda: STORE.accept_export(id, owner(request, True), body.version, body.sha256))


@router.get("/jobs/{id}/preview/{kind}/{page}")
@serialized
def preview(request: Request, id: str, kind: str, page: int, revision: int | None = None):
    invoke(lambda: STORE.get(id, owner(request)))
    doc = invoke(lambda: STORE.load_ir(id, revision))
    if not 1 <= page <= len(doc.pages) or kind not in ("source", "reconstructed", "original"):
        raise HTTPException(404)
    path = STORE.folder(id) / f"preview-{doc.revision}-{kind}-{page}.png"
    if not path.exists():
        if kind == "reconstructed":
            from reconstructor.render import reconstructed_pdf

            runtime = to_runtime(doc, STORE.assets(id))
            runtime.pages = [runtime.pages[page - 1]]
            data = reconstructed_pdf(runtime)
            index = 0
        else:
            data = STORE.assets(id).get(
                doc.normalized_pdf_asset if kind == "source" else doc.source_pdf_asset
            )
            index = page - 1
        with fitz.open(stream=data, filetype="pdf") as pdf:
            fp = pdf[index]
            scale = min(3, 1600 / fp.rect.width)
            fp.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).save(path)
    return FileResponse(path, media_type="image/png")


@router.get("/jobs/{id}/output-page/{page}")
def output_page(request: Request, id: str, page: int):
    item = invoke(lambda: STORE.get(id, owner(request)))
    info = item.get("export")
    if not info or not 1 <= page <= info["preview_pages"]:
        raise HTTPException(404)
    if request.query_params.get("export") not in (None, info["id"]):
        raise HTTPException(409, "Az export-előnézet már újabb változatra váltott")
    return FileResponse(
        STORE.folder(id) / "exports" / info["id"] / f"page-{page}.png", media_type="image/png"
    )


@router.get("/jobs/{id}/download")
def download(request: Request, id: str):
    item = invoke(lambda: STORE.get(id, owner(request)))
    if item["state"] != "ready" or not item["export"]:
        raise HTTPException(409, "Előbb fogadd el az export-előnézetet")
    info = item["export"]
    path = STORE.folder(id) / "exports" / info["id"] / info["filename"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != info["sha256"]:
        raise HTTPException(409, "Sérült exportfájl")
    return FileResponse(path, filename=info["filename"], media_type="application/octet-stream")


@router.get("/jobs/{id}/original")
def original(request: Request, id: str):
    item = invoke(lambda: STORE.get(id, owner(request)))
    return FileResponse(
        STORE.folder(id) / ("source" + item["extension"]),
        filename=item["name"],
        media_type="application/octet-stream",
    )


@router.post("/batch")
def batch(request: Request, ids: list[str]):
    sid = owner(request, True)
    if not 1 <= len(ids) <= 20:
        raise HTTPException(400)
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, "w", zipfile.ZIP_DEFLATED) as z:
        for n, id in enumerate(ids, 1):
            item = invoke(lambda: STORE.get(id, sid))
            if item["state"] != "ready":
                raise HTTPException(409, "Minden exportot el kell fogadni")
            info = item["export"]
            data = (STORE.folder(id) / "exports" / info["id"] / info["filename"]).read_bytes()
            if hashlib.sha256(data).hexdigest() != info["sha256"]:
                raise HTTPException(409, "Sérült export")
            z.writestr(f"{n:02d}-{id[:8]}/" + info["filename"], data)
    return Response(
        stream.getvalue(),
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=docstudio-batch.zip"},
    )


@router.delete("/jobs/{id}")
def delete(request: Request, id: str):
    invoke(lambda: STORE.delete(id, owner(request, True)))
    return {"deleted": True}
