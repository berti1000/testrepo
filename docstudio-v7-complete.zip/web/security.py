"""Browser-session isolation and optional password gate.

Session cookies are signed, HttpOnly, SameSite=Lax (Strict may block legitimate
cross-site navigations) and never contain document data or passwords.
"""

from __future__ import annotations
import hmac
import os
import secrets
from fastapi import HTTPException, Request


def environment_ready() -> None:
    if os.getenv("APP_ENV", "development").lower() != "production":
        return
    if len(os.getenv("APP_SESSION_SECRET", "")) < 32:
        raise RuntimeError("Production requires APP_SESSION_SECRET of at least 32 characters.")
    if len(os.getenv("APP_ACCESS_PASSWORD", "")) < 16:
        raise RuntimeError("Production requires APP_ACCESS_PASSWORD of at least 16 characters.")
    if os.getenv("COOKIE_SECURE", "0") != "1":
        raise RuntimeError("Production requires COOKIE_SECURE=1 and HTTPS.")


def session_id(request: Request) -> str:
    value = request.session.get("sid")
    if not isinstance(value, str) or len(value) != 32:
        value = secrets.token_hex(16)
        request.session["sid"] = value
    return value


def is_authenticated(request: Request) -> bool:
    password = os.getenv("APP_ACCESS_PASSWORD")
    return (not password) or request.session.get("authorized") is True


def require_access(request: Request) -> str:
    if not is_authenticated(request):
        raise HTTPException(401, "Bejelentkezes szukseges.")
    # The owner identity is per browser, not one global account.
    return session_id(request)


def verify_password(value: str) -> bool:
    real = os.getenv("APP_ACCESS_PASSWORD", "")
    return bool(real) and hmac.compare_digest(value.encode(), real.encode())


def check_origin(request: Request) -> None:
    """Reject browser cross-origin state-changing requests (CSRF hardening)."""
    origin = request.headers.get("origin")
    if not origin:
        return
    from urllib.parse import urlsplit

    origin_parts = urlsplit(origin)
    current = urlsplit(str(request.base_url))
    # Proxies can set Host and forwarded proto; verify host/port always.
    if origin_parts.netloc.lower() != current.netloc.lower():
        raise HTTPException(403, "A keres nem a sajat oldalrol erkezett.")


def session_secret():
    if os.getenv("APP_SESSION_SECRET"):
        return os.environ["APP_SESSION_SECRET"]
    from .jobs import ROOT

    path = ROOT / ".session-secret"
    try:
        with path.open("x") as f:
            os.chmod(path, 0o600)
            f.write(secrets.token_hex(32))
    except FileExistsError:
        pass
    return path.read_text().strip()
