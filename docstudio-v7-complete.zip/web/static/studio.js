"use strict";
(() => {
  if (!document.getElementById("studio")) return;
  const $ = (id) => document.getElementById(id),
    s = {
      jobs: [],
      job: null,
      ir: null,
      page: 1,
      revision: 0,
      view: "reconstructed",
      tab: "input",
      inputError: null,
      outputError: null,
      word: null,
      caps: null,
      polling: false,
      mutating: false,
      editVersion: null,
      sheetIndex: 0,
    };
  const labels = {
    queued: "Sorban áll",
    profiling: "Profilozás",
    processing: "Feldolgozás",
    input_review: "Beolvasás ellenőrzése",
    input_accepted: "Beolvasás elfogadva",
    exporting: "Export készül",
    export_review: "Export ellenőrzése",
    ready: "Letölthető",
    failed: "Hiba",
  };
  const busy = () =>
      !s.job ||
      ["queued", "profiling", "processing", "exporting"].includes(s.job.state),
    editable = () =>
      s.job &&
      !busy() &&
      s.ir &&
      s.revision === s.job.revision &&
      s.job.state !== "failed";
  function alert(text) {
    $("alert").textContent = text || "";
    $("alert").hidden = !text;
  }
  async function api(path, opts = {}) {
    const r = await fetch("/api/studio" + path, {
      credentials: "same-origin",
      ...opts,
    });
    if (!r.ok) {
      let t = await r.text();
      try {
        const o = JSON.parse(t);
        t = typeof o.detail === "string" ? o.detail : JSON.stringify(o.detail);
      } catch {}
      throw Error(t || `HTTP ${r.status}`);
    }
    return r.json();
  }
  const json = (body, method = "POST") => ({
    method,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  async function safe(action) {
    try {
      alert("");
      await action();
    } catch (e) {
      alert(e.message);
    }
  }
  function option(value, label) {
    const e = document.createElement("option");
    e.value = value;
    e.textContent = label;
    return e;
  }
  function para(parent, text) {
    const p = document.createElement("p");
    p.textContent = text;
    parent.append(p);
  }
  function settings() {
    return {
      engine: $("engine").value,
      contrast: Number($("contrast").value),
      gap_factor: Number($("gap").value),
      consent: $("consent").checked,
      verify_ocr: $("verify-ocr").checked,
      quality: $("ocr-quality").value,
      orientation: $("orientation").checked,
      deskew: $("deskew").checked,
      perspective: $("perspective").checked,
      password: $("password").value,
    };
  }
  function tags(parent, items, key) {
    parent.replaceChildren();
    for (const [code, text] of Object.entries(items || {})) {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = text;
      b.classList.toggle("active", s[key] === code);
      b.setAttribute("aria-pressed", String(s[key] === code));
      b.onclick = () => {
        s[key] = code;
        tags(parent, items, key);
        controls();
      };
      parent.append(b);
    }
  }
  function controls() {
    const j = s.job;
    $("compact-label").hidden = $("format").value !== "xlsx" || $("excel-mode").value !== "semantic";
    $("accept-input").disabled = !editable() || !!s.word || s.mutating;
    $("accept-input").textContent = j?.state === "input_review" ? "✓ Jóváhagyás · exportformátum választása" : "Exportformátum választása →";
    $("retry").disabled = !editable() || !s.inputError || !!s.word || s.mutating;
    $("restore").disabled = busy() || !!s.word || s.mutating || !j?.revision || s.revision === j.revision;
    $("generate").disabled =
      !j || !!s.word || s.mutating || !["input_accepted", "export_review", "ready"].includes(j.state);
    $("choose-format").disabled = $("generate").disabled;
    $("retry-export").disabled = $("generate").disabled || !s.outputError;
    const e = j?.export, o = options();
    const dirty = !!e && (o.format !== e.format || (e.format === "docx" && o.word_mode !== e.options.word_mode) ||
      (e.format === "xlsx" && ["numbers", "excel_mode", "compact"].some(k => o[k] !== (e.options[k] ?? ({numbers:"text",excel_mode:"semantic",compact:true})[k]))));
    $("accept-export").disabled = j?.state !== "export_review" || dirty || s.mutating;
    $("accept-export").title = dirty ? "A módosított beállításokhoz készíts új előnézetet." : "A megjelenített fájl jóváhagyása és letöltése";
    $("accept-export").hidden = j?.state === "ready";
    $("download").hidden = j?.state !== "ready" || dirty;
    $("save-word").disabled = !editable() || s.mutating;
  }
  function renderJobs() {
    $("job-count").textContent = s.jobs.length;
    $("jobs").replaceChildren();
    for (const j of s.jobs) {
      const row = document.createElement("div");
      row.className = "job-row";
      const b = document.createElement("button");
      b.className = "job";
      b.classList.toggle("selected", j.id === s.job?.id);
      b.setAttribute("aria-label", j.name);
      const n = document.createElement("strong");
      n.textContent = j.name;
      const t = document.createElement("small");
      t.textContent = labels[j.state];
      const p = document.createElement("progress");
      p.max = 1;
      p.value = j.progress;
      b.append(n, t, p);
      b.onclick = () => safe(() => select(j.id));
      row.append(b);
      if (
        !["queued", "profiling", "processing", "exporting"].includes(j.state)
      ) {
        const d = document.createElement("button");
        d.textContent = "×";
        d.className = "remove-job";
        d.setAttribute("aria-label", j.name + " törlése");
        d.onclick = () =>
          safe(async () => {
            await api(`/jobs/${j.id}`, { method: "DELETE" });
            if (s.job?.id === j.id) {
              s.job = null;
              s.ir = null;
              s.word = null;
              $("stage").hidden = true;
              $("empty").hidden = false;
              $("editor").hidden = true;
              $("original").hidden = true;
              $("status").textContent = "Válassz dokumentumot";
              $("diagnostics").replaceChildren();
            }
            await refresh();
            controls();
          });
        row.append(d);
      }
      $("jobs").append(row);
    }
    $("batch").disabled = !s.jobs.some((j) => j.state === "ready");
  }
  function status() {
    const j = s.job;
    if (!j) return;
    $("status").textContent = j.message || labels[j.state];
    $("progress").value = j.progress;
    if (j.error) alert(j.error);
    $("original").href = `/api/studio/jobs/${j.id}/original`;
    $("original").hidden = false;
    $("profile-label").textContent =
      j.profile?.label || "Dokumentum profilozása";
    $("profile-reasons").textContent = (j.profile?.reasons || []).join(" · ");
    $("revision-select").replaceChildren(
      ...j.history.map((h) =>
        option(h.revision, `v${h.revision} · ${h.label}`),
      ),
    );
    $("revision-select").value = s.revision || j.revision;
    controls();
  }
  async function refresh() {
    s.jobs = await api("/jobs");
    renderJobs();
    if (s.job) {
      const j = s.jobs.find((j) => j.id === s.job.id);
      if (j) {
        const old = s.job.version;
        s.job = j;
        status();
        if (j.version !== old && !s.word && !s.mutating) {
          s.revision = j.revision;
          await loadIR();
          renderOutput();
        }
      }
    }
  }
  function canLeaveEdit() {
    if (s.word) { alert("Előbb mentsd vagy vesd el a vásznon megnyitott javítást."); return false; }
    return !s.mutating;
  }
  async function select(id) {
    if (!canLeaveEdit()) return;
    s.job = await api(`/jobs/${id}`);
    s.page = 1;
    s.revision = s.job.revision;
    s.word = null;
    s.inputError = null;
    s.outputError = null;
    $("editor").hidden = true;
    renderJobs();
    status();
    await loadIR();
    renderOutput();
    tab("input");
    tags($("input-errors"), s.caps.input_errors, "inputError");
  }
  async function loadIR() {
    if (!s.job?.revision) {
      s.ir = null;
      $("stage").hidden = true;
      $("empty").hidden = false;
      return;
    }
    const id = s.job.id,
      rev = s.revision || s.job.revision;
    const ir = await api(`/jobs/${id}/ir?revision=${rev}`);
    if (s.job?.id !== id) return;
    s.ir = ir;
    s.revision = rev;
    s.page = Math.min(s.page, ir.pages.length);
    $("page-select").replaceChildren(
      ...ir.pages.map((p) =>
        option(p.number, `${p.number} / ${ir.pages.length}`),
      ),
    );
    $("page-select").value = s.page;
    $("revision-select").value = rev;
    renderPage();
    controls();
  }
  function renderPage() {
    if (!s.ir) return;
    const p = s.ir.pages[s.page - 1],
      base = `/api/studio/jobs/${s.job.id}/preview/`;
    $("source-image").src = `${base}source/${s.page}?revision=${s.revision}`;
    $("reconstructed-image").src =
      `${base}reconstructed/${s.page}?revision=${s.revision}`;
    $("stage").style.aspectRatio = `${p.width}/${p.height}`;
    $("stage").hidden = false;
    $("empty").hidden = true;
    const structure = $("structure-layer");
    structure.setAttribute("viewBox", `0 0 ${p.width} ${p.height}`);
    structure.replaceChildren();
    for (const b of p.blocks) {
      for (const box of b.kind === "table"
        ? b.cells.map((c) => c.bbox)
        : [b.bbox]) {
        const r = document.createElementNS(
          "http://www.w3.org/2000/svg",
          "rect",
        );
        const [x, y, x2, y2] = box;
        for (const [k, v] of Object.entries({
          x,
          y,
          width: x2 - x,
          height: y2 - y,
        }))
          r.setAttribute(k, v);
        r.classList.toggle("table-cell", b.kind === "table");
        structure.append(r);
      }
    }
    const svg = $("word-layer");
    svg.setAttribute("viewBox", `0 0 ${p.width} ${p.height}`);
    svg.replaceChildren();
    for (const w of p.words) {
      const r = document.createElementNS("http://www.w3.org/2000/svg", "rect");
      const [a, b, c, d] = w.bbox;
      for (const [k, v] of Object.entries({
        x: a,
        y: b,
        width: c - a,
        height: d - b,
      }))
        r.setAttribute(k, v);
      r.dataset.word = w.id;
      r.classList.toggle(
        "uncertain",
        !w.reviewed &&
          (w.visual_artifact ||
            w.alternatives.length ||
            (w.confidence !== null && w.confidence < 0.75)),
      );
      const t = document.createElementNS("http://www.w3.org/2000/svg", "title");
      t.textContent = w.text;
      r.append(t);
      r.setAttribute("tabindex", "0");
      r.setAttribute("role", "button");
      r.setAttribute("aria-label", "Szerkesztés: " + w.text);
      r.onkeydown = (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); r.onclick(); } };
      r.onclick = () => {
        if (!editable() || !canLeaveEdit()) return;
        s.word = w;
        s.editVersion = s.job.version;
        $("editor").hidden = false;
        $("edit-text").value = w.text;
        $("edit-size").value = Math.round(w.size*10)/10;
        $("edit-bold").checked = w.bold;
        $("edit-font").value = /mono|courier|consolas/i.test(w.font) ? "Courier New" : /times|(?<!sans )serif|cambria|georgia/i.test(w.font) ? "Times New Roman" : "Arial";
        previewFont();
        $("word-meta").textContent =
          `${w.source} · ${w.confidence === null ? "nincs bizonyossági adat" : Math.round(w.confidence * 100) + "% motorpontszám (nem pontosság)"}${w.alternatives.length ? " · eltérő olvasat: " + w.alternatives.join(" / ") : ""}`;
        for (const n of svg.children) n.classList.remove("selected");
        r.classList.add("selected");
        positionEditor();
        $("edit-text").focus();
        $("edit-text").select();
        controls();
      };
      svg.append(r);
    }
    $("word-count").textContent =
      `${p.words.length} szövegelem · v${s.revision}`;
    $("diagnostics").replaceChildren();
    para(
      $("diagnostics"),
      "OCR: " + (p.diagnostics.ocr_actual || p.diagnostics.engine || p.mode),
    );
    const st = p.diagnostics.strategy;
    if (st)
      para(
        $("diagnostics"),
        st.reason + " · táblázat: " + (p.diagnostics.table_actual || st.table),
      );
    if (p.diagnostics.inference_crop_px)
      para(
        $("diagnostics"),
        "OCR tartalomkivágás: " +
          p.diagnostics.inference_crop_px.join(", ") +
          " px. A vászon koordinátái a teljes oldalra vonatkoznak.",
      );
    for (const w of p.warnings) para($("diagnostics"), w);
    $("history").replaceChildren();
    for (const e of s.ir.provenance)
      para(
        $("history"),
        `${e.operation} · ${e.strategy?.ocr || e.engine || ""} · ${e.seconds || 0} s${e.error ? " · " + e.error : ""}${e.notice ? " · " + e.notice : ""}`,
      );
    view(s.view);
    zoom();
  }
  function view(v) {
    s.view = v;
    $("source-image").style.opacity = v === "reconstructed" ? "0" : "1";
    $("reconstructed-image").style.opacity =
      v === "source"
        ? "0"
        : v === "overlay"
          ? Number($("opacity").value) / 100
          : "1";
    $("opacity-label").hidden = v !== "overlay";
    document
      .querySelectorAll("[data-view]")
      .forEach((b) => b.classList.toggle("active", b.dataset.view === v));
  }
  function positionEditor() {
    if (!s.word || !s.ir) return;
    const p = s.ir.pages[s.page - 1], w = s.word, width = $("stage").clientWidth;
    const boxWidth = Math.min(320, Math.max(190, (w.bbox[2] - w.bbox[0]) / p.width * width + 24));
    $("editor").style.width = boxWidth + "px";
    $("editor").style.left = Math.max(0, Math.min(width - boxWidth, w.bbox[0] / p.width * width)) + "px";
    $("editor").style.top = Math.max(0, w.bbox[1] / p.height * 100) + "%";
    $("edit-text").style.fontSize = Math.max(14, w.size / p.width * width) + "px";
  }
  function zoom() {
    $("stage").style.width = Number($("zoom").value) + "%";
    positionEditor();
  }
  new ResizeObserver(positionEditor).observe($("stage"));
  function tab(t) {
    if (t !== s.tab && !canLeaveEdit()) return;
    s.tab = t;
    for (const n of ["input", "output"]) {
      $(n + "-view").hidden = n !== t;
      $(n + "-controls").hidden = n !== t;
      $(n + "-tab").classList.toggle("active", n === t);
      $(n + "-tab").setAttribute("aria-selected", String(n === t));
    }
    $("editor").hidden = t !== "input" || !s.word;
    controls();
  }
  function options() {
    return {
      ...(s.job?.export?.options || {}),
      format: $("format").value,
      word_mode: $("word-mode").value,
      numbers: $("numbers").value,
      excel_mode: $("excel-mode").value,
      compact: $("excel-mode").value === "semantic" && $("compact").checked,
    };
  }
  function formatChanged(reset = true) {
    if (reset) s.outputError = null;
    const f = $("format").value;
    $("word-mode-label").hidden = f !== "docx";
    $("numbers-label").hidden = f !== "xlsx";
    $("excel-mode-label").hidden = f !== "xlsx";
    $("compact-label").hidden = f !== "xlsx" || $("excel-mode").value !== "semantic";
    tags($("output-errors"), s.caps?.output_errors[f], "outputError");
    controls();
  }
  function outputImage() {
    const e = s.job?.export;
    if (e?.preview_pages) {
      $("output-image").hidden = false;
      $("output-image").src =
        `/api/studio/jobs/${s.job.id}/output-page/${$("output-page").value || 1}?export=${e.id}`;
    }
  }
  function address(value) {
    const m = /^([A-Z]+)(\d+)$/.exec(value);
    let c = 0;
    for (const ch of m[1]) c = c * 26 + ch.charCodeAt(0) - 64;
    return [Number(m[2]) - 1, c - 1];
  }
  function columnName(n) {
    let result = "";
    for (n++; n; n = Math.floor((n - 1) / 26)) result = String.fromCharCode(65 + (n - 1) % 26) + result;
    return result;
  }
  function sheets(items) {
    const host = $("sheet-preview"); host.replaceChildren();
    s.sheetIndex = Math.min(s.sheetIndex, items.length - 1);
    const tabs = document.createElement("div"); tabs.className = "sheet-tabs"; tabs.setAttribute("role", "tablist");
    items.forEach((item, i) => {
      const b = document.createElement("button"); b.textContent = item.name; b.setAttribute("role", "tab");
      b.setAttribute("aria-selected", String(i === s.sheetIndex)); b.classList.toggle("active", i === s.sheetIndex);
      b.onclick = () => { s.sheetIndex = i; sheets(items); }; tabs.append(b);
    });
    const formula = document.createElement("div"); formula.className = "sheet-formula";
    const addressBox = document.createElement("b"), valueBox = document.createElement("span");
    addressBox.textContent = "A1"; valueBox.textContent = "Kattints egy cellára a teljes érték megtekintéséhez.";
    formula.append(addressBox, valueBox); host.append(tabs, formula);
    const sh = items[s.sheetIndex], widths = sh.widths || sh.rows[0].map(() => 100), heights = sh.heights || sh.rows.map(() => 24);
    const xs = [36], ys = [24]; widths.forEach(w => xs.push(xs.at(-1) + w)); heights.forEach(h => ys.push(ys.at(-1) + h));
    const grid = document.createElement("div"); grid.className = "sheet-grid"; grid.setAttribute("role", "table");
    grid.setAttribute("aria-label", sh.name); grid.style.width = xs.at(-1) + "px"; grid.style.height = ys.at(-1) + "px";
    function place(el, x, y, width, height) { Object.assign(el.style, {left:x+"px",top:y+"px",width:width+"px",height:height+"px"}); }
    widths.forEach((w,c) => { const h=document.createElement("div"); h.className="sheet-heading"; h.textContent=columnName(c); h.setAttribute("role","columnheader"); place(h,xs[c],0,w,24); grid.append(h); });
    heights.forEach((h,r) => { const n=document.createElement("div"); n.className="sheet-heading row-heading"; n.textContent=r+1; n.setAttribute("role","rowheader"); place(n,0,ys[r],36,h); grid.append(n); });
    const skip = new Set(), spans = new Map();
    for (const range of sh.merges) {
      const [a, b] = range.split(":").map(address); spans.set(a.join(","), b);
      for (let r=a[0];r<=b[0];r++) for (let c=a[1];c<=b[1];c++) if(r!==a[0]||c!==a[1])skip.add(`${r},${c}`);
    }
    const fontStyle = (el, st) => {
      if(st.font) el.style.fontFamily = st.font + ", Arial, sans-serif";
      if(st.size) el.style.fontSize=st.size*96/72+"px";
      el.style.fontWeight=st.bold?"700":"400"; el.style.fontStyle=st.italic?"italic":"normal";
      if(st.color)el.style.color=st.color;
    };
    sh.rows.forEach((row,r) => row.forEach((value,c) => {
      const key=`${r},${c}`; if(skip.has(key))return;
      const coord=columnName(c)+(r+1), st=sh.styles?.[coord]||{}, end=spans.get(key)||[r,c];
      const cell=document.createElement("div"); cell.className="sheet-cell"; cell.setAttribute("role","cell"); cell.tabIndex=0; cell.dataset.cell=coord;
      place(cell,xs[c],ys[r],xs[end[1]+1]-xs[c],ys[end[0]+1]-ys[r]); fontStyle(cell,st);
      cell.style.background=st.fill||"#fff"; cell.style.textAlign=st.align||"left";
      cell.style.justifyContent=st.vertical==="center"?"center":st.vertical==="bottom"?"flex-end":"flex-start";
      for(const [side,border] of Object.entries(st.borders||{})) cell.style["border"+side[0].toUpperCase()+side.slice(1)]=`1px solid ${border.color}`;
      const content=document.createElement("div"); content.className="cell-content"; content.style.whiteSpace=st.wrap?"pre-wrap":"pre";
      if(sh.runs?.[coord]) {
        // A paragraph can mix a 10pt label and a 20pt amount. Each physical
        // line needs its own font-size strut; a shared 20pt strut clips labels.
        let line = document.createElement("div"), lineSize = 0;
        const finishLine = () => { line.style.fontSize = (lineSize || st.size || 11) * 96 / 72 + "px"; content.append(line); };
        for(const run of sh.runs[coord]) {
          run.text.split("\n").forEach((text, i) => {
            if(i) { finishLine(); line = document.createElement("div"); lineSize = 0; }
            if(text) { const span=document.createElement("span"); span.textContent=text; fontStyle(span,run); lineSize=Math.max(lineSize,run.size||st.size||11); line.append(span); }
          });
        }
        finishLine();
      }
      else if(typeof value==="number" && (st.number_format||"").includes("0.00")) content.textContent=new Intl.NumberFormat($("numbers").value==="hu"?"hu-HU":"en-US",{minimumFractionDigits:2,maximumFractionDigits:2}).format(value);
      else content.textContent=value===null?"":String(value);
      cell.title=content.textContent; cell.append(content);
      cell.onfocus=cell.onclick=()=>{ grid.querySelector(".selected-cell")?.classList.remove("selected-cell");cell.classList.add("selected-cell");addressBox.textContent=coord;valueBox.textContent=value===null?"":String(value); };
      grid.append(cell);
    }));
    for(const im of sh.images||[]) { const img=document.createElement("img");img.src=im.src;img.alt="Dokumentumgrafika";img.className="sheet-image";place(img,im.x+36,im.y+24,im.width,im.height);grid.append(img); }
    host.append(grid);
  }
  function renderOutput() {
    const e = s.job?.export;
    $("output-image").hidden = true;
    $("output-text").hidden = true;
    $("sheet-preview").hidden = true;
    $("output-page-label").hidden = true;
    $("sheet-toggle").hidden = true;
    $("output-empty").hidden = !!e;
    $("output-notes").textContent = (e?.strategy ? e.strategy + " · " : "") + (e?.warnings?.join(" ") || "");
    $("output-view").querySelector(".canvas-scroll").classList.toggle("spreadsheet-view", !!e?.sheets);
    $("fingerprint").textContent = e
      ? `IR v${e.ir_revision} · SHA256 ${e.sha256.slice(0, 16)}…`
      : "";
    if (e) {
      $("format").value = e.format;
      $("word-mode").value = e.options.word_mode;
      $("numbers").value = e.options.numbers;
      $("excel-mode").value = e.options.excel_mode || "semantic";
      $("compact").checked = e.options.compact;
      if (e.preview_pages) {
        $("output-page-label").hidden = false;
        $("output-page").replaceChildren(
          ...Array.from({ length: e.preview_pages }, (_, i) =>
            option(i + 1, `${i + 1} / ${e.preview_pages}`),
          ),
        );
        outputImage();
      } else {
        $("output-text").hidden = false;
        $("output-text").textContent = e.text_preview || "";
      }
      if (e.sheets) {
        $("sheet-toggle").hidden = false;
        sheets(e.sheets);
        $("sheet-preview").hidden = false;
        $("output-image").hidden = true;
        $("output-page-label").hidden = true;
        $("sheet-toggle").textContent = "Nyomtatási nézet";
      }
      $("download").href = `/api/studio/jobs/${s.job.id}/download`;
    }
    formatChanged(false);
    controls();
  }
  async function update(action) {
    if (s.mutating) return;
    s.mutating = true; controls();
    try {
      s.job = await action(); s.revision = s.job.revision;
      status(); await refresh(); await loadIR(); renderOutput();
    } finally { s.mutating = false; controls(); }
  }
  async function upload(files) {
    if (!files.length || !canLeaveEdit()) return;
    const f = new FormData();
    for (const file of files) f.append("files", file);
    f.append("settings", JSON.stringify(settings()));
    $("status").textContent = "Feltöltés…";
    const j = await api("/jobs", { method: "POST", body: f });
    $("password").value = "";
    await refresh();
    await select(j[0].id);
  }
  $("upload").onchange = () =>
    safe(async () => {
      await upload([...$("upload").files]);
      $("upload").value = "";
    });
  $("drop-zone").onkeydown = (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      $("upload").click();
    }
  };
  for (const name of ["dragover", "dragleave", "drop"])
    $("drop-zone").addEventListener(name, (e) => {
      e.preventDefault();
      $("drop-zone").classList.toggle("drag", name === "dragover");
      if (name === "drop") safe(() => upload([...e.dataTransfer.files]));
    });
  $("input-tab").onclick = () => tab("input");
  $("output-tab").onclick = () => tab("output");
  $("page-select").onchange = () => {
    if (!canLeaveEdit()) { $("page-select").value = s.page; return; }
    s.page = Number($("page-select").value);
    s.word = null;
    $("editor").hidden = true;
    renderPage();
  };
  $("revision-select").onchange = () =>
    safe(async () => {
      if (!canLeaveEdit()) { $("revision-select").value = s.revision; return; }
      s.revision = Number($("revision-select").value);
      s.word = null;
      $("editor").hidden = true;
      await loadIR();
    });
  document
    .querySelectorAll("[data-view]")
    .forEach((b) => (b.onclick = () => view(b.dataset.view)));
  $("opacity").oninput = () => view(s.view);
  $("zoom").oninput = zoom;
  $("boxes").onchange = () =>
    $("word-layer").classList.toggle("hide-boxes", !$("boxes").checked);
  $("grid").onchange = () => ($("structure-layer").hidden = !$("grid").checked);
  $("contrast").oninput = () =>
    ($("contrast-value").value = Number($("contrast").value).toFixed(2));
  $("gap").oninput = () =>
    ($("gap-value").value = Number($("gap").value).toFixed(2));
  $("retry").onclick = () => {
    $("grid").checked = true; $("structure-layer").hidden = false;
    safe(() =>
      update(() =>
        api(
          `/jobs/${s.job.id}/retry`,
          json({
            version: s.job.version,
            page: s.page,
            error: s.inputError,
            settings: settings(),
          }),
        ),
      ),
    );
  };
  $("restore").onclick = () =>
    safe(() =>
      update(() =>
        api(
          `/jobs/${s.job.id}/restore`,
          json({ version: s.job.version, revision: s.revision }),
        ),
      ),
    );
  $("accept-input").onclick = () =>
    safe(async () => {
      if (s.job.state === "input_review") await update(() =>
        api(`/jobs/${s.job.id}/accept-input`, json({ version: s.job.version })),
      );
      $("format-picker").showModal();
    });
  function previewFont() {
    $("edit-text").style.fontFamily = $("edit-font").value;
    $("edit-text").style.fontWeight = $("edit-bold").checked ? "700" : "400";
    $("edit-text").style.fontSize = Math.min(32,Math.max(10,Number($("edit-size").value)))+"pt";
  }
  for(const id of ["edit-font","edit-bold","edit-size"]) $(id).oninput = previewFont;
  $("save-word").onclick = () =>
    safe(async () => {
      await update(() =>
        api(
          `/jobs/${s.job.id}/word`,
          json(
            {
              version: s.editVersion,
              page: s.page,
              word: s.word.id,
              text: $("edit-text").value,
              size: Number($("edit-size").value),
              bold: $("edit-bold").checked,
              font: $("edit-font").value,
            },
            "PATCH",
          ),
        ),
      );
      s.word = null;
      $("editor").hidden = true;
      controls();
    });
  $("cancel-word").onclick = () => { s.word = null; $("editor").hidden = true; document.querySelectorAll("#word-layer .selected").forEach(n => n.classList.remove("selected")); controls(); };
  $("edit-text").onkeydown = e => {
    if (e.key === "Escape") { e.preventDefault(); $("cancel-word").click(); }
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); $("save-word").click(); }
  };
  $("generate").onclick = () =>
    safe(() =>
      update(() =>
        api(
          `/jobs/${s.job.id}/export`,
          json({ version: s.job.version, options: options() }),
        ),
      ),
    );
  $("retry-export").onclick = () =>
    safe(() =>
      update(() =>
        api(
          `/jobs/${s.job.id}/export`,
          json({
            version: s.job.version,
            options: options(),
            error: s.outputError,
          }),
        ),
      ),
    );
  async function downloadApproved() {
    const id=s.job.id, e=s.job.export;
    const response=await fetch(`/api/studio/jobs/${id}/download`,{credentials:"same-origin"});
    if(!response.ok) throw Error(await response.text());
    const url=URL.createObjectURL(await response.blob()), link=document.createElement("a");
    link.href=url;link.download=e.filename;document.body.append(link);link.click();link.remove();
    setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  $("accept-export").onclick = () => safe(async () => {
    await update(() => api(`/jobs/${s.job.id}/accept-export`,json({version:s.job.version,sha256:s.job.export.sha256})));
    await downloadApproved();
  });
  $("choose-format").onclick = () => $("format-picker").showModal();
  $("close-formats").onclick = () => $("format-picker").close();
  const iconPaths={xlsx:"M16 21h24v20H16z M16 28h24 M16 34h24 M24 21v20 M32 21v20",docx:"M16 22h23 M16 28h23 M16 34h17 M16 40h20",pdf:"M17 39c11-23 11-25 11-14 0 12 14 9 12 11-5 5-28-3-23 3",png:"M16 39l8-12 7 8 5-7 6 11 M20 21h1",html:"M23 24l-7 7 7 7 M34 24l7 7-7 7 M31 22l-4 18",txt:"M16 23h24 M28 23v18 M22 41h12",json:"M23 23c-9-2-2 8-8 8 6 0-1 10 8 8 M33 23c9-2 2 8 8 8-6 0 1 10-8 8"};
  for(const button of document.querySelectorAll("[data-format]")) {
    const f=button.dataset.format, ns="http://www.w3.org/2000/svg", svg=document.createElementNS(ns,"svg");
    svg.setAttribute("viewBox","0 0 56 56");svg.setAttribute("aria-hidden","true");
    for(const d of ["M11 5h25l10 10v36H11z M36 5v10h10",iconPaths[f]]) { const path=document.createElementNS(ns,"path");path.setAttribute("d",d);svg.append(path); }
    button.querySelector(".format-icon").append(svg);
    button.onclick=()=>{ $("format").value=f;formatChanged();$("format-picker").close();tab("output");$("generate").click(); };
  }
  $("format").onchange = () => formatChanged();
  for (const id of ["word-mode", "numbers", "excel-mode", "compact"]) $(id).onchange = controls;
  $("output-page").onchange = outputImage;
  $("sheet-toggle").onclick = () => {
    $("sheet-preview").hidden = !$("sheet-preview").hidden;
    $("output-image").hidden = !$("sheet-preview").hidden;
    $("output-page-label").hidden = !$("sheet-preview").hidden;
    $("sheet-toggle").textContent = $("sheet-preview").hidden ? "Rácsos cellanézet" : "Nyomtatási nézet";
  };
  $("batch").onclick = () =>
    safe(async () => {
      const r = await fetch(
        "/api/studio/batch",
        json(s.jobs.filter((j) => j.state === "ready").map((j) => j.id)),
      );
      if (!r.ok) throw Error(await r.text());
      const u = URL.createObjectURL(await r.blob()),
        a = document.createElement("a");
      a.href = u;
      a.download = "docstudio-batch.zip";
      a.click();
      setTimeout(() => URL.revokeObjectURL(u), 10000);
    });
  safe(async () => {
    s.caps = await api("/capabilities");
    for (const [k, v] of Object.entries(s.caps.engines)) {
      const d = document.createElement("div");
      d.className = "engine" + (v.available ? " available" : "");
      d.append(
        document.createElement("i"),
        document.createTextNode(
          v.label + (v.available ? "" : " · nincs előkészítve"),
        ),
      );
      if(v.setup) d.title=v.setup;
      if(k==="vision") {
        const details=document.createElement("p");details.className="small muted";details.textContent=v.setup+" "+v.purpose;
        const test=document.createElement("button");test.type="button";test.className="button subtle";test.textContent="Vision kapcsolat tesztelése";
        test.onclick=()=>safe(async()=>{test.disabled=true;try{const result=await api("/vision-test",json({}));details.textContent=result.message;}finally{test.disabled=false;}});
        d.append(details,test);
      }
      $("engines").append(d);
      const o = [...$("engine").options].find((o) => o.value === k);
      if (o) o.disabled = !v.available;
    }
    tags($("input-errors"), s.caps.input_errors, "inputError");
    formatChanged();
    await refresh();
    if (s.jobs.length) await select(s.jobs[0].id);
  });
  setInterval(() => {
    if (s.polling) return;
    s.polling = true;
    refresh()
      .catch((e) => alert("Állapotfrissítési hiba: " + e.message))
      .finally(() => (s.polling = false));
  }, 1600);
})();
