'use strict';
/* Native browser UI. No SPA framework, no third-party API, no HTML injection. */
const $ = id => document.getElementById(id);
const form = $('upload');
const inputs = $('files');
const state = { jobs: new Map(), ids: [], active: null, pages: [], page: 1,
                revision: 0, offset: 0, wordCount: 0, onlyLow: false,
                tab: 'preview', numbers: 'text' };
const API = id => `/api/jobs/${id}`;

async function jsonFetch(url, options = {}) {
  const response = await fetch(url, { cache: 'no-store', credentials: 'same-origin', ...options });
  let data;
  try { data = await response.json(); } catch { data = {}; }
  if (!response.ok) {
    let msg = typeof data.detail === 'string' ? data.detail : `HTTP ${response.status}`;
    if (response.status === 401) msg += ' - Jelentkezz be újra.';
    throw new Error(msg);
  }
  return data;
}
function errorText(err) { return String(err?.message || err || 'Ismeretlen hiba.'); }
function notify(text, isError = false) {
  const el = $('workspace-notice');
  el.textContent = text;
  el.classList.toggle('error', isError);
  el.hidden = !text;
}
function make(tag, className, textValue) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (textValue !== undefined) el.textContent = String(textValue);
  return el;
}
function updateBatch() {
  const ready = state.ids.filter(id => state.jobs.get(id)?.state === 'done');
  $('batch').disabled = ready.length === 0 || ready.length > 10;
  $('batch').textContent = ready.length > 10 ? 'Legfeljebb 10 kész dokumentum / ZIP' : `Kész dokumentumok ZIP-ben (${ready.length})`;
}
function renderJob(job) {
  state.jobs.set(job.id, job);
  let row = $('job-' + job.id);
  if (!row) { row = make('div', 'item'); row.id = 'job-' + job.id; $('items').append(row); }
  row.replaceChildren();
  const top = make('div', 'itemtop');
  top.append(make('strong', '', job.name));
  const labels = { queued: 'Várakozik', running: 'Feldolgozás', done: 'Kész', failed: 'Hiba' };
  const status = make('small', job.state, labels[job.state] || job.state);
  top.append(status);
  const track = make('div', 'track');
  const bar = make('div', 'bar');
  bar.style.width = `${Math.min(100, Math.max(0, Math.round(job.progress * 100)))}%`;
  track.append(bar);
  const details = make('div', 'item-detail');
  details.append(make('span', '', job.message || `${Math.round(job.progress * 100)}%`));
  if (job.state === 'done') {
    const inspect = make('button', '', 'Megnyitás és javítás');
    inspect.type = 'button';
    inspect.addEventListener('click', () => openJob(job.id).catch(e => notify(errorText(e), true)));
    details.append(inspect);
    const link = make('a', '', 'ZIP letöltése');
    link.href = `${API(job.id)}/export/all?numbers=${encodeURIComponent(state.numbers)}`;
    details.append(link);
  }
  if (job.state === 'failed') {
    const remove = make('button', '', 'Hibás feladat törlése');
    remove.type = 'button';
    remove.addEventListener('click', () => deleteJob(job.id).catch(e => { $('error').textContent = errorText(e); }));
    details.append(remove);
  }
  row.append(top, track, details);
  updateBatch();
}
async function poll(id) {
  try {
    const job = await jsonFetch(API(id));
    renderJob(job);
    if (job.state === 'queued' || job.state === 'running') {
      setTimeout(() => poll(id), 1200);
    }
  } catch (err) { $('error').textContent = errorText(err); }
}
function fileChips() {
  $('selected-files').replaceChildren();
  for (const f of Array.from(inputs.files).slice(0, 10)) {
    $('selected-files').append(make('span', 'file-chip', `${f.name} (${(f.size / 1048576).toFixed(1)} MB)`));
  }
}
inputs.addEventListener('change', fileChips);
const drop = $('drop');
for (const kind of ['dragenter', 'dragover']) drop.addEventListener(kind, event => {
  event.preventDefault(); drop.classList.add('dragover');
});
for (const kind of ['dragleave', 'drop']) drop.addEventListener(kind, event => {
  event.preventDefault(); drop.classList.remove('dragover');
});
drop.addEventListener('drop', event => {
  const dt = event.dataTransfer;
  if (dt?.files?.length) { inputs.files = dt.files; fileChips(); }
});
form.addEventListener('submit', async event => {
  event.preventDefault();
  $('error').textContent = '';
  const files = [...inputs.files];
  if (!files.length || files.length > 10) {
    $('error').textContent = '1–10 fájlt válassz ki.'; return;
  }
  if (files.some(f => f.size > 50 * 1048576 || f.size === 0)) {
    $('error').textContent = 'Minden fájl 1 bájt és 50 MB között lehet.'; return;
  }
  state.numbers = form.elements.numbers.value;
  const data = new FormData(form);
  for (const key of ['deskew', 'enhance', 'raster_lines', 'scan_graphics', 'unruled_tables', 'orientation', 'perspective', 'visual_fallback']) {
    data.set(key, String(form.elements[key].checked));
  }
  $('submit').disabled = true;
  try {
    const result = await jsonFetch('/api/jobs', { method: 'POST', body: data });
    $('items').querySelector('.muted')?.remove();
    for (const job of result.jobs) {
      state.ids.push(job.id);
      renderJob(job);
      poll(job.id);
    }
    inputs.value = ''; fileChips();
  } catch (err) { $('error').textContent = errorText(err); }
  finally { $('submit').disabled = false; }
});
$('batch').addEventListener('click', async () => {
  try {
    const response = await fetch('/api/batch/download?numbers=' + encodeURIComponent(state.numbers), {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(state.ids.filter(id => state.jobs.get(id)?.state === 'done')),
    });
    if (!response.ok) throw new Error('A közös ZIP nem készült el.');
    const url = URL.createObjectURL(await response.blob());
    const link = make('a'); link.href = url; link.download = 'docstudio_batch.zip';
    document.body.append(link); link.click(); link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 15000);
  } catch (err) { $('error').textContent = errorText(err); }
});

async function openJob(id) {
  const payload = await jsonFetch(`${API(id)}/pages`);
  state.active = id;
  state.pages = payload.pages;
  state.revision = payload.revision;
  state.page = 1;
  state.offset = 0;
  $('workspace').hidden = false;
  $('workspace-name').textContent = payload.filename;
  $('page-select').replaceChildren();
  for (const p of payload.pages) {
    const option = make('option', '', `${p.number}. oldal – ${p.words} szó`);
    option.value = p.number;
    $('page-select').append(option);
  }
  notify('');
  $('ai-results').replaceChildren();
  $('ai-consent').checked = false;
  updateManualDefaults();
  await showTab(state.tab);
  $('workspace').scrollIntoView({ behavior: 'smooth', block: 'start' });
}
function currentPage() { return state.pages.find(p => p.number === state.page); }
function updateManualDefaults() {
  const p = currentPage(); if (!p) return;
  $('manual-bbox').value = `20,80,${(p.width - 20).toFixed(1)},${Math.max(120, p.height - 50).toFixed(1)}`;
  $('manual-xs').value = (p.width / 2).toFixed(1);
  $('manual-ys').value = `${(p.height / 3).toFixed(1)},${(p.height * 2 / 3).toFixed(1)}`;
}
$('page-select').addEventListener('change', async () => {
  state.page = Number($('page-select').value); state.offset = 0;
  $('ai-results').replaceChildren(); $('ai-consent').checked = false;
  notify(''); updateManualDefaults();
  try { await showTab(state.tab); } catch (e) { notify(errorText(e), true); }
});
for (const button of document.querySelectorAll('[data-tab]')) {
  button.addEventListener('click', () => showTab(button.dataset.tab).catch(e => notify(errorText(e), true)));
}
async function showTab(tab) {
  state.tab = tab;
  for (const button of document.querySelectorAll('[data-tab]')) {
    button.classList.toggle('active', button.dataset.tab === tab);
    button.setAttribute('aria-selected', String(button.dataset.tab === tab));
  }
  for (const name of ['preview', 'words', 'tables', 'downloads']) {
    $('tab-' + name).hidden = name !== tab;
  }
  if (!state.active) return;
  if (tab === 'preview') await loadPreview();
  else if (tab === 'words') await loadWords();
  else if (tab === 'tables') await loadTables();
  else drawExports();
}
$('blend').addEventListener('input', () => {
  $('img-reconstructed').style.opacity = (Number($('blend').value) / 100).toString();
  $('blend-value').textContent = $('blend').value + '%';
});
$('draw-boxes').addEventListener('change', () => drawBoxes().catch(e => notify(errorText(e), true)));
$('preview-mode').addEventListener('change', () => loadPreview().catch(e => notify(errorText(e), true)));
for (const id of ['img-original', 'img-reconstructed']) $(id).addEventListener('error', () => notify('Az előnézet nem tölthető be. Frissítsd az oldalt vagy ellenőrizd a feldolgozást.', true));
async function loadPreview() {
  const base = `${API(state.active)}/pages/${state.page}/preview`;
  const mode = $('preview-mode').value;
  $('img-original').src = `${base}/${mode === 'source' ? 'source' : 'original'}?v=${state.revision}`;
  $('img-reconstructed').hidden = mode === 'source';
  if (mode !== 'source') $('img-reconstructed').src = `${base}/reconstructed?v=${state.revision}`;
  $('img-reconstructed').style.opacity = mode === 'reconstructed' ? 1 : Number($('blend').value) / 100;
  $('blend').disabled = mode !== 'compare';
  $('draw-boxes').disabled = mode === 'source';
  $('preview-boxes').style.display = mode === 'source' ? 'none' : '';
  const p = currentPage();
  $('page-diagnostics').textContent = `${p.words} szó · ${p.low_confidence} ellenőrizendő · ${p.tables} táblázat. ${p.warnings.join(' ')}`;
  $('preview-boxes').setAttribute('viewBox', `0 0 ${p.width} ${p.height}`);
  $('preview-boxes').replaceChildren();
  if (mode !== 'source' && $('draw-boxes').checked) await drawBoxes();
}
async function drawBoxes() {
  const svg = $('preview-boxes'); svg.replaceChildren();
  if (!$('draw-boxes').checked || !state.active || $('preview-mode').value === 'source') return;
  const requested = `${state.active}/${state.page}`;
  const max = 2500;
  let offset = 0, total = 0;
  do {
    const data = await jsonFetch(`${API(state.active)}/pages/${state.page}/words?offset=${offset}&limit=200`);
    if (requested !== `${state.active}/${state.page}`) return;
    total = data.total;
    for (const word of data.words) {
      const [x0,y0,x1,y1] = word.bbox;
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', x0); rect.setAttribute('y', y0);
      rect.setAttribute('width', Math.max(0, x1-x0));
      rect.setAttribute('height', Math.max(0, y1-y0));
      rect.setAttribute('fill', 'none');
      rect.setAttribute('stroke', word.needs_review ? '#dc8a20' : '#3974ce');
      rect.setAttribute('stroke-width', '0.75');
      svg.append(rect);
    }
    offset += data.words.length;
    if (!data.words.length) break;
  } while (offset < total && offset < max);
  if (total > max) notify('Több mint 2500 szódoboz: az előnézet az első 2500-at mutatja.');
}
$('only-low').addEventListener('change', () => {
  state.onlyLow = $('only-low').checked; state.offset = 0;
  loadWords().catch(e => notify(errorText(e), true));
});
async function loadWords() {
  const low = state.onlyLow ? 'true' : 'false';
  const result = await jsonFetch(`${API(state.active)}/pages/${state.page}/words?only_low=${low}&offset=${state.offset}&limit=80`);
  state.revision = result.revision;
  state.wordCount = result.total;
  $('word-count').textContent = `${result.total} szó`;
  const body = $('word-rows'); body.replaceChildren();
  $('word-crop-panel').hidden = true;
  for (const item of result.words) {
    const tr = make('tr', item.needs_review ? 'is-low' : '');
    tr.append(make('td', '', item.id));
    const input = make('input'); input.type = 'text'; input.value = item.text; input.maxLength = 1000;
    input.setAttribute('aria-label', 'Felismert szó: ' + item.id);
    const tdInput = make('td'); tdInput.append(input);
    if (item.alternatives?.length) tdInput.append(make('small', 'micro-note', 'Eltérő OCR-olvasatok: ' + item.alternatives.join(' / ')));
    tr.append(tdInput);
    tr.append(make('td', item.needs_review ? 'confidence low' : 'confidence', item.confidence == null ? '-' : Math.round(item.confidence * 100) + '%'));
    const box = make('input'); box.type = 'checkbox'; box.checked = item.reviewed;
    box.setAttribute('aria-label', 'Ellenőrizve: ' + item.id);
    const tdBox = make('td'); tdBox.append(box); tr.append(tdBox);
    const save = make('button', 'btn btn-quiet', 'Mentés'); save.type = 'button';
    save.addEventListener('click', async () => {
      save.disabled = true;
      try {
        const update = await jsonFetch(`${API(state.active)}/pages/${state.page}/words/${encodeURIComponent(item.id)}`, {
          method: 'PATCH', headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({text: input.value, reviewed: box.checked}),
        });
        state.revision = update.revision;
        notify('Javítás mentve, az exportok frissültek.');
        await loadWords();
      } catch (err) { notify(errorText(err), true); save.disabled = false; }
    });
    const source = make('button', 'source-button', 'Forrás'); source.type = 'button';
    source.addEventListener('click', () => {
      $('word-crop-panel').hidden = false;
      $('word-crop-label').textContent = `Eredeti részlet: ${item.id}`;
      $('word-crop-img').src = `${API(state.active)}/pages/${state.page}/words/${encodeURIComponent(item.id)}/crop`;
    });
    const tdSave = make('td'); tdSave.append(save, source); tr.append(tdSave);
    body.append(tr);
  }
  const begin = result.total ? result.offset + 1 : 0;
  const end = Math.min(result.offset + result.words.length, result.total);
  $('words-position').textContent = `${begin}-${end} / ${result.total}`;
  $('words-prev').disabled = result.offset === 0;
  $('words-next').disabled = result.offset + result.words.length >= result.total;
}
$('words-prev').addEventListener('click', () => { state.offset = Math.max(0, state.offset - 80); loadWords().catch(e => notify(errorText(e), true)); });
$('words-next').addEventListener('click', () => { state.offset += 80; loadWords().catch(e => notify(errorText(e), true)); });
async function loadTables() {
  const result = await jsonFetch(`${API(state.active)}/pages/${state.page}/tables`);
  const audit = $('audit'); audit.replaceChildren();
  for (const [value,label] of [[result.audit.words,'Szavak'],[result.audit.assigned,'Helyhez rendelve'],[result.audit.tables,'Táblázatok'],[result.audit.low_confidence,'OCR ellenőrzés']]) {
    const box = make('div', 'audit-stat');
    box.append(make('strong', '', value), make('span', '', label)); audit.append(box);
  }
  const list = $('table-list'); list.replaceChildren();
  if (!result.tables.length) list.append(make('p', 'muted', 'Ezen az oldalon nincs felismert táblázat.'));
  for (const table of result.tables) {
    const card = make('article', 'table-preview');
    const head = make('div', 'table-title', `${table.id} - ${table.columns} oszlop, ${table.rows} sor`);
    head.append(make('small', '', ` ${table.method}`)); card.append(head);
    const scroll = make('div', 'table-scroll');
    const htmlTable = make('table', 'data-table');
    const tbody = make('tbody');
    for (const row of table.matrix) {
      const tr = make('tr');
      for (const cell of row) tr.append(make('td', '', cell));
      tbody.append(tr);
    }
    htmlTable.append(tbody); scroll.append(htmlTable); card.append(scroll);
    if (table.truncated) card.append(make('p', 'micro-note', 'Csak 150 sor előnézete. A teljes táblázat az Excelben található.'));
    list.append(card);
  }
  for (const w of result.warnings) list.append(make('p', 'micro-note', w));
}
function commaNumbers(text, expected) {
  const result = text.split(',').map(s => Number(s.trim()));
  if (result.length < expected || result.some(n => !Number.isFinite(n))) throw new Error('Az elválasztott koordinátáknak számoknak kell lenniük.');
  return result;
}
$('manual-form').addEventListener('submit', async event => {
  event.preventDefault();
  try {
    const bbox = commaNumbers($('manual-bbox').value, 4);
    if (bbox.length !== 4) throw new Error('Pontosan négy területkoordináta szükséges.');
    const x_edges = commaNumbers($('manual-xs').value, 1);
    const y_edges = commaNumbers($('manual-ys').value, 1);
    const result = await jsonFetch(`${API(state.active)}/pages/${state.page}/tables`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ bbox, x_edges, y_edges }),
    });
    state.revision = result.revision;
    notify('Táblázatszerkezet mentve.');
    await loadTables();
  } catch (err) { notify(errorText(err), true); }
});
const EXPORTS = [
  ['all', 'Összes alapformátum', 'ZIP'],
  ['xlsx', 'Szerkeszthető Excel', 'XLSX'],
  ['docx', 'Szerkeszthető Word', 'DOCX'],
  ['reconstructed-pdf', 'Újraalkotott PDF', 'PDF'],
  ['original-pdf', 'Eredeti kinézet megőrzése', 'PDF'],
  ['searchable-pdf', 'Kereshető, tájolásjavított másolat', 'PDF'],
  ['source-file', 'Feltöltött forrás változatlanul', 'EREDETI'],
  ['html', 'Újraalkotott HTML', 'HTML'],
  ['txt', 'Felismert szöveg', 'TXT'],
  ['json', 'Koordináták, ellenőrzés', 'JSON'],
  ['csv', 'Táblázatok kulon', 'CSV / ZIP'],
  ['png', 'Oldalképek', 'PNG / ZIP'],
  ['svg', 'Vektoros oldalak', 'SVG / ZIP'],
];
function drawExports() {
  const box = $('export-links'); box.replaceChildren();
  for (const [kind,label,ext] of EXPORTS) {
    const link = make('a', 'export-link');
    link.href = `${API(state.active)}/export/${kind}?numbers=${encodeURIComponent(state.numbers)}&v=${state.revision}`;
    link.append(make('span', '', label), make('small', '', ext + ' \u2193'));
    box.append(link);
  }
}
$('delete-job').addEventListener('click', async () => {
  if (!state.active || !window.confirm('Töröljük a dokumentumot és az ideiglenes exportokat?')) return;
  try {
    await deleteJob(state.active);
  } catch (err) { notify(errorText(err), true); }
});

async function deleteJob(id) {
  await jsonFetch(API(id), { method: 'DELETE' });
  $('job-' + id)?.remove(); state.jobs.delete(id);
  state.ids = state.ids.filter(item => item !== id);
  if (state.active === id) { state.active = null; $('workspace').hidden = true; }
  updateBatch();
  if (!state.ids.length) $('items').append(make('p', 'muted', 'Még nincs feldolgozási feladat.'));
}

$('ai-review').addEventListener('click', async () => {
  if (!$('ai-consent').checked) { notify('Az AI kéréshez jelöld be a továbbítás engedélyezését.', true); return; }
  const job = state.active, page = state.page;
  $('ai-review').disabled = true; $('ai-results').replaceChildren(make('p', '', 'Vision ellenőrzés folyamatban…'));
  try {
    const result = await jsonFetch(`${API(job)}/pages/${page}/ai-review`, {
      method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({consent: true}),
    });
    if (job !== state.active || page !== state.page) return;
    const box = $('ai-results'); box.replaceChildren();
    for (const item of result.corrections) {
      const row = make('div', 'ai-proposal');
      row.append(make('p', '', `${item.before} → ${item.text}`), make('small', '', item.reason));
      if (item.numeric) row.append(make('p', 'micro-note', 'Számot vagy azonosítót érint: ellenőrizd a forrásrészletet, és szükség esetén javítsd a szólistában.'));
      else {
        const apply = make('button', 'btn btn-quiet', 'Ellenőriztem, elfogadom'); apply.type = 'button';
        apply.addEventListener('click', async () => {
          apply.disabled = true;
          try {
            const saved = await jsonFetch(`${API(job)}/pages/${page}/words/${encodeURIComponent(item.word_id)}`, {
              method: 'PATCH', headers: {'Content-Type': 'application/json'},
              body: JSON.stringify({text: item.text, expected_text: item.before, reviewed: true}),
            });
            state.revision = saved.revision; row.remove(); await loadWords();
          } catch (e) { notify(errorText(e), true); apply.disabled = false; }
        }); row.append(apply);
      }
      box.append(row);
    }
    for (const item of result.tables) {
      const row = make('div', 'ai-proposal'); row.append(make('p', '', 'Táblázatjavaslat: ' + item.reason));
      const inspect = make('button', 'btn btn-quiet', 'Határok megnyitása ellenőrzésre'); inspect.type = 'button';
      inspect.addEventListener('click', async () => {
        $('manual-bbox').value = item.bbox.join(','); $('manual-xs').value = item.x_edges.join(','); $('manual-ys').value = item.y_edges.join(',');
        document.querySelector('.manual-editor').open = true;
        try { await showTab('tables'); } catch (e) { notify(errorText(e), true); }
      }); row.append(inspect); box.append(row);
    }
    if (!result.corrections.length && !result.tables.length) box.append(make('p', '', 'Nem érkezett alkalmazható javaslat.'));
  } catch (e) { $('ai-results').replaceChildren(); notify(errorText(e), true); }
  finally { $('ai-review').disabled = false; }
});

async function restoreWorkspace() {
  try {
    const [payload, capabilities] = await Promise.all([jsonFetch('/api/jobs'), jsonFetch('/api/capabilities')]);
    $('ai-panel').hidden = !capabilities.ai_enabled;
    if (!capabilities.ocr_languages.includes('hun')) $('error').textContent = 'A magyar OCR-modell hiányzik. Futtasd a telepítési útmutatóban szereplő modelltelepítőt.';
    if (payload.jobs.length) $('items').replaceChildren();
    for (const job of payload.jobs) { state.ids.push(job.id); renderJob(job); if (['queued', 'running'].includes(job.state)) poll(job.id); }
  } catch (e) { $('error').textContent = errorText(e); }
}
restoreWorkspace();
