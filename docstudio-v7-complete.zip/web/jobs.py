"""In-process, bounded job runner. Intentionally single Uvicorn process.

A durable distributed queue (Redis/RQ + object storage) is a future upgrade,
not a feature claimed by this single-process deployment.
"""

from __future__ import annotations
import os
import json
import re
import shutil
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from fastapi import UploadFile

ROOT = Path(os.environ.get("JOB_DIR", "/tmp/reconstructor-jobs"))
ROOT.mkdir(parents=True, exist_ok=True, mode=0o700)
MAX_BYTES = 50 * 1024 * 1024
MAX_ACTIVE_JOBS = max(1, int(os.getenv("MAX_ACTIVE_JOBS", "20")))
JOB_TTL_SECONDS = max(60, int(os.getenv("JOB_TTL_SECONDS", "3600")))
ALLOWED = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".webp", ".bmp"}
EXECUTOR = ThreadPoolExecutor(max_workers=max(1, min(4, int(os.getenv("JOB_WORKERS", "1")))))
JOBS: dict[str, "Job"] = {}
LOCK = threading.RLock()


@dataclass
class Job:
    id: str
    owner: str
    name: str
    path: Path
    state: str = "queued"
    progress: float = 0.0
    message: str = ""
    created: float = field(default_factory=time.time)
    touched: float = field(default_factory=time.time)
    revision: int = 0
    document: Any = field(default=None, repr=False)
    outputs: dict[tuple, Path] = field(default_factory=dict, repr=False)
    lock: Any = field(default_factory=threading.RLock, repr=False)

    def public(self) -> dict[str, Any]:
        doc = self.document
        return {
            "id": self.id,
            "name": self.name,
            "state": self.state,
            "progress": round(self.progress, 3),
            "message": self.message,
            "revision": self.revision,
            "pages": len(doc.pages) if doc else 0,
            "warnings": len(doc.warnings) if doc else 0,
        }


def _verify_header(path: Path, ext: str) -> None:
    with open(path, "rb") as f:
        header = f.read(1024)
    if ext == ".pdf":
        if b"%PDF-" not in header:
            raise ValueError("A feltoltott fajl nem ervenyes PDF.")
    else:
        from PIL import Image, UnidentifiedImageError

        try:
            with Image.open(path) as img:
                if img.format not in ("PNG", "JPEG", "TIFF", "WEBP", "BMP"):
                    raise ValueError("Nem tamogatott kepkodolas.")
                img.verify()
        except (UnidentifiedImageError, OSError) as exc:
            raise ValueError("A kep nem olvashato vagy serult.") from exc


def free_slots() -> int:
    with LOCK:
        return MAX_ACTIVE_JOBS - len(JOBS)


async def create(upload: UploadFile, owner: str) -> Job:
    name = Path((upload.filename or "document.pdf").replace("\\", "/")).name[:120]
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED:
        raise ValueError("Csak PDF, PNG, JPG, TIFF, WEBP es BMP engedelyezett.")
    if free_slots() <= 0:
        raise OverflowError("A feldolgozasi sor megtelt. Probalj ujra kesobb.")
    identifier = uuid.uuid4().hex
    folder = ROOT / identifier
    folder.mkdir(mode=0o700)
    source = folder / ("input" + ext)
    size = 0
    try:
        with open(source, "wb") as dst:
            while chunk := await upload.read(1024 * 1024):
                size += len(chunk)
                if size > MAX_BYTES:
                    raise ValueError("Egy fajl legfeljebb 50 MB lehet.")
                dst.write(chunk)
        if size == 0:
            raise ValueError("Ures fajl nem dolgozhato fel.")
        _verify_header(source, ext)
        job = Job(identifier, owner, name, source)
        with LOCK:
            if len(JOBS) >= MAX_ACTIVE_JOBS:
                raise OverflowError("A feldolgozasi sor megtelt.")
            JOBS[identifier] = job
        return job
    except BaseException:
        shutil.rmtree(folder, ignore_errors=True)
        raise
    finally:
        await upload.close()


def process(job: Job, settings: dict) -> None:
    with job.lock:
        job.state = "running"
        job.progress = 0.02
        job.message = "Beolvasas"
    try:
        from reconstructor.extract import read_document
        from reconstructor.model import Options

        options = Options(
            quality=settings.get("quality", "accurate"),
            orientation=settings.get("orientation", True),
            rotation=settings.get("rotation", 0),
            perspective=settings.get("perspective", False),
            ocr=settings["ocr"],
            languages=settings["languages"],
            dpi=settings["dpi"],
            psm=settings["psm"],
            deskew=settings["deskew"],
            enhance=settings["enhance"],
            raster_lines=settings["raster_lines"],
            scan_graphics=settings["scan_graphics"],
            visual_fallback=settings.get("visual_fallback", False),
            unruled_tables=settings["unruled_tables"],
            gap_factor=settings["gap_factor"],
            max_pages=settings["max_pages"],
        )

        def progress(done: int, total: int) -> None:
            with job.lock:
                job.progress = 0.02 + 0.96 * done / max(1, total)
                completed = int(done)
                job.message = (
                    f"{completed}/{total} oldal kész"
                    if done == completed
                    else f"{completed + 1}/{total}. oldal feldolgozása"
                )

        doc = read_document(
            job.path.read_bytes(), job.name, options, settings.get("password", ""), progress
        )
        with job.lock:
            job.document = doc
            job.progress = 1.0
            job.message = f"{len(doc.pages)} oldal feldolgozva"
            job.state = "done"
            job.touched = time.time()
            persist(job, save_document=True)
    except Exception as exc:
        with job.lock:
            job.state = "failed"
            job.message = f"{type(exc).__name__}: {exc}"[:350]
            persist(job)


def submit(job: Job, settings: dict) -> None:
    persist(job)
    EXECUTOR.submit(process, job, dict(settings))


def get(job_id: str, owner: str) -> Job | None:
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        return None
    with LOCK:
        job = JOBS.get(job_id)
        if job is None or job.owner != owner:
            return None
    with job.lock:
        previous = job.touched
        job.touched = time.time()
        if job.touched - previous > 60:
            persist(job)
        return job


def require_document(job: Job):
    if job.state != "done" or job.document is None:
        raise RuntimeError("A dokumentum meg feldolgozas alatt all.")
    return job.document


FORMATS: dict[str, tuple[str, str]] = {
    "all": ("zip", "application/zip"),
    "original-pdf": ("pdf", "application/pdf"),
    "searchable-pdf": ("pdf", "application/pdf"),
    "reconstructed-pdf": ("pdf", "application/pdf"),
    "xlsx": ("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
    "docx": ("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
    "html": ("html", "text/html; charset=utf-8"),
    "txt": ("txt", "text/plain; charset=utf-8"),
    "json": ("json", "application/json"),
    "csv": ("zip", "application/zip"),
    "png": ("zip", "application/zip"),
    "svg": ("zip", "application/zip"),
}


def export(job: Job, kind: str, numbers: str = "text") -> Path:
    if kind not in FORMATS or numbers not in ("text", "hu", "en"):
        raise ValueError("Ervenytelen exportformatum.")
    with job.lock:
        doc = require_document(job)
        key = (kind, numbers if kind in ("all", "xlsx") else "", job.revision)
        previous = job.outputs.get(key)
        if previous is not None and previous.is_file():
            return previous
        from reconstructor.export import (
            all_exports,
            csv_tables,
            excel,
            image_archive,
            plain_text,
            word_document,
        )
        from reconstructor.render import (
            preserved_pdf,
            reconstructed_pdf,
            standalone_html,
            searchable_pdf,
        )

        result = {
            "all": lambda: all_exports(doc, numbers),
            "original-pdf": lambda: preserved_pdf(doc),
            "searchable-pdf": lambda: searchable_pdf(doc),
            "reconstructed-pdf": lambda: reconstructed_pdf(doc),
            "xlsx": lambda: excel(doc, numbers),
            "docx": lambda: word_document(doc),
            "html": lambda: standalone_html(doc),
            "txt": lambda: plain_text(doc),
            "json": lambda: doc.to_json(),
            "csv": lambda: csv_tables(doc),
            "png": lambda: image_archive(doc, "png"),
            "svg": lambda: image_archive(doc, "svg"),
        }[kind]()
        output = job.path.parent / f"{kind}_{numbers}_{job.revision}.{FORMATS[kind][0]}"
        output.write_bytes(result)
        job.outputs[key] = output
        return output


def invalidate(job: Job) -> None:
    # Immutable revision files remain available to ongoing downloads until cleanup.
    job.outputs.clear()
    job.revision += 1
    persist(job, save_document=True)


def remove(job: Job) -> None:
    with job.lock:
        if job.state in ("running", "queued"):
            raise RuntimeError("Futo feldolgozast nem lehet torolni.")
        with LOCK:
            JOBS.pop(job.id, None)
        job.document = None
        shutil.rmtree(job.path.parent, ignore_errors=True)


def cleanup() -> int:
    now = time.time()
    expired = []
    with LOCK:
        for job in JOBS.values():
            if job.state in ("done", "failed") and now - job.touched > JOB_TTL_SECONDS:
                expired.append(job)
    for job in expired:
        try:
            remove(job)
        except RuntimeError:
            pass
    return len(expired)


def discard_unsubmitted(job):
    with LOCK:
        JOBS.pop(job.id, None)
    shutil.rmtree(job.path.parent, ignore_errors=True)


def persist(job, save_document=False):
    if save_document and job.document:
        from reconstructor.persistence import save

        save(job.document, job.path.parent / "document.json.gz")
    item = dict(
        id=job.id,
        owner=job.owner,
        name=job.name,
        input=job.path.name,
        state=job.state,
        progress=job.progress,
        message=job.message,
        created=job.created,
        touched=job.touched,
        revision=job.revision,
    )
    path = job.path.parent / "job.json"
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(item, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def restore():
    from reconstructor.persistence import load

    for folder in ROOT.iterdir():
        if (
            not folder.is_dir()
            or not re.fullmatch(r"[a-f0-9]{32}", folder.name)
            or folder.name in JOBS
        ):
            continue
        try:
            raw = json.loads((folder / "job.json").read_text())
            if time.time() - raw["touched"] > JOB_TTL_SECONDS:
                shutil.rmtree(folder)
                continue
            job = Job(
                folder.name,
                raw["owner"],
                raw["name"],
                folder / Path(raw["input"]).name,
                state=raw["state"],
                progress=raw["progress"],
                message=raw["message"],
                created=raw["created"],
                touched=raw["touched"],
                revision=raw["revision"],
            )
            if job.state in ("queued", "running"):
                job.state = "failed"
                job.message = "A szerver feldolgozás közben újraindult. Töltsd fel újra a fájlt."
            if job.state == "done":
                job.document = load(folder / "document.json.gz")
            JOBS[job.id] = job
        except (OSError, ValueError, KeyError, TypeError, EOFError):
            shutil.rmtree(folder, ignore_errors=True)
