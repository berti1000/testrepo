"""FastAPI HTML frontend + authenticated, per-browser document job API."""

from __future__ import annotations
import asyncio
from contextlib import asynccontextmanager
import os
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.responses import (
    PlainTextResponse,
)
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from starlette.middleware.gzip import GZipMiddleware

from dotenv import load_dotenv

load_dotenv()

from . import jobs
from .security import (
    environment_ready,
    session_secret,
)

BASE = Path(__file__).resolve().parent
environment_ready()


@asynccontextmanager
async def lifespan(app: FastAPI):
    async def cleanup_loop():
        while True:
            await asyncio.sleep(60)
            jobs.cleanup()
            from studio.store import STORE

            STORE.cleanup()

    jobs.restore()
    from studio.store import STORE

    STORE.recover()
    task = asyncio.create_task(cleanup_loop())
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(
    title="Dokumentum-rekonstrukcio",
    version="7.0.0",
    lifespan=lifespan,
    docs_url=None,
    redoc_url=None,
    openapi_url=None,
)
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    SessionMiddleware,
    secret_key=session_secret(),
    session_cookie="docstudio_session",
    max_age=60 * 60 * 24,
    same_site="lax",
    https_only=os.getenv("COOKIE_SECURE", "0") == "1",
)


@app.middleware("http")
async def response_safety(request: Request, call_next):
    if request.method == "POST" and request.url.path == "/api/jobs":
        length = request.headers.get("content-length")
        if length and length.isdecimal() and int(length) > 10 * jobs.MAX_BYTES + 5 * 1048576:
            return PlainTextResponse("Feltoltesi merethatar tullepve.", status_code=413)
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault(
        "Content-Security-Policy",
        "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data: blob:; connect-src 'self'; form-action 'self'; "
        "object-src 'none'; frame-ancestors 'none'; base-uri 'self'",
    )
    if request.url.path.startswith("/api/") or request.url.path == "/login":
        response.headers["Cache-Control"] = "no-store"
    return response


from .limits import UploadLimitMiddleware

app.add_middleware(UploadLimitMiddleware)

app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")
from .routes.pages import router as page_router

app.include_router(page_router)
if os.getenv("ENABLE_LEGACY_API", "0") == "1":
    from .routes.api import router as api_router

    app.include_router(api_router)

from .routes.studio_api import router as studio_router

app.include_router(studio_router)
