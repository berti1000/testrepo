import os
from starlette.exceptions import HTTPException
from starlette.responses import PlainTextResponse


class UploadLimitMiddleware:
    def __init__(self, app):
        self.app = app
        self.limit = int(os.getenv("MAX_REQUEST_MB", "100")) * 1024 * 1024

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http" or scope.get("method") not in ("POST", "PATCH"):
            return await self.app(scope, receive, send)
        limit = self.limit if scope.get("path") in ("/api/jobs", "/api/studio/jobs") else 256 * 1024
        headers = dict(scope.get("headers", []))
        length = headers.get(b"content-length", b"")
        if length.isdigit() and int(length) > limit:
            return await PlainTextResponse("A kérés túl nagy.", status_code=413)(
                scope, receive, send
            )
        count = 0

        async def limited():
            nonlocal count
            message = await receive()
            if message["type"] == "http.request":
                count += len(message.get("body", b""))
                if count > limit:
                    raise HTTPException(413, "A kérés túl nagy.")
            return message

        await self.app(scope, limited, send)
